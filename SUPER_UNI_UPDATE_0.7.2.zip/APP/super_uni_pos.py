from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse, parse_qs
import sqlite3, os, json, hashlib, mimetypes, smtplib, ssl, secrets, shutil, threading, time, socket
from email.message import EmailMessage
from datetime import datetime, date, timedelta

APP_DIR=os.path.dirname(os.path.abspath(__file__))
DATA_DIR=os.environ.get('SUPER_UNI_DATA_DIR',os.path.join(os.path.dirname(APP_DIR),'DATOS'))
os.makedirs(DATA_DIR,exist_ok=True)
DB_PATH=os.path.join(DATA_DIR,'super_uni_pos.db')
STATIC_DIR=os.path.join(APP_DIR,'static')
BACKUP_DIR=os.path.join(DATA_DIR,'RESPALDOS')
os.makedirs(BACKUP_DIR,exist_ok=True)
VERSION_PATH=os.path.join(APP_DIR,'version.json')
BACKUP_LOCK=threading.Lock()
PID_PATH=os.path.join(DATA_DIR,'super_uni_server.pid')
PID_PATH=os.path.join(DATA_DIR,'super_uni_server.pid')
PROVIDERS=['BARCEL','BIMBO','BOING','CIGARROS','COCA COLA','COSTEÑA','DANONE','DULCES','GAMESA','HOLANDA','JARRITOS','LALA','PEÑAFIEL','PEPSI','SABRITAS','SOL','YAKULT','YOPLAIT','ZORRO']

def now(): return datetime.now().isoformat(timespec='seconds')
def pin_hash(pin): return hashlib.sha256(str(pin).encode()).hexdigest()

def local_ip():
    try:
        s=socket.socket(socket.AF_INET,socket.SOCK_DGRAM)
        s.connect(("8.8.8.8",80))
        ip=s.getsockname()[0]
        s.close()
        return ip
    except Exception:
        try:return socket.gethostbyname(socket.gethostname())
        except:return "127.0.0.1"
def db():
    c=sqlite3.connect(DB_PATH,timeout=20); c.row_factory=sqlite3.Row; c.execute('PRAGMA foreign_keys=ON'); return c

def init_db():
    c=db(); cur=c.cursor(); cur.executescript('''
    CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT UNIQUE NOT NULL,role TEXT NOT NULL DEFAULT 'CAJERO',pin_hash TEXT NOT NULL,active INTEGER NOT NULL DEFAULT 1,created_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS products(id INTEGER PRIMARY KEY AUTOINCREMENT,barcode TEXT UNIQUE,name TEXT NOT NULL,provider TEXT NOT NULL,presentation TEXT,category TEXT,supplier_price REAL NOT NULL DEFAULT 0,sale_price REAL NOT NULL DEFAULT 0,stock INTEGER NOT NULL DEFAULT 0,min_stock INTEGER NOT NULL DEFAULT 0,active INTEGER NOT NULL DEFAULT 1,created_at TEXT NOT NULL,updated_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS inventory_movements(id INTEGER PRIMARY KEY AUTOINCREMENT,product_id INTEGER NOT NULL,movement_type TEXT NOT NULL,qty INTEGER NOT NULL,stock_before INTEGER NOT NULL,stock_after INTEGER NOT NULL,note TEXT,user_name TEXT,created_at TEXT NOT NULL,FOREIGN KEY(product_id) REFERENCES products(id));
    CREATE TABLE IF NOT EXISTS inventory_receipts(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        provider TEXT NOT NULL,
        user_name TEXT NOT NULL,
        status TEXT NOT NULL DEFAULT 'OPEN',
        started_at TEXT NOT NULL,
        ended_at TEXT,
        email_sent INTEGER NOT NULL DEFAULT 0,
        email_message TEXT
    );
    CREATE TABLE IF NOT EXISTS inventory_receipt_items(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        receipt_id INTEGER NOT NULL,
        product_id INTEGER NOT NULL,
        product_name TEXT NOT NULL,
        movement_type TEXT NOT NULL,
        qty INTEGER NOT NULL,
        stock_before INTEGER NOT NULL,
        stock_after INTEGER NOT NULL,
        note TEXT,
        created_at TEXT NOT NULL,
        FOREIGN KEY(receipt_id) REFERENCES inventory_receipts(id),
        FOREIGN KEY(product_id) REFERENCES products(id)
    );
    CREATE TABLE IF NOT EXISTS sales(id INTEGER PRIMARY KEY AUTOINCREMENT,total REAL NOT NULL,payment_method TEXT NOT NULL,received REAL NOT NULL DEFAULT 0,change_due REAL NOT NULL DEFAULT 0,cashbox TEXT NOT NULL,user_name TEXT,voided INTEGER NOT NULL DEFAULT 0,void_reason TEXT,created_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS sale_items(id INTEGER PRIMARY KEY AUTOINCREMENT,sale_id INTEGER NOT NULL,product_id INTEGER NOT NULL,product_name TEXT NOT NULL,qty INTEGER NOT NULL,unit_price REAL NOT NULL,supplier_price REAL NOT NULL,line_total REAL NOT NULL,FOREIGN KEY(sale_id) REFERENCES sales(id),FOREIGN KEY(product_id) REFERENCES products(id));
    CREATE TABLE IF NOT EXISTS cash_sessions(id INTEGER PRIMARY KEY AUTOINCREMENT,cashbox TEXT NOT NULL,user_name TEXT NOT NULL,opening_amount REAL NOT NULL DEFAULT 0,opened_at TEXT NOT NULL,closed_at TEXT,closing_counted REAL,expected_cash REAL,difference REAL,status TEXT NOT NULL DEFAULT 'OPEN');
    CREATE TABLE IF NOT EXISTS cash_movements(id INTEGER PRIMARY KEY AUTOINCREMENT,session_id INTEGER NOT NULL,movement_type TEXT NOT NULL,amount REAL NOT NULL,note TEXT,user_name TEXT,created_at TEXT NOT NULL,FOREIGN KEY(session_id) REFERENCES cash_sessions(id));
    CREATE TABLE IF NOT EXISTS purchase_comparisons(id INTEGER PRIMARY KEY AUTOINCREMENT,product_id INTEGER NOT NULL,qty INTEGER NOT NULL,supplier_price REAL NOT NULL,wholesale_price REAL NOT NULL,supplier_total REAL NOT NULL,wholesale_total REAL NOT NULL,savings REAL NOT NULL,add_to_stock INTEGER NOT NULL DEFAULT 0,created_at TEXT NOT NULL,FOREIGN KEY(product_id) REFERENCES products(id));
    CREATE TABLE IF NOT EXISTS app_settings(key TEXT PRIMARY KEY,value TEXT);
    CREATE TABLE IF NOT EXISTS custom_providers(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT UNIQUE NOT NULL,created_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS notifications(id INTEGER PRIMARY KEY AUTOINCREMENT,title TEXT NOT NULL,message TEXT NOT NULL,level TEXT NOT NULL DEFAULT 'INFO',read_flag INTEGER NOT NULL DEFAULT 0,created_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS transfers(id INTEGER PRIMARY KEY AUTOINCREMENT,amount REAL NOT NULL,reference TEXT,note TEXT,status TEXT NOT NULL DEFAULT 'PENDING',created_by TEXT,created_at TEXT NOT NULL,confirmed_at TEXT,confirmed_by TEXT);
    ''')
    cols={x['name'] for x in cur.execute("PRAGMA table_info(cash_sessions)").fetchall()}
    for name,decl in [
        ('declared_transfers','REAL'),('expected_transfers','REAL'),('transfer_difference','REAL'),
        ('declared_card','REAL'),('expected_card','REAL'),('card_difference','REAL'),
        ('declared_withdrawals','REAL'),('expected_withdrawals','REAL'),('withdrawal_difference','REAL'),
        ('cut_note','TEXT')
    ]:
        if name not in cols: cur.execute(f"ALTER TABLE cash_sessions ADD COLUMN {name} {decl}")
    if cur.execute('SELECT COUNT(*) c FROM users').fetchone()['c']==0:
        cur.executemany('INSERT INTO users(name,role,pin_hash,created_at) VALUES(?,?,?,?)',[('ADMIN','ADMIN',pin_hash('1234'),now()),('CAJERO 1','CAJERO',pin_hash('1111'),now()),('CAJERO 2','CAJERO',pin_hash('2222'),now())])
    if cur.execute('SELECT COUNT(*) c FROM products').fetchone()['c']==0:
        t=now();cur.executemany('INSERT INTO products(barcode,name,provider,presentation,category,supplier_price,sale_price,stock,min_stock,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?)',[
        ('7501013101234','Coca Cola 600 ml','COCA COLA','600 ml','REFRESCOS',14,20,30,10,t,t),('7500478022047','Pepsi 600 ml','PEPSI','600 ml','REFRESCOS',13,19,25,8,t,t),('7501055300887','Sabritas Original 170 g','SABRITAS','170 g','BOTANAS',30,42,18,6,t,t)])
    # Catalogo inicial SUPER-UNI v0.5.9: inserta productos aprobados sin borrar ni duplicar los existentes.
    catalog=[('Bonafont 600 ml', 'BONAFONT', '600 ml', 'BEBIDAS', 10, 13), ('Bonafont 1 L', 'BONAFONT', '1 L', 'BEBIDAS', 10.8, 15), ('Bonafont 1.5 L', 'BONAFONT', '1.5 L', 'BEBIDAS', 12.5, 18), ('Bonafont Té 500 ml', 'BONAFONT', 'Té 500 ml', 'BEBIDAS', 14.3, 22), ('Bonafont Jugo Jamaica 1 L', 'BONAFONT', '1 L', 'BEBIDAS', 17.5, 22), ('Bonafont Jugo Naranja 1 L', 'BONAFONT', '1 L', 'BEBIDAS', 17.5, 22), ('Bonafont Jugo Limón 1 L', 'BONAFONT', '1 L', 'BEBIDAS', 17.5, 22), ('Bonafont Jugo Piña 1 L', 'BONAFONT', '1 L', 'BEBIDAS', 17.5, 22), ('Bonafont Jugo Mango 1 L', 'BONAFONT', '1 L', 'BEBIDAS', 17.5, 22), ('Bonafont Jugo Tamarindo 1 L', 'BONAFONT', '1 L', 'BEBIDAS', 17.5, 22), ('Bonafont Jugo Guayaba 1 L', 'BONAFONT', '1 L', 'BEBIDAS', 17.5, 22), ('Bonafont Jugo Jamaica 1.4 L', 'BONAFONT', '1.4 L', 'BEBIDAS', 19.2, 25), ('Bonafont Jugo Mango 1.4 L', 'BONAFONT', '1.4 L', 'BEBIDAS', 19.2, 25), ('Bonafont Jugo Naranja 1.4 L', 'BONAFONT', '1.4 L', 'BEBIDAS', 19.2, 25), ('Bonafont Jugo Guayaba 1.4 L', 'BONAFONT', '1.4 L', 'BEBIDAS', 19.2, 25), ('Levité Pepino-Limón 1 L', 'BONAFONT', '1 L', 'BEBIDAS', 18.3, 22), ('Levité Piña-Coco 1 L', 'BONAFONT', '1 L', 'BEBIDAS', 18.3, 22), ('Levité Frutos Rojos 1 L', 'BONAFONT', '1 L', 'BEBIDAS', 18.3, 22), ('Levité Jamaica 1 L', 'BONAFONT', '1 L', 'BEBIDAS', 18.3, 22), ('Levité Pepino-Limón 1.4 L', 'BONAFONT', '1.4 L', 'BEBIDAS', 20.8, 25), ('Levité Piña-Coco 1.4 L', 'BONAFONT', '1.4 L', 'BEBIDAS', 20.8, 25), ('Levité Frutos Rojos 1.4 L', 'BONAFONT', '1.4 L', 'BEBIDAS', 20.8, 25), ('Levité Jamaica 1.4 L', 'BONAFONT', '1.4 L', 'BEBIDAS', 20.8, 25), ('Sabritas RC Sal', 'SABRITAS', '57 g', 'BOTANAS', 17.12, 20), ('Sabritas R.C Jalapeño', 'SABRITAS', '57 g', 'BOTANAS', 17.12, 20), ('Sabritas RC FH', 'SABRITAS', '57 g', 'BOTANAS', 17.12, 20), ('Sabritas Sal', 'SABRITAS', '45 g', 'BOTANAS', 17.12, 20), ('Sabritas C & E', 'SABRITAS', '42 g', 'BOTANAS', 17.12, 20), ('Sabritas Limón', 'SABRITAS', '42 g', 'BOTANAS', 17.12, 20), ('Sabritas FH', 'SABRITAS', '42 g', 'BOTANAS', 17.12, 20), ('Sabritas Adobadas', 'SABRITAS', '42 g', 'BOTANAS', 17.12, 20), ('Sabritas Habanero', 'SABRITAS', '42 g', 'BOTANAS', 17.12, 20), ('Mega Crunch Jalapeño', 'SABRITAS', '42 g', 'BOTANAS', 17.12, 20), ('Mega Crunch Salsa Roja', 'SABRITAS', '42 g', 'BOTANAS', 17.12, 20), ('Mega Crunch FH', 'SABRITAS', '42 g', 'BOTANAS', 17.12, 20), ('Ruffles Sal', 'SABRITAS', '48 g', 'BOTANAS', 17.12, 20), ('Ruffles Queso', 'SABRITAS', '48 g', 'BOTANAS', 17.12, 20), ('Doritos Nacho', 'SABRITAS', '58 g', 'BOTANAS', 17.12, 20), ('Doritos Incógnita', 'SABRITAS', '58 g', 'BOTANAS', 17.12, 20), ('Doritos Pizzerola', 'SABRITAS', '58 g', 'BOTANAS', 17.12, 20), ('Doritos 3D', 'SABRITAS', '50 g', 'BOTANAS', 17.12, 20), ('Doritos Flamin Hot', 'SABRITAS', '58 g', 'BOTANAS', 17.12, 20), ('Doritos Dinamita', 'SABRITAS', '70 g', 'BOTANAS', 17.12, 20), ('Dorito Dinamita FH', 'SABRITAS', '70 g', 'BOTANAS', 17.12, 20), ('Doritos Diablo', 'SABRITAS', '58 g', 'BOTANAS', 17.12, 20), ('Tostito Salsa Verde', 'SABRITAS', '62 g', 'BOTANAS', 17.12, 20), ('Tostito FH', 'SABRITAS', '62 g', 'BOTANAS', 17.12, 20), ('Fritos Chile y Limón', 'SABRITAS', '60 g', 'BOTANAS', 15.41, 18), ('Fritos Sal', 'SABRITAS', '60 g', 'BOTANAS', 15.41, 18), ('Fritos Chorizo y Chipotle', 'SABRITAS', '60 g', 'BOTANAS', 15.41, 18), ('Frito FH', 'SABRITAS', '70 g', 'BOTANAS', 15.41, 18), ('Cheetos Torcidito', 'SABRITAS', '55 g', 'BOTANAS', 14.55, 17), ('Cheetos Flamin Hot', 'SABRITAS', '52 g', 'BOTANAS', 14.55, 17), ('Cheetos Nacho', 'SABRITAS', '58 g', 'BOTANAS', 14.55, 17), ('Cheetos Bolita', 'SABRITAS', '46 g', 'BOTANAS', 14.55, 17), ('Cheetos Colmillo', 'SABRITAS', '27 g', 'BOTANAS', 14.55, 17), ('Cheetos Palomitas', 'SABRITAS', '29 g', 'BOTANAS', 14.55, 17), ('Cheetos Poffs', 'SABRITAS', '44 g', 'BOTANAS', 14.55, 17), ('Cheetos Poff FH', 'SABRITAS', '42 g', 'BOTANAS', 14.55, 17), ('Paketaxo Botanero', 'SABRITAS', '81 g', 'BOTANAS', 18.84, 22), ('Paketaxo Mezcladito', 'SABRITAS', '81 g', 'BOTANAS', 18.84, 22), ('Paketaxo Xtra FH', 'SABRITAS', '81 g', 'BOTANAS', 18.84, 22), ('Paketaxo Quexo', 'SABRITAS', '81 g', 'BOTANAS', 18.84, 22), ('Churrumais Limón', 'SABRITAS', '70 g', 'BOTANAS', 14.55, 17), ('Churrumais FH', 'SABRITAS', '70 g', 'BOTANAS', 14.55, 17), ('Chicharrón de Cerdo', 'SABRITAS', '30 g', 'BOTANAS', 17.12, 20), ('Rancheritos', 'SABRITAS', '58 g', 'BOTANAS', 15.41, 18), ('Crujitos', 'SABRITAS', '42 g', 'BOTANAS', 15.41, 18), ('Sabritones', 'SABRITAS', '60 g', 'BOTANAS', 12.8, 16), ('Crujito FH', 'SABRITAS', '40 g', 'BOTANAS', 8.56, 10), ('Cheetos mix', 'SABRITAS', '41 g', 'BOTANAS', 8.56, 10), ('Paketaxo Queso', 'SABRITAS', '35 g', 'BOTANAS', 8.56, 10), ('Paketaxo Dark', 'SABRITAS', '44 g', 'BOTANAS', 8.56, 10), ('Pizzerolas', 'SABRITAS', '41 g', 'BOTANAS', 12.84, 15), ('Quesabritas', 'SABRITAS', '40 g', 'BOTANAS', 12.84, 15), ('Bolzaza', 'SABRITAS', '', 'BOTANAS', 21.35, 25), ('Mantecadas Nuez 6p', 'BIMBO', '184 g', 'PAN/GALLETAS', 26.56, 32), ('Mantecadas Vainilla 6p', 'BIMBO', '188 g', 'PAN/GALLETAS', 26.56, 32), ('Panquecitos Gota de Chocolate 2p', 'BIMBO', '140 g', 'PAN/GALLETAS', 18.26, 22), ('Rebanadas', 'BIMBO', '55 g', 'PAN/GALLETAS', 8.3, 10), ('Roles Canela 3p', 'BIMBO', '180 g', 'PAN/GALLETAS', 20.75, 25), ('Roles Glass 3p', 'BIMBO', '205 g', 'PAN/GALLETAS', 20.75, 25), ('Chocotorro', 'BIMBO', '50 g', 'PAN/GALLETAS', 12.45, 15), ('Dálmata', 'BIMBO', '55 g', 'PAN/GALLETAS', 12.45, 15), ('Twinkies Vainilla 3p', 'BIMBO', '114 g', 'PAN/GALLETAS', 15.77, 19), ('Twinkies Chocolate 3p', 'BIMBO', '114 g', 'PAN/GALLETAS', 15.77, 19), ('Bran Frut Fresa', 'BIMBO', '58 g', 'PAN/GALLETAS', 9.96, 12), ('Bran Frut Piña', 'BIMBO', '58 g', 'PAN/GALLETAS', 9.96, 12), ('Barritas Fresa', 'BIMBO', '75 g', 'PAN/GALLETAS', 15.12, 18), ('Barritas Moras', 'BIMBO', '75 g', 'PAN/GALLETAS', 15.12, 18), ('Barritas Piña', 'BIMBO', '75 g', 'PAN/GALLETAS', 15.12, 18), ('Bombonete', 'BIMBO', '55 g', 'PAN/GALLETAS', 12.6, 15), ('Canelitas', 'BIMBO', '120 g +2p', 'PAN/GALLETAS', 20.16, 24), ('Fruti Sponch 8p', 'BIMBO', '124 g', 'PAN/GALLETAS', 20.16, 24), ('Platívolos', 'BIMBO', '90 g', 'PAN/GALLETAS', 16.8, 20), ('Polvorones 6p', 'BIMBO', '148 g +2p', 'PAN/GALLETAS', 20.16, 24), ('Rocko', 'BIMBO', '44 g', 'PAN/GALLETAS', 8.4, 10), ('Sponch', 'BIMBO', '120 g', 'PAN/GALLETAS', 18.48, 22), ('Príncipe Chocolate 12p +2p', 'BIMBO', '126 g', 'PAN/GALLETAS', 20.16, 24), ('Príncipe Avellana 12p +2p', 'BIMBO', '126 g', 'PAN/GALLETAS', 20.16, 24), ('Príncipe Chocolate Blanco 12p +2p', 'BIMBO', '126 g', 'PAN/GALLETAS', 20.16, 24), ('Príncipe Limón 12p +2p', 'BIMBO', '126 g', 'PAN/GALLETAS', 20.16, 24), ('MaxiTubos Príncipe', 'BIMBO', '', 'PAN/GALLETAS', 26.88, 32), ('MaxiTubos Triki Trakes', 'BIMBO', '', 'PAN/GALLETAS', 26.88, 32), ('MaxiTubos Canelitas', 'BIMBO', '', 'PAN/GALLETAS', 26.88, 32), ('MaxiTubos Sponch', 'BIMBO', '', 'PAN/GALLETAS', 26.88, 32), ('MaxiTubos Polvorones', 'BIMBO', '', 'PAN/GALLETAS', 26.88, 32), ('MaxiTubos Mini Barritas Fresa', 'BIMBO', '', 'PAN/GALLETAS', 26.88, 32), ('MaxiTubos Mini Barritas Piña', 'BIMBO', '', 'PAN/GALLETAS', 26.88, 32), ('Choco Roles 25pct más 2p', 'BIMBO', '100 g', 'PAN/GALLETAS', 18.26, 22), ('Dúo Mini Pay Piña', 'BIMBO', '110 g', 'PAN/GALLETAS', 20.75, 25), ('Dúo Mini Pay Nuez', 'BIMBO', '96 g', 'PAN/GALLETAS', 20.75, 25), ('Dúo Napolitano', 'BIMBO', '140 g', 'PAN/GALLETAS', 20.75, 25), ('Mini Choco Roles', 'BIMBO', '28 g', 'PAN/GALLETAS', 6.64, 8), ('Mini Gansito', 'BIMBO', '24 g', 'PAN/GALLETAS', 6.64, 8), ("Pastelito Hershey's 1p", 'BIMBO', '40 g', 'PAN/GALLETAS', 11.62, 14), ('Rollo Fresa', 'BIMBO', '75 g', 'PAN/GALLETAS', 14.94, 18), ('Leche Gansito', 'BIMBO', '236 ml', 'PAN/GALLETAS', 12.45, 15), ('Leche Nito', 'BIMBO', '236 ml', 'PAN/GALLETAS', 12.45, 15), ('Submarinos Chocolate', 'BIMBO', '105 g', 'PAN/GALLETAS', 16.6, 20), ('Submarinos Fresa', 'BIMBO', '105 g', 'PAN/GALLETAS', 16.6, 20), ('Submarinos Vainilla', 'BIMBO', '105 g', 'PAN/GALLETAS', 16.6, 20), ('Bigotes Cajeta', 'BIMBO', '80 g', 'PAN/GALLETAS', 13.28, 16), ('Bigotes Chocolate', 'BIMBO', '80 g', 'PAN/GALLETAS', 13.28, 16), ('Doraditas Nuez', 'BIMBO', '127 g', 'PAN/GALLETAS', 14.94, 18), ('Madalenas Cuadradas', 'BIMBO', '44 g', 'PAN/GALLETAS', 8.3, 10), ('Mantecadas Vainilla 3p', 'BIMBO', '157 g', 'PAN/GALLETAS', 21.58, 26), ('Mantecadas Chocolate 3p', 'BIMBO', '143 g', 'PAN/GALLETAS', 21.58, 26), ('Mantecadas Naranja 3p', 'BIMBO', '165 g', 'PAN/GALLETAS', 21.58, 26), ('Mini Divididas en Tiras Doraditas', 'BIMBO', '58 g', 'PAN/GALLETAS', 8.3, 10), ('Galleta con Avena Arándano', 'BIMBO', '66 g', 'PAN/GALLETAS', 10.08, 12), ('Pastisetas Suandy', 'BIMBO', '90 g', 'PAN/GALLETAS', 23.52, 28), ('Tartinas Fresa 8p', 'BIMBO', '133.3 g', 'PAN/GALLETAS', 16.8, 20), ('Tartinas Piña 8p', 'BIMBO', '133.3 g', 'PAN/GALLETAS', 16.8, 20), ('Tartinas Zarzamora 8p', 'BIMBO', '133.3 g', 'PAN/GALLETAS', 16.8, 20), ('Deliciosas Chocochispas', 'BIMBO', '60 g', 'PAN/GALLETAS', 8.4, 10), ('Deliciosas Vainilla', 'BIMBO', '60 g', 'PAN/GALLETAS', 8.4, 10), ('Deliciosas Chocochispas', 'BIMBO', '130 g', 'PAN/GALLETAS', 16.8, 20), ('Deliciosas Vainilla', 'BIMBO', '130 g', 'PAN/GALLETAS', 16.8, 20), ('CAJ Lucky Strike XL Click & Mix', 'CIGARROS', '20s', 'CIGARROS', 100.37, 106), ('Lucky Strike XL Click & Mix Suelto', 'CIGARROS', '1 cigarro', 'CIGARROS', 5.0185, 8), ('CAJ Lucky Strike XL Indigo Wild', 'CIGARROS', '20s', 'CIGARROS', 100.37, 106), ('Lucky Strike XL Indigo Wild Suelto', 'CIGARROS', '1 cigarro', 'CIGARROS', 5.0185, 8), ('CAJ Lucky Strike XL Enigma', 'CIGARROS', '20s', 'CIGARROS', 92.8, 98), ('Lucky Strike XL Enigma Suelto', 'CIGARROS', '1 cigarro', 'CIGARROS', 4.64, 8), ('CAJ Lucky Strike XL Comet', 'CIGARROS', '20s', 'CIGARROS', 92.8, 98), ('Lucky Strike XL Comet Suelto', 'CIGARROS', '1 cigarro', 'CIGARROS', 4.64, 8), ('CAJ Pall Mall XL Alaska', 'CIGARROS', '20s', 'CIGARROS', 92.8, 98), ('Pall Mall XL Alaska Suelto', 'CIGARROS', '1 cigarro', 'CIGARROS', 4.64, 8), ('CAJ Pall Mall XL Tokyo', 'CIGARROS', '20s', 'CIGARROS', 92.8, 98), ('Pall Mall XL Tokyo Suelto', 'CIGARROS', '1 cigarro', 'CIGARROS', 4.64, 8), ('CAJ Pall Mall XL Mykonos', 'CIGARROS', '20s', 'CIGARROS', 92.8, 98), ('Pall Mall XL Mykonos Suelto', 'CIGARROS', '1 cigarro', 'CIGARROS', 4.64, 8), ('CAJ Pall Mall XL Rio', 'CIGARROS', '20s', 'CIGARROS', 92.8, 98), ('Pall Mall XL Rio Suelto', 'CIGARROS', '1 cigarro', 'CIGARROS', 4.64, 8), ('CAJ Pall Mall XL Manila', 'CIGARROS', '20s', 'CIGARROS', 92.8, 98), ('Pall Mall XL Manila Suelto', 'CIGARROS', '1 cigarro', 'CIGARROS', 4.64, 8), ('CAJ Pall Mall XL Hawaii', 'CIGARROS', '20s', 'CIGARROS', 92.8, 98), ('Pall Mall XL Hawaii Suelto', 'CIGARROS', '1 cigarro', 'CIGARROS', 4.64, 8), ('CAJ Pall Mall XL London', 'CIGARROS', '20s', 'CIGARROS', 92.8, 98), ('Pall Mall XL London Suelto', 'CIGARROS', '1 cigarro', 'CIGARROS', 4.64, 8), ('CAJ Pall Mall XL Bora Bora', 'CIGARROS', '20s', 'CIGARROS', 92.8, 98), ('Pall Mall XL Bora Bora Suelto', 'CIGARROS', '1 cigarro', 'CIGARROS', 4.64, 8), ('CAJ Pall Mall XL New York', 'CIGARROS', '20s', 'CIGARROS', 92.8, 98), ('Pall Mall XL New York Suelto', 'CIGARROS', '1 cigarro', 'CIGARROS', 4.64, 8), ('CAJ Pall Mall XL Miami', 'CIGARROS', '20s', 'CIGARROS', 92.8, 98), ('Pall Mall XL Miami Suelto', 'CIGARROS', '1 cigarro', 'CIGARROS', 4.64, 8), ('CAJ Montana Clásicos', 'CIGARROS', '25s', 'CIGARROS', 45.94, 50), ('Montana Clásicos Suelto', 'CIGARROS', '1 cigarro', 'CIGARROS', 1.8376, 6), ('CAJ Boots Clásicos', 'CIGARROS', '25s', 'CIGARROS', 45.94, 50), ('Boots Clásicos Suelto', 'CIGARROS', '1 cigarro', 'CIGARROS', 1.8376, 6)]
    t=now()
    for name,provider,presentation,category,supplier_price,sale_price in catalog:
        if not cur.execute('SELECT 1 FROM products WHERE name=? AND provider=?',(name,provider)).fetchone():
            cur.execute('INSERT INTO products(barcode,name,provider,presentation,category,supplier_price,sale_price,stock,min_stock,created_at,updated_at) VALUES(NULL,?,?,?,?,?,?,0,0,?,?)',(name,provider,presentation,category,supplier_price,sale_price,t,t))
    # Catalogo inicial SUPER-UNI v0.5.9: inserta productos aprobados sin borrar ni duplicar los existentes.
    catalog=[('Bonafont 600 ml', 'BONAFONT', '600 ml', 'BEBIDAS', 10, 13), ('Bonafont 1 L', 'BONAFONT', '1 L', 'BEBIDAS', 10.8, 15), ('Bonafont 1.5 L', 'BONAFONT', '1.5 L', 'BEBIDAS', 12.5, 18), ('Bonafont Té 500 ml', 'BONAFONT', 'Té 500 ml', 'BEBIDAS', 14.3, 22), ('Bonafont Jugo Jamaica 1 L', 'BONAFONT', '1 L', 'BEBIDAS', 17.5, 22), ('Bonafont Jugo Naranja 1 L', 'BONAFONT', '1 L', 'BEBIDAS', 17.5, 22), ('Bonafont Jugo Limón 1 L', 'BONAFONT', '1 L', 'BEBIDAS', 17.5, 22), ('Bonafont Jugo Piña 1 L', 'BONAFONT', '1 L', 'BEBIDAS', 17.5, 22), ('Bonafont Jugo Mango 1 L', 'BONAFONT', '1 L', 'BEBIDAS', 17.5, 22), ('Bonafont Jugo Tamarindo 1 L', 'BONAFONT', '1 L', 'BEBIDAS', 17.5, 22), ('Bonafont Jugo Guayaba 1 L', 'BONAFONT', '1 L', 'BEBIDAS', 17.5, 22), ('Bonafont Jugo Jamaica 1.4 L', 'BONAFONT', '1.4 L', 'BEBIDAS', 19.2, 25), ('Bonafont Jugo Mango 1.4 L', 'BONAFONT', '1.4 L', 'BEBIDAS', 19.2, 25), ('Bonafont Jugo Naranja 1.4 L', 'BONAFONT', '1.4 L', 'BEBIDAS', 19.2, 25), ('Bonafont Jugo Guayaba 1.4 L', 'BONAFONT', '1.4 L', 'BEBIDAS', 19.2, 25), ('Levité Pepino-Limón 1 L', 'BONAFONT', '1 L', 'BEBIDAS', 18.3, 22), ('Levité Piña-Coco 1 L', 'BONAFONT', '1 L', 'BEBIDAS', 18.3, 22), ('Levité Frutos Rojos 1 L', 'BONAFONT', '1 L', 'BEBIDAS', 18.3, 22), ('Levité Jamaica 1 L', 'BONAFONT', '1 L', 'BEBIDAS', 18.3, 22), ('Levité Pepino-Limón 1.4 L', 'BONAFONT', '1.4 L', 'BEBIDAS', 20.8, 25), ('Levité Piña-Coco 1.4 L', 'BONAFONT', '1.4 L', 'BEBIDAS', 20.8, 25), ('Levité Frutos Rojos 1.4 L', 'BONAFONT', '1.4 L', 'BEBIDAS', 20.8, 25), ('Levité Jamaica 1.4 L', 'BONAFONT', '1.4 L', 'BEBIDAS', 20.8, 25), ('Sabritas RC Sal', 'SABRITAS', '57 g', 'BOTANAS', 17.12, 20), ('Sabritas R.C Jalapeño', 'SABRITAS', '57 g', 'BOTANAS', 17.12, 20), ('Sabritas RC FH', 'SABRITAS', '57 g', 'BOTANAS', 17.12, 20), ('Sabritas Sal', 'SABRITAS', '45 g', 'BOTANAS', 17.12, 20), ('Sabritas C & E', 'SABRITAS', '42 g', 'BOTANAS', 17.12, 20), ('Sabritas Limón', 'SABRITAS', '42 g', 'BOTANAS', 17.12, 20), ('Sabritas FH', 'SABRITAS', '42 g', 'BOTANAS', 17.12, 20), ('Sabritas Adobadas', 'SABRITAS', '42 g', 'BOTANAS', 17.12, 20), ('Sabritas Habanero', 'SABRITAS', '42 g', 'BOTANAS', 17.12, 20), ('Mega Crunch Jalapeño', 'SABRITAS', '42 g', 'BOTANAS', 17.12, 20), ('Mega Crunch Salsa Roja', 'SABRITAS', '42 g', 'BOTANAS', 17.12, 20), ('Mega Crunch FH', 'SABRITAS', '42 g', 'BOTANAS', 17.12, 20), ('Ruffles Sal', 'SABRITAS', '48 g', 'BOTANAS', 17.12, 20), ('Ruffles Queso', 'SABRITAS', '48 g', 'BOTANAS', 17.12, 20), ('Doritos Nacho', 'SABRITAS', '58 g', 'BOTANAS', 17.12, 20), ('Doritos Incógnita', 'SABRITAS', '58 g', 'BOTANAS', 17.12, 20), ('Doritos Pizzerola', 'SABRITAS', '58 g', 'BOTANAS', 17.12, 20), ('Doritos 3D', 'SABRITAS', '50 g', 'BOTANAS', 17.12, 20), ('Doritos Flamin Hot', 'SABRITAS', '58 g', 'BOTANAS', 17.12, 20), ('Doritos Dinamita', 'SABRITAS', '70 g', 'BOTANAS', 17.12, 20), ('Dorito Dinamita FH', 'SABRITAS', '70 g', 'BOTANAS', 17.12, 20), ('Doritos Diablo', 'SABRITAS', '58 g', 'BOTANAS', 17.12, 20), ('Tostito Salsa Verde', 'SABRITAS', '62 g', 'BOTANAS', 17.12, 20), ('Tostito FH', 'SABRITAS', '62 g', 'BOTANAS', 17.12, 20), ('Fritos Chile y Limón', 'SABRITAS', '60 g', 'BOTANAS', 15.41, 18), ('Fritos Sal', 'SABRITAS', '60 g', 'BOTANAS', 15.41, 18), ('Fritos Chorizo y Chipotle', 'SABRITAS', '60 g', 'BOTANAS', 15.41, 18), ('Frito FH', 'SABRITAS', '70 g', 'BOTANAS', 15.41, 18), ('Cheetos Torcidito', 'SABRITAS', '55 g', 'BOTANAS', 14.55, 17), ('Cheetos Flamin Hot', 'SABRITAS', '52 g', 'BOTANAS', 14.55, 17), ('Cheetos Nacho', 'SABRITAS', '58 g', 'BOTANAS', 14.55, 17), ('Cheetos Bolita', 'SABRITAS', '46 g', 'BOTANAS', 14.55, 17), ('Cheetos Colmillo', 'SABRITAS', '27 g', 'BOTANAS', 14.55, 17), ('Cheetos Palomitas', 'SABRITAS', '29 g', 'BOTANAS', 14.55, 17), ('Cheetos Poffs', 'SABRITAS', '44 g', 'BOTANAS', 14.55, 17), ('Cheetos Poff FH', 'SABRITAS', '42 g', 'BOTANAS', 14.55, 17), ('Paketaxo Botanero', 'SABRITAS', '81 g', 'BOTANAS', 18.84, 22), ('Paketaxo Mezcladito', 'SABRITAS', '81 g', 'BOTANAS', 18.84, 22), ('Paketaxo Xtra FH', 'SABRITAS', '81 g', 'BOTANAS', 18.84, 22), ('Paketaxo Quexo', 'SABRITAS', '81 g', 'BOTANAS', 18.84, 22), ('Churrumais Limón', 'SABRITAS', '70 g', 'BOTANAS', 14.55, 17), ('Churrumais FH', 'SABRITAS', '70 g', 'BOTANAS', 14.55, 17), ('Chicharrón de Cerdo', 'SABRITAS', '30 g', 'BOTANAS', 17.12, 20), ('Rancheritos', 'SABRITAS', '58 g', 'BOTANAS', 15.41, 18), ('Crujitos', 'SABRITAS', '42 g', 'BOTANAS', 15.41, 18), ('Sabritones', 'SABRITAS', '60 g', 'BOTANAS', 12.8, 16), ('Crujito FH', 'SABRITAS', '40 g', 'BOTANAS', 8.56, 10), ('Cheetos mix', 'SABRITAS', '41 g', 'BOTANAS', 8.56, 10), ('Paketaxo Queso', 'SABRITAS', '35 g', 'BOTANAS', 8.56, 10), ('Paketaxo Dark', 'SABRITAS', '44 g', 'BOTANAS', 8.56, 10), ('Pizzerolas', 'SABRITAS', '41 g', 'BOTANAS', 12.84, 15), ('Quesabritas', 'SABRITAS', '40 g', 'BOTANAS', 12.84, 15), ('Bolzaza', 'SABRITAS', '', 'BOTANAS', 21.35, 25), ('Mantecadas Nuez 6p', 'BIMBO', '184 g', 'PAN/GALLETAS', 26.56, 32), ('Mantecadas Vainilla 6p', 'BIMBO', '188 g', 'PAN/GALLETAS', 26.56, 32), ('Panquecitos Gota de Chocolate 2p', 'BIMBO', '140 g', 'PAN/GALLETAS', 18.26, 22), ('Rebanadas', 'BIMBO', '55 g', 'PAN/GALLETAS', 8.3, 10), ('Roles Canela 3p', 'BIMBO', '180 g', 'PAN/GALLETAS', 20.75, 25), ('Roles Glass 3p', 'BIMBO', '205 g', 'PAN/GALLETAS', 20.75, 25), ('Chocotorro', 'BIMBO', '50 g', 'PAN/GALLETAS', 12.45, 15), ('Dálmata', 'BIMBO', '55 g', 'PAN/GALLETAS', 12.45, 15), ('Twinkies Vainilla 3p', 'BIMBO', '114 g', 'PAN/GALLETAS', 15.77, 19), ('Twinkies Chocolate 3p', 'BIMBO', '114 g', 'PAN/GALLETAS', 15.77, 19), ('Bran Frut Fresa', 'BIMBO', '58 g', 'PAN/GALLETAS', 9.96, 12), ('Bran Frut Piña', 'BIMBO', '58 g', 'PAN/GALLETAS', 9.96, 12), ('Barritas Fresa', 'BIMBO', '75 g', 'PAN/GALLETAS', 15.12, 18), ('Barritas Moras', 'BIMBO', '75 g', 'PAN/GALLETAS', 15.12, 18), ('Barritas Piña', 'BIMBO', '75 g', 'PAN/GALLETAS', 15.12, 18), ('Bombonete', 'BIMBO', '55 g', 'PAN/GALLETAS', 12.6, 15), ('Canelitas', 'BIMBO', '120 g +2p', 'PAN/GALLETAS', 20.16, 24), ('Fruti Sponch 8p', 'BIMBO', '124 g', 'PAN/GALLETAS', 20.16, 24), ('Platívolos', 'BIMBO', '90 g', 'PAN/GALLETAS', 16.8, 20), ('Polvorones 6p', 'BIMBO', '148 g +2p', 'PAN/GALLETAS', 20.16, 24), ('Rocko', 'BIMBO', '44 g', 'PAN/GALLETAS', 8.4, 10), ('Sponch', 'BIMBO', '120 g', 'PAN/GALLETAS', 18.48, 22), ('Príncipe Chocolate 12p +2p', 'BIMBO', '126 g', 'PAN/GALLETAS', 20.16, 24), ('Príncipe Avellana 12p +2p', 'BIMBO', '126 g', 'PAN/GALLETAS', 20.16, 24), ('Príncipe Chocolate Blanco 12p +2p', 'BIMBO', '126 g', 'PAN/GALLETAS', 20.16, 24), ('Príncipe Limón 12p +2p', 'BIMBO', '126 g', 'PAN/GALLETAS', 20.16, 24), ('MaxiTubos Príncipe', 'BIMBO', '', 'PAN/GALLETAS', 26.88, 32), ('MaxiTubos Triki Trakes', 'BIMBO', '', 'PAN/GALLETAS', 26.88, 32), ('MaxiTubos Canelitas', 'BIMBO', '', 'PAN/GALLETAS', 26.88, 32), ('MaxiTubos Sponch', 'BIMBO', '', 'PAN/GALLETAS', 26.88, 32), ('MaxiTubos Polvorones', 'BIMBO', '', 'PAN/GALLETAS', 26.88, 32), ('MaxiTubos Mini Barritas Fresa', 'BIMBO', '', 'PAN/GALLETAS', 26.88, 32), ('MaxiTubos Mini Barritas Piña', 'BIMBO', '', 'PAN/GALLETAS', 26.88, 32), ('Choco Roles 25pct más 2p', 'BIMBO', '100 g', 'PAN/GALLETAS', 18.26, 22), ('Dúo Mini Pay Piña', 'BIMBO', '110 g', 'PAN/GALLETAS', 20.75, 25), ('Dúo Mini Pay Nuez', 'BIMBO', '96 g', 'PAN/GALLETAS', 20.75, 25), ('Dúo Napolitano', 'BIMBO', '140 g', 'PAN/GALLETAS', 20.75, 25), ('Mini Choco Roles', 'BIMBO', '28 g', 'PAN/GALLETAS', 6.64, 8), ('Mini Gansito', 'BIMBO', '24 g', 'PAN/GALLETAS', 6.64, 8), ("Pastelito Hershey's 1p", 'BIMBO', '40 g', 'PAN/GALLETAS', 11.62, 14), ('Rollo Fresa', 'BIMBO', '75 g', 'PAN/GALLETAS', 14.94, 18), ('Leche Gansito', 'BIMBO', '236 ml', 'PAN/GALLETAS', 12.45, 15), ('Leche Nito', 'BIMBO', '236 ml', 'PAN/GALLETAS', 12.45, 15), ('Submarinos Chocolate', 'BIMBO', '105 g', 'PAN/GALLETAS', 16.6, 20), ('Submarinos Fresa', 'BIMBO', '105 g', 'PAN/GALLETAS', 16.6, 20), ('Submarinos Vainilla', 'BIMBO', '105 g', 'PAN/GALLETAS', 16.6, 20), ('Bigotes Cajeta', 'BIMBO', '80 g', 'PAN/GALLETAS', 13.28, 16), ('Bigotes Chocolate', 'BIMBO', '80 g', 'PAN/GALLETAS', 13.28, 16), ('Doraditas Nuez', 'BIMBO', '127 g', 'PAN/GALLETAS', 14.94, 18), ('Madalenas Cuadradas', 'BIMBO', '44 g', 'PAN/GALLETAS', 8.3, 10), ('Mantecadas Vainilla 3p', 'BIMBO', '157 g', 'PAN/GALLETAS', 21.58, 26), ('Mantecadas Chocolate 3p', 'BIMBO', '143 g', 'PAN/GALLETAS', 21.58, 26), ('Mantecadas Naranja 3p', 'BIMBO', '165 g', 'PAN/GALLETAS', 21.58, 26), ('Mini Divididas en Tiras Doraditas', 'BIMBO', '58 g', 'PAN/GALLETAS', 8.3, 10), ('Galleta con Avena Arándano', 'BIMBO', '66 g', 'PAN/GALLETAS', 10.08, 12), ('Pastisetas Suandy', 'BIMBO', '90 g', 'PAN/GALLETAS', 23.52, 28), ('Tartinas Fresa 8p', 'BIMBO', '133.3 g', 'PAN/GALLETAS', 16.8, 20), ('Tartinas Piña 8p', 'BIMBO', '133.3 g', 'PAN/GALLETAS', 16.8, 20), ('Tartinas Zarzamora 8p', 'BIMBO', '133.3 g', 'PAN/GALLETAS', 16.8, 20), ('Deliciosas Chocochispas', 'BIMBO', '60 g', 'PAN/GALLETAS', 8.4, 10), ('Deliciosas Vainilla', 'BIMBO', '60 g', 'PAN/GALLETAS', 8.4, 10), ('Deliciosas Chocochispas', 'BIMBO', '130 g', 'PAN/GALLETAS', 16.8, 20), ('Deliciosas Vainilla', 'BIMBO', '130 g', 'PAN/GALLETAS', 16.8, 20), ('CAJ Lucky Strike XL Click & Mix', 'CIGARROS', '20s', 'CIGARROS', 100.37, 106), ('Lucky Strike XL Click & Mix Suelto', 'CIGARROS', '1 cigarro', 'CIGARROS', 5.0185, 8), ('CAJ Lucky Strike XL Indigo Wild', 'CIGARROS', '20s', 'CIGARROS', 100.37, 106), ('Lucky Strike XL Indigo Wild Suelto', 'CIGARROS', '1 cigarro', 'CIGARROS', 5.0185, 8), ('CAJ Lucky Strike XL Enigma', 'CIGARROS', '20s', 'CIGARROS', 92.8, 98), ('Lucky Strike XL Enigma Suelto', 'CIGARROS', '1 cigarro', 'CIGARROS', 4.64, 8), ('CAJ Lucky Strike XL Comet', 'CIGARROS', '20s', 'CIGARROS', 92.8, 98), ('Lucky Strike XL Comet Suelto', 'CIGARROS', '1 cigarro', 'CIGARROS', 4.64, 8), ('CAJ Pall Mall XL Alaska', 'CIGARROS', '20s', 'CIGARROS', 92.8, 98), ('Pall Mall XL Alaska Suelto', 'CIGARROS', '1 cigarro', 'CIGARROS', 4.64, 8), ('CAJ Pall Mall XL Tokyo', 'CIGARROS', '20s', 'CIGARROS', 92.8, 98), ('Pall Mall XL Tokyo Suelto', 'CIGARROS', '1 cigarro', 'CIGARROS', 4.64, 8), ('CAJ Pall Mall XL Mykonos', 'CIGARROS', '20s', 'CIGARROS', 92.8, 98), ('Pall Mall XL Mykonos Suelto', 'CIGARROS', '1 cigarro', 'CIGARROS', 4.64, 8), ('CAJ Pall Mall XL Rio', 'CIGARROS', '20s', 'CIGARROS', 92.8, 98), ('Pall Mall XL Rio Suelto', 'CIGARROS', '1 cigarro', 'CIGARROS', 4.64, 8), ('CAJ Pall Mall XL Manila', 'CIGARROS', '20s', 'CIGARROS', 92.8, 98), ('Pall Mall XL Manila Suelto', 'CIGARROS', '1 cigarro', 'CIGARROS', 4.64, 8), ('CAJ Pall Mall XL Hawaii', 'CIGARROS', '20s', 'CIGARROS', 92.8, 98), ('Pall Mall XL Hawaii Suelto', 'CIGARROS', '1 cigarro', 'CIGARROS', 4.64, 8), ('CAJ Pall Mall XL London', 'CIGARROS', '20s', 'CIGARROS', 92.8, 98), ('Pall Mall XL London Suelto', 'CIGARROS', '1 cigarro', 'CIGARROS', 4.64, 8), ('CAJ Pall Mall XL Bora Bora', 'CIGARROS', '20s', 'CIGARROS', 92.8, 98), ('Pall Mall XL Bora Bora Suelto', 'CIGARROS', '1 cigarro', 'CIGARROS', 4.64, 8), ('CAJ Pall Mall XL New York', 'CIGARROS', '20s', 'CIGARROS', 92.8, 98), ('Pall Mall XL New York Suelto', 'CIGARROS', '1 cigarro', 'CIGARROS', 4.64, 8), ('CAJ Pall Mall XL Miami', 'CIGARROS', '20s', 'CIGARROS', 92.8, 98), ('Pall Mall XL Miami Suelto', 'CIGARROS', '1 cigarro', 'CIGARROS', 4.64, 8), ('CAJ Montana Clásicos', 'CIGARROS', '25s', 'CIGARROS', 45.94, 50), ('Montana Clásicos Suelto', 'CIGARROS', '1 cigarro', 'CIGARROS', 1.8376, 6), ('CAJ Boots Clásicos', 'CIGARROS', '25s', 'CIGARROS', 45.94, 50), ('Boots Clásicos Suelto', 'CIGARROS', '1 cigarro', 'CIGARROS', 1.8376, 6)]
    t=now()
    for name,provider,presentation,category,supplier_price,sale_price in catalog:
        if not cur.execute('SELECT 1 FROM products WHERE name=? AND provider=?',(name,provider)).fetchone():
            cur.execute('INSERT INTO products(barcode,name,provider,presentation,category,supplier_price,sale_price,stock,min_stock,created_at,updated_at) VALUES(NULL,?,?,?,?,?,?,0,0,?,?)',(name,provider,presentation,category,supplier_price,sale_price,t,t))

    # Catalogo incremental SUPER-UNI v0.6.0: Barcel + Danone.
    catalog_v060=[('7503032606859', "Chip's Papatinas Chilix", 'BARCEL', '31 g', 'BOTANAS', 13.44, 16), ('7500810012284', "Chip's Papatinas Fuego", 'BARCEL', '31 g', 'BOTANAS', 13.44, 16), ('7500810024553', "Chip's Jalapeño", 'BARCEL', '52 g', 'BOTANAS', 16.8, 20), ('7500810024546', "Chip's Fuego", 'BARCEL', '52 g', 'BOTANAS', 16.8, 20), ('7500810024560', "Chip's Sal", 'BARCEL', '52 g', 'BOTANAS', 16.8, 20), ('757528027148', "Chip's Fuego", 'BARCEL', '42 g', 'BOTANAS', 12.6, 15), ('757528027117', "Chip's Jalapeño", 'BARCEL', '42 g', 'BOTANAS', 12.6, 15), ('7501000266203', "Chip's Sal", 'BARCEL', '170 g', 'BOTANAS', 46.2, 55), ('7501000266234', "Chip's Jalapeño", 'BARCEL', '170 g', 'BOTANAS', 46.2, 55), ('757528001889', "Chip's Fuego", 'BARCEL', '170 g', 'BOTANAS', 46.2, 55), ('7500810027783', 'Papas Barcel Sal', 'BARCEL', '28 g', 'BOTANAS', 8.4, 10), ('7500810027745', 'Papas Barcel Adobado', 'BARCEL', '28 g', 'BOTANAS', 8.4, 10), ('7500810027790', 'Papas Barcel Sal', 'BARCEL', '45 g', 'BOTANAS', 13.44, 16), ('7500810027752', 'Papas Barcel Adobado', 'BARCEL', '45 g', 'BOTANAS', 13.44, 16), ('7500810027813', 'Papas Barcel Toreadas', 'BARCEL', '45 g', 'BOTANAS', 13.44, 16), ('7500810014363', 'Papas Barcel Toreadas', 'BARCEL', '170 g', 'BOTANAS', 46.2, 55), ('7500810020975', 'Wapas Nuevo Queso', 'BARCEL', '52 g', 'BOTANAS', 13.44, 16), ('7500810027646', 'Chipotles', 'BARCEL', '65 g', 'BOTANAS', 15.12, 18), ('7501000364039', 'Mini Runners', 'BARCEL', '35 g', 'BOTANAS', 8.4, 10), ('7500810027837', 'Runners', 'BARCEL', '72 g', 'BOTANAS', 15.12, 18), ('7500810027820', 'Runners Fuego', 'BARCEL', '72 g', 'BOTANAS', 15.12, 18), ('7500810028407', 'Runners Blue Heat', 'BARCEL', '72 g', 'BOTANAS', 15.12, 18), ('7500810028599', 'Runners Limón y Sal', 'BARCEL', '72 g', 'BOTANAS', 15.12, 18), ('7501030421269', 'Runners', 'BARCEL', '200 g', 'BOTANAS', 33.6, 40), ('7500810037294', 'Tostachos Queso Jalapeño', 'BARCEL', '75 g', 'BOTANAS', 15.12, 18), ('7501030448242', 'Mini Takis Fuego', 'BARCEL', '35 g', 'BOTANAS', 8.4, 10), ('7500810000441', 'Takis Fajitas', 'BARCEL', '70 g', 'BOTANAS', 16.8, 20), ('7500810000489', 'Takis Huakamole', 'BARCEL', '70 g', 'BOTANAS', 16.8, 20), ('7500810003671', 'Takis Fuego', 'BARCEL', '70 g', 'BOTANAS', 16.8, 20), ('7500810000502', 'Takis Salsa Brava', 'BARCEL', '70 g', 'BOTANAS', 16.8, 20), ('7500810028353', 'Takis Blue Heat', 'BARCEL', '70 g', 'BOTANAS', 16.8, 20), ('7500810036822', 'Takis Chile Limón', 'BARCEL', '70 g', 'BOTANAS', 16.8, 20), ('757528038205', 'Takis Fuego', 'BARCEL', '200 g', 'BOTANAS', 37.8, 45), ('7503030572460', 'Takis Original', 'BARCEL', '200 g', 'BOTANAS', 37.8, 45), ('7500810008874', 'Hot Nuts Original', 'BARCEL', '75 g', 'BOTANAS', 16.8, 20), ('7500810008881', 'Hot Nuts Fuego', 'BARCEL', '75 g', 'BOTANAS', 16.8, 20), ('757528044121', 'Hot Nuts Original', 'BARCEL', '115 g', 'BOTANAS', 21.0, 25), ('757528044138', 'Hot Nuts Fuego', 'BARCEL', '115 g', 'BOTANAS', 21.0, 25), ('7500810029046', 'Golden Nuts Salados', 'BARCEL', '78 g', 'BOTANAS', 16.8, 20), ('7500810029053', 'Golden Nuts Enchilado', 'BARCEL', '78 g', 'BOTANAS', 16.8, 20), ('7500810029879', 'Golden Nuts Fuego', 'BARCEL', '78 g', 'BOTANAS', 16.8, 20), ('7500810027707', 'Golden Nuts Salados', 'BARCEL', '110 g', 'BOTANAS', 21.0, 25), ('7500810027691', 'Golden Nuts Enchilado', 'BARCEL', '110 g', 'BOTANAS', 21.0, 25), ('7500810029886', 'Golden Nuts Fuego', 'BARCEL', '110 g', 'BOTANAS', 21.0, 25), ('7500810027714', 'Kiyakis', 'BARCEL', '60 g', 'BOTANAS', 12.6, 15), ('7500810005064', 'Kiyakis', 'BARCEL', '120 g', 'BOTANAS', 16.8, 20), ('7500810013205', 'Big Mix Inglesa Limón', 'BARCEL', '80 g', 'BOTANAS', 18.48, 22), ('7500810013199', 'Big Mix Fuego', 'BARCEL', '80 g', 'BOTANAS', 18.48, 22), ('7500810013182', 'Big Mix Queso', 'BARCEL', '80 g', 'BOTANAS', 18.48, 22), ('7500810013250', 'Big Mix Fuego', 'BARCEL', '38 g', 'BOTANAS', 8.4, 10), ('757528039271', 'Big Mix Fuego', 'BARCEL', '185 g', 'BOTANAS', 33.6, 40), ('757528039288', 'Big Mix Queso', 'BARCEL', '185 g', 'BOTANAS', 33.6, 40), ('7500810028377', 'Takis Duoz Chips Sal', 'BARCEL', '70 g', 'BOTANAS', 16.8, 20), ('7500810020234', 'Takis Duoz Pop Chilix Sandía', 'BARCEL', '85 g', 'BOTANAS', 16.8, 20), ('7500810005040', 'Karameladas Pop', 'BARCEL', '45 g', 'BOTANAS', 8.4, 10), ('7500810013564', 'Pop Sens Queso', 'BARCEL', '45 g', 'BOTANAS', 13.44, 16), ('7500810005057', 'Karameladas Pop', 'BARCEL', '110 g', 'BOTANAS', 13.44, 16), ('7503030199728', 'Chicharrón de Cerdo', 'BARCEL', '30 g', 'BOTANAS', 15.12, 18), ('7503032248165', 'Chicharrón de Cerdo', 'BARCEL', '70 g', 'BOTANAS', 33.6, 40), ('757528036638', 'Valentones Fuego', 'BARCEL', '60 g', 'BOTANAS', 13.44, 16), ('7501030482055', 'Valentones', 'BARCEL', '175 g', 'BOTANAS', 29.4, 35), ('7500810016930', 'Valentones Fuego', 'BARCEL', '175 g', 'BOTANAS', 29.4, 35), (None, 'Danup Fresa 220 g', 'DANONE', '220 g', 'LÁCTEOS', 14.4, 20), (None, 'Danup Piña Coco 220 g', 'DANONE', '220 g', 'LÁCTEOS', 14.4, 20), (None, 'Danup Galleta 220 g', 'DANONE', '220 g', 'LÁCTEOS', 14.4, 20), (None, 'Danup Fresa 350 g', 'DANONE', '350 g', 'LÁCTEOS', 16.2, 23), (None, 'Danup Piña Coco 350 g', 'DANONE', '350 g', 'LÁCTEOS', 16.2, 23), (None, 'Danup Galleta 350 g', 'DANONE', '350 g', 'LÁCTEOS', 16.2, 23), (None, 'Danone Licuado Fresa-Plátano 435 g', 'DANONE', '435 g', 'LÁCTEOS', 21.1, 26), (None, 'Danone Licuado Frutos Rojos 435 g', 'DANONE', '435 g', 'LÁCTEOS', 21.1, 26), (None, 'Danone Licuado Nuez 435 g', 'DANONE', '435 g', 'LÁCTEOS', 21.1, 26), (None, 'Danone Licuado Quaker Plátano 435 g', 'DANONE', '435 g', 'LÁCTEOS', 21.1, 26), (None, 'Danone Licuado Quaker Fresa 435 g', 'DANONE', '435 g', 'LÁCTEOS', 21.1, 26), (None, 'Activia Fresa 225 g', 'DANONE', '225 g', 'LÁCTEOS', 15.0, 20), (None, 'Activia Chía 225 g', 'DANONE', '225 g', 'LÁCTEOS', 15.0, 20), (None, 'Activia Ciruela Pasa 225 g', 'DANONE', '225 g', 'LÁCTEOS', 15.0, 20), (None, 'Benegastro 240 g', 'DANONE', '240 g', 'LÁCTEOS', 15.8, 20), (None, 'Oikos Selecto 230 g', 'DANONE', '230 g', 'LÁCTEOS', 17.5, 22), (None, 'Oikos Pro 220 g', 'DANONE', '220 g', 'LÁCTEOS', 23.2, 29), (None, 'Oikos Pro Chocolate 220 g', 'DANONE', '220 g', 'LÁCTEOS', 23.2, 29)]
    t=now()
    for barcode,name,provider,presentation,category,supplier_price,sale_price in catalog_v060:
        existing=cur.execute('SELECT id,barcode FROM products WHERE name=? AND provider=? AND COALESCE(presentation,\'\')=?',(name,provider,presentation or '')).fetchone()
        if existing:
            # Conserva un codigo ya capturado; si esta vacio y la lista trae codigo, lo completa.
            if barcode and not (existing['barcode'] or '').strip():
                try: cur.execute('UPDATE products SET barcode=?,category=?,supplier_price=?,sale_price=?,updated_at=? WHERE id=?',(barcode,category,supplier_price,sale_price,t,existing['id']))
                except sqlite3.IntegrityError: cur.execute('UPDATE products SET category=?,supplier_price=?,sale_price=?,updated_at=? WHERE id=?',(category,supplier_price,sale_price,t,existing['id']))
            else:
                cur.execute('UPDATE products SET category=?,supplier_price=?,sale_price=?,updated_at=? WHERE id=?',(category,supplier_price,sale_price,t,existing['id']))
        else:
            try:
                cur.execute('INSERT INTO products(barcode,name,provider,presentation,category,supplier_price,sale_price,stock,min_stock,created_at,updated_at) VALUES(?,?,?,?,?,?,?,0,0,?,?)',(barcode,name,provider,presentation,category,supplier_price,sale_price,t,t))
            except sqlite3.IntegrityError:
                cur.execute('INSERT INTO products(barcode,name,provider,presentation,category,supplier_price,sale_price,stock,min_stock,created_at,updated_at) VALUES(NULL,?,?,?,?,?,?,0,0,?,?)',(name,provider,presentation,category,supplier_price,sale_price,t,t))

    if not cur.execute("SELECT 1 FROM app_settings WHERE key='transfer_webhook_token'").fetchone():
        cur.execute("INSERT INTO app_settings(key,value) VALUES('transfer_webhook_token',?)",(secrets.token_urlsafe(24),))
    c.commit();c.close()


def app_version():
    try:
        with open(VERSION_PATH,'r',encoding='utf-8') as f:return json.load(f).get('version','0.0.0')
    except:return '0.0.0'

def backup_name(reason='daily'):
    stamp=datetime.now().strftime('%Y-%m-%d_%H-%M-%S')
    return f"SUPER_UNI_{reason}_{stamp}.db"

def external_backup_dir(c=None):
    val=''
    try:
        if c: val=get_setting(c,'backup_external_dir','').strip()
        else:
            cx=db(); val=get_setting(cx,'backup_external_dir','').strip(); cx.close()
    except: pass
    if val:return os.path.expandvars(os.path.expanduser(val))
    od=os.environ.get('OneDrive') or os.environ.get('ONEDRIVE')
    return os.path.join(od,'SUPER-UNI Respaldos') if od else ''

def prune_backups(folder,keep=30):
    try:
        files=sorted([os.path.join(folder,x) for x in os.listdir(folder) if x.lower().endswith('.db')],key=os.path.getmtime,reverse=True)
        for f in files[keep:]:
            try:os.remove(f)
            except:pass
    except:pass

def backup_database(reason='manual'):
    with BACKUP_LOCK:
        os.makedirs(BACKUP_DIR,exist_ok=True)
        dest=os.path.join(BACKUP_DIR,backup_name(reason))
        src=sqlite3.connect(DB_PATH,timeout=20)
        dst=sqlite3.connect(dest)
        try:src.backup(dst)
        finally:dst.close();src.close()
        prune_backups(BACKUP_DIR,30)
        ext=external_backup_dir()
        ext_copy=''
        if ext:
            try:
                os.makedirs(ext,exist_ok=True)
                ext_copy=os.path.join(ext,os.path.basename(dest))
                shutil.copy2(dest,ext_copy)
                prune_backups(ext,30)
            except Exception:
                ext_copy=''
        return {'file':os.path.basename(dest),'path':dest,'size':os.path.getsize(dest),'external_copy':ext_copy,'created_at':now(),'reason':reason}

def list_backups():
    out=[]
    os.makedirs(BACKUP_DIR,exist_ok=True)
    for name in sorted(os.listdir(BACKUP_DIR),reverse=True):
        if not name.lower().endswith('.db'):continue
        p=os.path.join(BACKUP_DIR,name)
        st=os.stat(p)
        out.append({'file':name,'size':st.st_size,'modified':datetime.fromtimestamp(st.st_mtime).isoformat(timespec='seconds')})
    return out[:30]

def restore_backup(filename):
    safe=os.path.basename(filename)
    srcpath=os.path.join(BACKUP_DIR,safe)
    if not os.path.isfile(srcpath):raise ValueError('Respaldo no encontrado')
    backup_database('antes_restaurar')
    with BACKUP_LOCK:
        src=sqlite3.connect(srcpath,timeout=20)
        dst=sqlite3.connect(DB_PATH,timeout=20)
        try:src.backup(dst)
        finally:dst.close();src.close()
    return True

def has_daily_backup_today():
    prefix='SUPER_UNI_daily_'+date.today().isoformat()
    return any(x.startswith(prefix) for x in os.listdir(BACKUP_DIR)) if os.path.isdir(BACKUP_DIR) else False

def backup_scheduler():
    while True:
        try:
            if datetime.now().hour>=22 and not has_daily_backup_today():
                backup_database('daily')
        except Exception as e:
            print('[SUPER-UNI] Respaldo automático:',e)
        time.sleep(1800)

def install_launcher_update():
    template=os.path.join(APP_DIR,'launcher_template.pyw')
    target=os.path.join(os.path.dirname(APP_DIR),'SUPER_UNI.pyw')
    if os.path.isfile(template):
        try:
            if not os.path.isfile(target) or open(template,'rb').read()!=open(target,'rb').read():
                shutil.copy2(template,target)
                print('[SUPER-UNI] Actualizador de escritorio actualizado.')
        except Exception as e:print('[SUPER-UNI] No se pudo actualizar launcher:',e)

def rows(c,sql,p=()): return [dict(x) for x in c.execute(sql,p).fetchall()]
def one(c,sql,p=()):
    r=c.execute(sql,p).fetchone(); return dict(r) if r else None

def session_totals(c,s):
    end=s.get('closed_at') or now()
    pars=(s['cashbox'],s['user_name'],s['opened_at'],end)
    cash=float(c.execute("SELECT COALESCE(SUM(total),0) t FROM sales WHERE cashbox=? AND user_name=? AND created_at>=? AND created_at<=? AND voided=0 AND payment_method='EFECTIVO'",pars).fetchone()['t'])
    card=float(c.execute("SELECT COALESCE(SUM(total),0) t FROM sales WHERE cashbox=? AND user_name=? AND created_at>=? AND created_at<=? AND voided=0 AND payment_method='TARJETA'",pars).fetchone()['t'])
    transfer=float(c.execute("SELECT COALESCE(SUM(total),0) t FROM sales WHERE cashbox=? AND user_name=? AND created_at>=? AND created_at<=? AND voided=0 AND payment_method='TRANSFERENCIA'",pars).fetchone()['t'])
    withdrawals=float(c.execute("SELECT COALESCE(SUM(amount),0) t FROM cash_movements WHERE session_id=? AND movement_type='WITHDRAWAL'",(s['id'],)).fetchone()['t'])
    deposits=float(c.execute("SELECT COALESCE(SUM(amount),0) t FROM cash_movements WHERE session_id=? AND movement_type='DEPOSIT'",(s['id'],)).fetchone()['t'])
    expected_cash=float(s['opening_amount'])+cash+deposits-withdrawals
    return {'cash_sales':cash,'card_sales':card,'transfer_sales':transfer,'withdrawals':withdrawals,'deposits':deposits,'expected_cash':expected_cash}

def session_expected(c,s):
    return session_totals(c,s)['expected_cash']

def get_setting(c,key,default=''):
    r=c.execute('SELECT value FROM app_settings WHERE key=?',(key,)).fetchone()
    return r['value'] if r else default

def set_setting(c,key,value):
    c.execute("INSERT INTO app_settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",(key,str(value or '')))

def add_notification(c,title,message,level='INFO'):
    c.execute('INSERT INTO notifications(title,message,level,created_at) VALUES(?,?,?,?)',(title,message,level,now()))

def send_gmail(c,subject,body):
    user=get_setting(c,'gmail_user')
    pwd=get_setting(c,'gmail_app_password')
    recipient=get_setting(c,'report_email')
    if not user or not pwd or not recipient:
        return False,'Gmail no configurado'
    msg=EmailMessage()
    msg['Subject']=subject
    msg['From']=user
    msg['To']=recipient
    msg.set_content(body)
    try:
        ctx=ssl.create_default_context()
        with smtplib.SMTP_SSL('smtp.gmail.com',465,context=ctx,timeout=15) as s:
            s.login(user,pwd)
            s.send_message(msg)
        return True,'Enviado'
    except Exception as e:
        return False,str(e)

def cut_report_text(c,sid):
    s=one(c,'SELECT * FROM cash_sessions WHERE id=?',(sid,))
    if not s:return ''
    t=session_totals(c,s)
    sales=one(c,"SELECT COALESCE(SUM(total),0) total, COUNT(*) tickets FROM sales WHERE cashbox=? AND user_name=? AND created_at>=? AND created_at<=? AND voided=0",(s['cashbox'],s['user_name'],s['opened_at'],s.get('closed_at') or now()))
    return (
        f"SUPER-UNI - CORTE DE CAJA\n"
        f"Caja: {s['cashbox']}\nCajero: {s['user_name']}\n"
        f"Apertura: {s['opened_at']}\nCierre: {s.get('closed_at') or 'ABIERTO'}\n\n"
        f"Fondo inicial: ${float(s['opening_amount']):,.2f}\n"
        f"Venta total: ${float(sales['total']):,.2f}\nTickets: {sales['tickets']}\n\n"
        f"EFECTIVO\nEsperado: ${float(s.get('expected_cash') or t['expected_cash']):,.2f}\nDeclarado: ${float(s.get('closing_counted') or 0):,.2f}\nDiferencia: ${float(s.get('difference') or 0):,.2f}\n\n"
        f"TARJETA\nSistema: ${float(s.get('expected_card') or t['card_sales']):,.2f}\nDeclarado: ${float(s.get('declared_card') or 0):,.2f}\nDiferencia: ${float(s.get('card_difference') or 0):,.2f}\n\n"
        f"TRANSFERENCIAS\nSistema: ${float(s.get('expected_transfers') or t['transfer_sales']):,.2f}\nDeclarado: ${float(s.get('declared_transfers') or 0):,.2f}\nDiferencia: ${float(s.get('transfer_difference') or 0):,.2f}\n\n"
        f"SALIDAS DE CAJA\nRegistradas: ${float(s.get('expected_withdrawals') or t['withdrawals']):,.2f}\nDeclaradas: ${float(s.get('declared_withdrawals') or 0):,.2f}\nDiferencia: ${float(s.get('withdrawal_difference') or 0):,.2f}\n"
        f"Observaciones: {s.get('cut_note') or ''}\n"
    )


def inventory_receipt_report_text(c,receipt_id):
    r=one(c,'SELECT * FROM inventory_receipts WHERE id=?',(receipt_id,))
    if not r:return ''
    items=rows(c,'SELECT * FROM inventory_receipt_items WHERE receipt_id=? ORDER BY id',(receipt_id,))
    lines=[
        "SUPER-UNI - COMPROBANTE DE INVENTARIADO",
        f"Proveedor: {r['provider']}",
        f"Trabajador: {r['user_name']}",
        f"Inicio: {r['started_at']}",
        f"Fin: {r.get('ended_at') or 'EN PROCESO'}",
        "",
        "MOVIMIENTOS:"
    ]
    for x in items:
        op={'add':'ENTRADA','remove':'SALIDA/MERMA','set':'CONTEO FIJO'}.get(x['movement_type'],x['movement_type'])
        lines.append(f"{x['product_name']} | {op} {x['qty']} | {x['stock_before']} -> {x['stock_after']} | {x.get('note') or ''}")
    lines += ["",f"Total de movimientos: {len(items)}"]
    return "\n".join(lines)

def inventory_report_text(c,limit=100):
    mv=rows(c,'SELECT im.*,p.name product_name FROM inventory_movements im JOIN products p ON p.id=im.product_id ORDER BY im.id DESC LIMIT ?',(limit,))
    lines=["SUPER-UNI - MOVIMIENTOS DE INVENTARIO",""]
    for x in mv:
        lines.append(f"{x['created_at']} | {x['user_name'] or ''} | {x['product_name']} | {x['stock_before']} -> {x['stock_after']} | {x['movement_type']} | {x['note'] or ''}")
    return "\n".join(lines)

class Handler(BaseHTTPRequestHandler):
    def log_message(self,fmt,*args): print('[SUPER-UNI]',fmt%args)
    def send_json(self,obj,status=200):
        data=json.dumps(obj,ensure_ascii=False).encode();self.send_response(status);self.send_header('Content-Type','application/json; charset=utf-8');self.send_header('Content-Length',str(len(data)));self.end_headers();self.wfile.write(data)
    def body(self):
        n=int(self.headers.get('Content-Length',0));
        try:return json.loads(self.rfile.read(n) or b'{}')
        except:return {}
    def path_parts(self): return [x for x in urlparse(self.path).path.split('/') if x]
    def serve_file(self,path):
        if not os.path.isfile(path):self.send_error(404);return
        data=open(path,'rb').read();self.send_response(200);self.send_header('Content-Type',mimetypes.guess_type(path)[0] or 'application/octet-stream');self.send_header('Cache-Control','no-store, no-cache, must-revalidate, max-age=0');self.send_header('Pragma','no-cache');self.send_header('Expires','0');self.send_header('Content-Length',len(data));self.end_headers();self.wfile.write(data)
    def do_GET(self):
        u=urlparse(self.path);p=u.path;qs=parse_qs(u.query)
        if p=='/': return self.serve_file(os.path.join(STATIC_DIR,'index.html'))
        if p.startswith('/static/'):
            rel=os.path.normpath(p[8:]).lstrip('/\\');return self.serve_file(os.path.join(STATIC_DIR,rel))
        try:
            c=db()
            if p=='/api/providers':
                custom=[x['name'] for x in rows(c,'SELECT name FROM custom_providers ORDER BY name')]
                used=[x['provider'] for x in rows(c,"SELECT DISTINCT provider FROM products WHERE active=1 AND TRIM(provider)<>'' ORDER BY provider")]
                out=sorted(set(PROVIDERS+custom+used),key=lambda x:x.upper())
            elif p=='/api/report-settings':
                out={'report_email':get_setting(c,'report_email',''),'whatsapp_phone':get_setting(c,'whatsapp_phone','')}
            elif p=='/api/users': out=rows(c,'SELECT id,name,role,active FROM users ORDER BY name')
            elif p=='/api/products':
                q=qs.get('q',[''])[0].strip();provider=qs.get('provider',[''])[0].strip();sql='SELECT * FROM products WHERE active=1';pars=[]
                if q:sql+=' AND (name LIKE ? OR COALESCE(barcode,\'\') LIKE ? OR provider LIKE ? OR COALESCE(presentation,\'\') LIKE ?)';like=f'%{q}%';pars += [like]*4
                if provider:sql+=' AND provider=?';pars.append(provider)
                out=rows(c,sql+' ORDER BY name',pars)
            elif p=='/api/cash/status':out=one(c,"SELECT * FROM cash_sessions WHERE cashbox=? AND status='OPEN' ORDER BY id DESC LIMIT 1",(qs.get('cashbox',['CAJA 1'])[0],)) or {}
            elif p=='/api/cash/preview':
                sess=one(c,"SELECT * FROM cash_sessions WHERE cashbox=? AND status='OPEN' ORDER BY id DESC LIMIT 1",(qs.get('cashbox',['CAJA 1'])[0],)) or {}
                out={'session':sess,'totals':session_totals(c,sess) if sess else {}}

            elif p=='/api/sales':out=rows(c,'SELECT * FROM sales ORDER BY id DESC LIMIT 300')
            elif p.startswith('/api/sales/') and len(self.path_parts())==3:
                sid=int(self.path_parts()[2]);s=one(c,'SELECT * FROM sales WHERE id=?',(sid,));
                if not s:c.close();return self.send_json({'error':'Venta no encontrada'},404)
                out={'sale':s,'items':rows(c,'SELECT * FROM sale_items WHERE sale_id=?',(sid,))}
            elif p=='/api/dashboard':
                td=date.today().isoformat();out={'products':c.execute('SELECT COUNT(*) c FROM products WHERE active=1').fetchone()['c'],'low_stock':c.execute('SELECT COUNT(*) c FROM products WHERE active=1 AND stock<=min_stock').fetchone()['c'],'sales_today':c.execute("SELECT COALESCE(SUM(total),0) t FROM sales WHERE substr(created_at,1,10)=? AND voided=0",(td,)).fetchone()['t'],'tickets_today':c.execute("SELECT COUNT(*) c FROM sales WHERE substr(created_at,1,10)=? AND voided=0",(td,)).fetchone()['c'],'profit_today':c.execute("SELECT COALESCE(SUM((si.unit_price-si.supplier_price)*si.qty),0) t FROM sale_items si JOIN sales s ON s.id=si.sale_id WHERE substr(s.created_at,1,10)=? AND s.voided=0",(td,)).fetchone()['t']}
            elif p=='/api/dashboard/owner':
                period=qs.get('period',['today'])[0]
                today=date.today()
                if period=='month': start=today.replace(day=1).isoformat()
                elif period=='week': start=(today-timedelta(days=today.weekday())).isoformat()
                else: start=today.isoformat()
                end=today.isoformat()
                sales_total=c.execute("SELECT COALESCE(SUM(total),0) t FROM sales WHERE substr(created_at,1,10) BETWEEN ? AND ? AND voided=0",(start,end)).fetchone()['t']
                cost_total=c.execute("SELECT COALESCE(SUM(si.supplier_price*si.qty),0) t FROM sale_items si JOIN sales s ON s.id=si.sale_id WHERE substr(s.created_at,1,10) BETWEEN ? AND ? AND s.voided=0",(start,end)).fetchone()['t']
                profit=c.execute("SELECT COALESCE(SUM((si.unit_price-si.supplier_price)*si.qty),0) t FROM sale_items si JOIN sales s ON s.id=si.sale_id WHERE substr(s.created_at,1,10) BETWEEN ? AND ? AND s.voided=0",(start,end)).fetchone()['t']
                tickets=c.execute("SELECT COUNT(*) c FROM sales WHERE substr(created_at,1,10) BETWEEN ? AND ? AND voided=0",(start,end)).fetchone()['c']
                top=rows(c,"""SELECT si.product_name,SUM(si.qty) qty,SUM(si.line_total) sales,SUM((si.unit_price-si.supplier_price)*si.qty) profit FROM sale_items si JOIN sales s ON s.id=si.sale_id WHERE substr(s.created_at,1,10) BETWEEN ? AND ? AND s.voided=0 GROUP BY si.product_id,si.product_name ORDER BY qty DESC,sales DESC LIMIT 10""",(start,end))
                by_user=rows(c,"""SELECT COALESCE(user_name,'SIN USUARIO') user_name,COUNT(*) tickets,COALESCE(SUM(total),0) sales FROM sales WHERE substr(created_at,1,10) BETWEEN ? AND ? AND voided=0 GROUP BY COALESCE(user_name,'SIN USUARIO') ORDER BY sales DESC""",(start,end))
                out={'period':period,'start':start,'end':end,'sales':sales_total,'cost':cost_total,'profit':profit,'margin_percent':(profit/sales_total*100 if sales_total else 0),'tickets':tickets,'top_products':top,'by_user':by_user}
            elif p=='/api/dashboard/weekly':
                today=date.today()
                start=(today-timedelta(days=today.weekday())).isoformat()
                end=today.isoformat()
                sales_total=c.execute("SELECT COALESCE(SUM(total),0) t FROM sales WHERE substr(created_at,1,10) BETWEEN ? AND ? AND voided=0",(start,end)).fetchone()['t']
                cost_total=c.execute("SELECT COALESCE(SUM(si.supplier_price*si.qty),0) t FROM sale_items si JOIN sales s ON s.id=si.sale_id WHERE substr(s.created_at,1,10) BETWEEN ? AND ? AND s.voided=0",(start,end)).fetchone()['t']
                profit=c.execute("SELECT COALESCE(SUM((si.unit_price-si.supplier_price)*si.qty),0) t FROM sale_items si JOIN sales s ON s.id=si.sale_id WHERE substr(s.created_at,1,10) BETWEEN ? AND ? AND s.voided=0",(start,end)).fetchone()['t']
                tickets=c.execute("SELECT COUNT(*) c FROM sales WHERE substr(created_at,1,10) BETWEEN ? AND ? AND voided=0",(start,end)).fetchone()['c']
                top=rows(c,"""SELECT si.product_name, SUM(si.qty) qty, SUM(si.line_total) sales,
                    SUM((si.unit_price-si.supplier_price)*si.qty) profit
                    FROM sale_items si JOIN sales s ON s.id=si.sale_id
                    WHERE substr(s.created_at,1,10) BETWEEN ? AND ? AND s.voided=0
                    GROUP BY si.product_id,si.product_name ORDER BY qty DESC,sales DESC LIMIT 10""",(start,end))
                by_user=rows(c,"""SELECT COALESCE(user_name,'SIN USUARIO') user_name,COUNT(*) tickets,COALESCE(SUM(total),0) sales
                    FROM sales WHERE substr(created_at,1,10) BETWEEN ? AND ? AND voided=0
                    GROUP BY COALESCE(user_name,'SIN USUARIO') ORDER BY sales DESC""",(start,end))
                margin=(profit/sales_total*100) if sales_total else 0
                markup=(profit/cost_total*100) if cost_total else 0
                out={'start':start,'end':end,'sales':sales_total,'cost':cost_total,'profit':profit,'margin_percent':margin,'markup_percent':markup,'tickets':tickets,'top_products':top,'by_user':by_user}
            elif p=='/api/inventory/movements':out=rows(c,'SELECT im.*,p.name product_name FROM inventory_movements im JOIN products p ON p.id=im.product_id ORDER BY im.id DESC LIMIT 300')
            elif p=='/api/inventory/receipt/current':
                usr=qs.get('user',[''])[0];out=one(c,"SELECT * FROM inventory_receipts WHERE user_name=? AND status='OPEN' ORDER BY id DESC LIMIT 1",(usr,)) or {}
            elif p=='/api/inventory/receipt/items':
                rid=int(qs.get('receipt_id',['0'])[0]);out=rows(c,'SELECT * FROM inventory_receipt_items WHERE receipt_id=? ORDER BY id DESC',(rid,))

            elif p=='/api/version':out={'version':app_version()}
            elif p=='/api/connection-info':
                ip=local_ip();out={'ip':ip,'port':5000,'url':f'http://{ip}:5000'}
            elif p=='/api/backups':out={'backups':list_backups(),'external_dir':external_backup_dir(c),'retention':30}

            elif p=='/api/settings':
                out={x['key']:x['value'] for x in rows(c,'SELECT key,value FROM app_settings')}
                if out.get('gmail_app_password'): out['gmail_app_password']='********'
            elif p=='/api/notifications': out=rows(c,'SELECT * FROM notifications ORDER BY id DESC LIMIT 100')
            elif p=='/api/transfers': out=rows(c,'SELECT * FROM transfers ORDER BY id DESC LIMIT 200')
            elif p=='/api/cash/sessions': out=rows(c,'SELECT * FROM cash_sessions ORDER BY id DESC LIMIT 100')
            elif p=='/api/reports/inventory-text': out={'text':inventory_report_text(c,100)}
            elif p=='/api/reports/cut-text':
                sid=int(qs.get('session_id',['0'])[0]);out={'text':cut_report_text(c,sid)}
            else:c.close();return self.send_json({'error':'Ruta no encontrada'},404)
            c.close();return self.send_json(out)
        except Exception as e:return self.send_json({'error':str(e)},500)
    def do_POST(self):
        p=urlparse(self.path).path;d=self.body()
        try:
            c=db();cur=c.cursor()
            if p=='/api/login':
                out=one(c,'SELECT id,name,role FROM users WHERE name=? AND pin_hash=? AND active=1',(d.get('name',''),pin_hash(d.get('pin',''))));c.close();return self.send_json(out if out else {'error':'Usuario o PIN incorrecto'},200 if out else 401)
            if p=='/api/providers':
                name=str(d.get('name','')).strip().upper()
                if not name:c.close();return self.send_json({'error':'Escribe el nombre del proveedor'},400)
                exists=name in PROVIDERS or one(c,'SELECT id FROM custom_providers WHERE UPPER(name)=UPPER(?)',(name,)) or one(c,'SELECT id FROM products WHERE UPPER(provider)=UPPER(?) LIMIT 1',(name,))
                if exists:c.close();return self.send_json({'error':'Ese proveedor ya existe'},400)
                cur.execute('INSERT INTO custom_providers(name,created_at) VALUES(?,?)',(name,now()));c.commit();c.close();return self.send_json({'ok':True,'name':name},201)
            if p=='/api/users':
                name=d.get('name','').strip();pin=d.get('pin','').strip()
                if not name or not pin:c.close();return self.send_json({'error':'Nombre y PIN son obligatorios'},400)
                try:cur.execute('INSERT INTO users(name,role,pin_hash,created_at) VALUES(?,?,?,?)',(name,d.get('role','CAJERO'),pin_hash(pin),now()));c.commit()
                except sqlite3.IntegrityError:c.close();return self.send_json({'error':'Ese usuario ya existe'},400)
                c.close();return self.send_json({'ok':True},201)
            if p=='/api/products':
                if not d.get('name','').strip() or not d.get('provider','').strip():c.close();return self.send_json({'error':'Nombre y proveedor son obligatorios'},400)
                t=now()
                try:cur.execute('INSERT INTO products(barcode,name,provider,presentation,category,supplier_price,sale_price,stock,min_stock,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?)',(d.get('barcode') or None,d['name'].strip(),d['provider'].strip(),d.get('presentation',''),d.get('category',''),float(d.get('supplier_price',0) or 0),float(d.get('sale_price',0) or 0),int(d.get('stock',0) or 0),int(d.get('min_stock',0) or 0),t,t));c.commit();pid=cur.lastrowid
                except sqlite3.IntegrityError:c.close();return self.send_json({'error':'Ese código de barras ya existe'},400)
                out=one(c,'SELECT * FROM products WHERE id=?',(pid,));c.close();return self.send_json(out,201)
            if p=='/api/inventory/receipt/start':
                provider=d.get('provider','').strip();usr=d.get('user_name','').strip()
                if not provider or not usr:c.close();return self.send_json({'error':'Proveedor y usuario son obligatorios'},400)
                ex=one(c,"SELECT * FROM inventory_receipts WHERE user_name=? AND status='OPEN' ORDER BY id DESC LIMIT 1",(usr,))
                if ex:c.close();return self.send_json(ex,200)
                cur.execute("INSERT INTO inventory_receipts(provider,user_name,status,started_at) VALUES(?,?,'OPEN',?)",(provider,usr,now()))
                rid=cur.lastrowid;c.commit();out=one(c,'SELECT * FROM inventory_receipts WHERE id=?',(rid,));c.close();return self.send_json(out,201)
            if p=='/api/inventory/receipt/finish':
                rid=int(d.get('receipt_id',0));rec=one(c,"SELECT * FROM inventory_receipts WHERE id=? AND status='OPEN'",(rid,))
                if not rec:c.close();return self.send_json({'error':'Registro de inventario no encontrado o ya finalizado'},404)
                ended=now();cur.execute("UPDATE inventory_receipts SET status='CLOSED',ended_at=? WHERE id=?",(ended,rid));c.commit()
                report=inventory_receipt_report_text(c,rid)
                ok,msg=send_gmail(c,f"SUPER-UNI · Inventariado {rec['provider']} · {rec['user_name']}",report)
                cur.execute("UPDATE inventory_receipts SET email_sent=?,email_message=? WHERE id=?",(1 if ok else 0,msg,rid))
                add_notification(c,'Inventariado finalizado',f"{rec['user_name']} finalizó {rec['provider']}. Email: {'enviado' if ok else 'no enviado'}",'OK' if ok else 'WARN')
                c.commit();c.close();return self.send_json({'ok':True,'email_sent':ok,'email_message':msg,'report':report})
            if p=='/api/inventory/adjust':
                pid=int(d.get('product_id',0));mode=d.get('mode','add');qty=int(d.get('qty',0));pr=one(c,'SELECT * FROM products WHERE id=?',(pid,))
                if not pr:c.close();return self.send_json({'error':'Producto no encontrado'},404)
                before=int(pr['stock']);after=qty if mode=='set' else before-qty if mode=='remove' else before+qty
                cur.execute('UPDATE products SET stock=?,updated_at=? WHERE id=?',(after,now(),pid))
                stamp=now()
                cur.execute('INSERT INTO inventory_movements(product_id,movement_type,qty,stock_before,stock_after,note,user_name,created_at) VALUES(?,?,?,?,?,?,?,?)',(pid,mode,qty,before,after,d.get('note',''),d.get('user_name','ADMIN'),stamp))
                rid=int(d.get('receipt_id',0) or 0)
                if rid:
                    rec=one(c,"SELECT * FROM inventory_receipts WHERE id=? AND status='OPEN'",(rid,))
                    if rec:
                        cur.execute('INSERT INTO inventory_receipt_items(receipt_id,product_id,product_name,movement_type,qty,stock_before,stock_after,note,created_at) VALUES(?,?,?,?,?,?,?,?,?)',(rid,pid,pr['name'],mode,qty,before,after,d.get('note',''),stamp))
                c.commit();c.close();return self.send_json({'stock_before':before,'stock_after':after})
            if p=='/api/cash/open':
                box=d.get('cashbox','CAJA 1');ex=one(c,"SELECT * FROM cash_sessions WHERE cashbox=? AND status='OPEN'",(box,))
                if ex:c.close();return self.send_json({'error':'Esa caja ya tiene un turno abierto','session':ex},400)
                cur.execute("INSERT INTO cash_sessions(cashbox,user_name,opening_amount,opened_at,status) VALUES(?,?,?,?, 'OPEN')",(box,d.get('user_name','CAJERO'),float(d.get('opening_amount',0) or 0),now()));c.commit();sid=cur.lastrowid;c.close();return self.send_json({'session_id':sid})
            if p=='/api/cash/movement':
                sid=int(d.get('session_id',0));amount=float(d.get('amount',0) or 0);s=one(c,"SELECT * FROM cash_sessions WHERE id=? AND status='OPEN'",(sid,))
                if not s or amount<=0:c.close();return self.send_json({'error':'Turno o monto inválido'},400)
                cur.execute('INSERT INTO cash_movements(session_id,movement_type,amount,note,user_name,created_at) VALUES(?,?,?,?,?,?)',(sid,d.get('movement_type','WITHDRAWAL'),amount,d.get('note',''),d.get('user_name',''),now()));c.commit();c.close();return self.send_json({'ok':True})
            if p=='/api/cash/close':
                sid=int(d.get('session_id',0));sess=one(c,"SELECT * FROM cash_sessions WHERE id=? AND status='OPEN'",(sid,))
                if not sess:c.close();return self.send_json({'error':'Turno no encontrado'},404)
                vals=session_totals(c,sess)
                counted=float(d.get('closing_counted',0) or 0)
                declared_card=float(d.get('declared_card',0) or 0)
                declared_transfers=float(d.get('declared_transfers',0) or 0)
                declared_withdrawals=float(d.get('declared_withdrawals',0) or 0)
                cash_diff=counted-vals['expected_cash']
                card_diff=declared_card-vals['card_sales']
                transfer_diff=declared_transfers-vals['transfer_sales']
                withdrawal_diff=declared_withdrawals-vals['withdrawals']
                closed=now()
                cur.execute("""UPDATE cash_sessions SET closing_counted=?,expected_cash=?,difference=?,
                    declared_card=?,expected_card=?,card_difference=?,
                    declared_transfers=?,expected_transfers=?,transfer_difference=?,
                    declared_withdrawals=?,expected_withdrawals=?,withdrawal_difference=?,
                    cut_note=?,closed_at=?,status='CLOSED' WHERE id=?""",
                    (counted,vals['expected_cash'],cash_diff,
                     declared_card,vals['card_sales'],card_diff,
                     declared_transfers,vals['transfer_sales'],transfer_diff,
                     declared_withdrawals,vals['withdrawals'],withdrawal_diff,
                     d.get('cut_note',''),closed,sid))
                c.commit()
                report=cut_report_text(c,sid)
                ok,msg=send_gmail(c,f"SUPER-UNI · Corte {sess['cashbox']} · {sess['user_name']}",report)
                any_diff=any(abs(x)>=0.01 for x in (cash_diff,card_diff,transfer_diff,withdrawal_diff))
                add_notification(c,f"Corte {sess['cashbox']} realizado",f"{sess['user_name']} cerró turno. {'Hay diferencias por revisar.' if any_diff else 'Corte cuadrado.'} Email: {'enviado' if ok else 'no enviado'}",'WARN' if any_diff else 'OK')
                c.commit();c.close()
                try: backup_database('daily')
                except Exception as e: print('[SUPER-UNI] Respaldo al corte:',e)
                return self.send_json({
                    'ok':True,'expected_cash':vals['expected_cash'],'closing_counted':counted,'difference':cash_diff,
                    'expected_card':vals['card_sales'],'declared_card':declared_card,'card_difference':card_diff,
                    'expected_transfers':vals['transfer_sales'],'declared_transfers':declared_transfers,'transfer_difference':transfer_diff,
                    'expected_withdrawals':vals['withdrawals'],'declared_withdrawals':declared_withdrawals,'withdrawal_difference':withdrawal_diff,
                    'report':report,'email_sent':ok,'email_message':msg
                })
            if p=='/api/sales':
                items=d.get('items') or []
                if not items:c.close();return self.send_json({'error':'Venta vacía'},400)
                total=0;resolved=[]
                for it in items:
                    pr=one(c,'SELECT * FROM products WHERE id=? AND active=1',(int(it['product_id']),));qty=int(it['qty'])
                    if not pr or qty<=0:raise ValueError('Producto o cantidad inválida')
                    price=float(it.get('unit_price',pr['sale_price']));total+=price*qty;resolved.append((pr,qty,price))
                pay=d.get('payment_method','EFECTIVO');received=float(d.get('received',0) or 0)
                if pay=='EFECTIVO' and received<total:raise ValueError('Efectivo recibido insuficiente')
                change=received-total if pay=='EFECTIVO' else 0;t=now();box=d.get('cashbox','CAJA 1');usr=d.get('user_name','CAJERO');cur.execute('INSERT INTO sales(total,payment_method,received,change_due,cashbox,user_name,created_at) VALUES(?,?,?,?,?,?,?)',(total,pay,received,change,box,usr,t));sid=cur.lastrowid
                for pr,qty,price in resolved:
                    cur.execute('INSERT INTO sale_items(sale_id,product_id,product_name,qty,unit_price,supplier_price,line_total) VALUES(?,?,?,?,?,?,?)',(sid,pr['id'],pr['name'],qty,price,pr['supplier_price'],price*qty));before=int(pr['stock']);after=before-qty;cur.execute('UPDATE products SET stock=?,updated_at=? WHERE id=?',(after,t,pr['id']));cur.execute('INSERT INTO inventory_movements(product_id,movement_type,qty,stock_before,stock_after,note,user_name,created_at) VALUES(?,?,?,?,?,?,?,?)',(pr['id'],'sale',qty,before,after,f'Venta #{sid}',usr,t))
                c.commit();c.close();return self.send_json({'sale_id':sid,'total':total,'change':change})
            if p.endswith('/void') and p.startswith('/api/sales/'):
                sid=int(self.path_parts()[2]);s=one(c,'SELECT * FROM sales WHERE id=?',(sid,))
                if not s or s['voided']:c.close();return self.send_json({'error':'Venta no encontrada o ya cancelada'},400)
                for it in rows(c,'SELECT * FROM sale_items WHERE sale_id=?',(sid,)):
                    pr=one(c,'SELECT * FROM products WHERE id=?',(it['product_id'],));before=int(pr['stock']);after=before+int(it['qty']);cur.execute('UPDATE products SET stock=?,updated_at=? WHERE id=?',(after,now(),pr['id']));cur.execute('INSERT INTO inventory_movements(product_id,movement_type,qty,stock_before,stock_after,note,user_name,created_at) VALUES(?,?,?,?,?,?,?,?)',(pr['id'],'void',it['qty'],before,after,f'Cancelación venta #{sid}',d.get('user_name','ADMIN'),now()))
                cur.execute('UPDATE sales SET voided=1,void_reason=? WHERE id=?',(d.get('reason','Cancelación'),sid));c.commit();c.close();return self.send_json({'ok':True})
            if p=='/api/purchase-comparison':
                pid=int(d.get('product_id',0));qty=int(d.get('qty',0));wh=float(d.get('wholesale_price',0) or 0);pr=one(c,'SELECT * FROM products WHERE id=?',(pid,))
                if not pr or qty<=0:c.close();return self.send_json({'error':'Producto o cantidad inválida'},400)
                st=float(pr['supplier_price'])*qty;wt=wh*qty;sav=st-wt;add=1 if d.get('add_to_stock') else 0;cur.execute('INSERT INTO purchase_comparisons(product_id,qty,supplier_price,wholesale_price,supplier_total,wholesale_total,savings,add_to_stock,created_at) VALUES(?,?,?,?,?,?,?,?,?)',(pid,qty,pr['supplier_price'],wh,st,wt,sav,add,now()))
                if add:
                    before=int(pr['stock']);after=before+qty;cur.execute('UPDATE products SET stock=?,updated_at=? WHERE id=?',(after,now(),pid));cur.execute('INSERT INTO inventory_movements(product_id,movement_type,qty,stock_before,stock_after,note,user_name,created_at) VALUES(?,?,?,?,?,?,?,?)',(pid,'purchase',qty,before,after,'Compra mayorista',d.get('user_name','ADMIN'),now()))
                c.commit();c.close();return self.send_json({'supplier_total':st,'wholesale_total':wt,'savings':sav})

            if p=='/api/backups/create':
                if d.get('user_role')!='ADMIN':c.close();return self.send_json({'error':'Solo administrador'},403)
                c.close()
                try:return self.send_json(backup_database('manual'),201)
                except Exception as e:return self.send_json({'error':str(e)},500)
            if p=='/api/backups/restore':
                admin_pin=str(d.get('admin_pin',''))
                ok=one(c,"SELECT id FROM users WHERE role='ADMIN' AND active=1 AND pin_hash=?",(pin_hash(admin_pin),))
                c.close()
                if not ok:return self.send_json({'error':'PIN de administrador incorrecto'},403)
                try:
                    restore_backup(d.get('file',''))
                    return self.send_json({'ok':True,'message':'Respaldo restaurado. Reinicia SUPER-UNI para asegurar que todos los equipos recarguen la información.'})
                except Exception as e:return self.send_json({'error':str(e)},500)
            if p=='/api/settings':
                allowed=['gmail_user','gmail_app_password','report_email','whatsapp_phone','backup_external_dir']
                for k in allowed:
                    if k in d and not (k=='gmail_app_password' and d[k]=='********'):
                        set_setting(c,k,d[k])
                c.commit();c.close();return self.send_json({'ok':True})
            if p=='/api/reports/send-inventory':
                text=inventory_report_text(c,100);ok,msg=send_gmail(c,'SUPER-UNI · Movimientos de inventario',text)
                add_notification(c,'Reporte de inventario',f"Intento de envío por Gmail: {'enviado' if ok else 'no enviado'}",'OK' if ok else 'WARN')
                c.commit();c.close();return self.send_json({'ok':ok,'message':msg,'text':text})
            if p=='/api/reports/send-cut':
                sid=int(d.get('session_id',0));text=cut_report_text(c,sid)
                if not text:c.close();return self.send_json({'error':'Corte no encontrado'},404)
                s=one(c,'SELECT * FROM cash_sessions WHERE id=?',(sid,));ok,msg=send_gmail(c,f"SUPER-UNI · Corte {s['cashbox']} · {s['user_name']}",text)
                c.close();return self.send_json({'ok':ok,'message':msg,'text':text})
            if p=='/api/transfers':
                amount=float(d.get('amount',0) or 0)
                if amount<=0:c.close();return self.send_json({'error':'Monto inválido'},400)
                cur.execute("INSERT INTO transfers(amount,reference,note,status,created_by,created_at) VALUES(?,?,?,?,?,?)",(amount,d.get('reference','').strip(),d.get('note','').strip(),'PENDING',d.get('user_name',''),now()))
                tid=cur.lastrowid;add_notification(c,'Transferencia pendiente',f"Se registró una transferencia por ${amount:,.2f} pendiente de confirmación.",'INFO');c.commit();c.close();return self.send_json({'id':tid},201)
            if p.startswith('/api/transfers/') and p.endswith('/confirm'):
                tid=int(self.path_parts()[2]);tr=one(c,'SELECT * FROM transfers WHERE id=?',(tid,))
                if not tr:c.close();return self.send_json({'error':'Transferencia no encontrada'},404)
                cur.execute("UPDATE transfers SET status='RECEIVED',confirmed_at=?,confirmed_by=? WHERE id=?",(now(),d.get('user_name','ADMIN'),tid))
                add_notification(c,'TRANSFERENCIA RECIBIDA',f"${float(tr['amount']):,.2f} · Ref. {tr['reference'] or 'sin referencia'}",'OK');c.commit();c.close();return self.send_json({'ok':True})
            if p=='/api/transfers/webhook':
                token=self.headers.get('X-SUPERUNI-TOKEN','') or d.get('token','')
                if token!=get_setting(c,'transfer_webhook_token'):c.close();return self.send_json({'error':'Token inválido'},403)
                ref=d.get('reference','').strip();amount=float(d.get('amount',0) or 0)
                tr=one(c,"SELECT * FROM transfers WHERE status='PENDING' AND (?='' OR reference=?) AND (?<=0 OR ABS(amount-?)<0.01) ORDER BY id DESC LIMIT 1",(ref,ref,amount,amount))
                if not tr:c.close();return self.send_json({'error':'No hay transferencia pendiente coincidente'},404)
                cur.execute("UPDATE transfers SET status='RECEIVED',confirmed_at=?,confirmed_by='INTEGRACION' WHERE id=?",(now(),tr['id']))
                add_notification(c,'TRANSFERENCIA RECIBIDA',f"${float(tr['amount']):,.2f} · Ref. {tr['reference'] or 'sin referencia'} · Confirmación automática",'OK');c.commit();c.close();return self.send_json({'ok':True,'transfer_id':tr['id']})
            if p=='/api/notifications/read-all':
                cur.execute('UPDATE notifications SET read_flag=1');c.commit();c.close();return self.send_json({'ok':True})
            c.close();return self.send_json({'error':'Ruta no encontrada'},404)
        except ValueError as e:
            try:c.rollback();c.close()
            except:pass
            return self.send_json({'error':str(e)},400)
        except Exception as e:
            try:c.rollback();c.close()
            except:pass
            return self.send_json({'error':str(e)},500)
    def do_PUT(self):
        p=urlparse(self.path).path;parts=self.path_parts();d=self.body()
        if len(parts)!=3 or parts[:2]!=['api','products']:return self.send_json({'error':'Ruta no encontrada'},404)
        pid=int(parts[2]);c=db();old=one(c,'SELECT * FROM products WHERE id=?',(pid,))
        if not old:c.close();return self.send_json({'error':'Producto no encontrado'},404)
        v={k:d.get(k,old[k]) for k in ['barcode','name','provider','presentation','category','supplier_price','sale_price','stock','min_stock']}
        try:c.execute('UPDATE products SET barcode=?,name=?,provider=?,presentation=?,category=?,supplier_price=?,sale_price=?,stock=?,min_stock=?,updated_at=? WHERE id=?',(v['barcode'] or None,v['name'],v['provider'],v['presentation'],v['category'],float(v['supplier_price']),float(v['sale_price']),int(v['stock']),int(v['min_stock']),now(),pid));c.commit()
        except sqlite3.IntegrityError:c.close();return self.send_json({'error':'Ese código de barras ya existe'},400)
        out=one(c,'SELECT * FROM products WHERE id=?',(pid,));c.close();return self.send_json(out)

if __name__=='__main__':
    init_db();
    try: open(PID_PATH,'w',encoding='utf-8').write(str(os.getpid()))
    except: pass
    install_launcher_update();threading.Thread(target=backup_scheduler,daemon=True).start();print('\nSUPER-UNI POS iniciado.\nEn esta PC: http://127.0.0.1:5000\nEn otras PCs/teléfono: http://IP-DE-ESTA-PC:5000\n');ThreadingHTTPServer(('0.0.0.0',5000),Handler).serve_forever()
