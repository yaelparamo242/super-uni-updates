import base64
import urllib
import urllib.parse
import urllib.request
import urllib.error
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse, parse_qs
import sqlite3, os, json, hashlib, mimetypes, smtplib, ssl, secrets, shutil, threading, time, socket, uuid
from email.message import EmailMessage
from datetime import datetime, date, timedelta

APP_DIR=os.path.dirname(os.path.abspath(__file__))
DATA_DIR=os.environ.get('SUPER_UNI_DATA_DIR',os.path.join(os.path.dirname(APP_DIR),'DATOS'))
os.makedirs(DATA_DIR,exist_ok=True)
DB_PATH=os.path.join(DATA_DIR,'super_uni_pos.db')
STATIC_DIR=os.path.join(APP_DIR,'static')
BACKUP_DIR=os.path.join(DATA_DIR,'RESPALDOS')
os.makedirs(BACKUP_DIR,exist_ok=True)
VERSION_PATH=os.path.join(APP_DIR,'version.json')
BACKUP_LOCK=threading.Lock()
PID_PATH=os.path.join(DATA_DIR,'super_uni_server.pid')
PID_PATH=os.path.join(DATA_DIR,'super_uni_server.pid')
PROVIDERS=['BARCEL','BIMBO','BOING','CIGARROS','COCA COLA','COSTEÑA','DANONE','DULCES','GAMESA','HOLANDA','JARRITOS','LALA','PEÑAFIEL','PEPSI','SABRITAS','SOL','YAKULT','YOPLAIT','ZORRO']

def now(): return datetime.now().isoformat(timespec='seconds')
def pin_hash(pin): return hashlib.sha256(str(pin).encode()).hexdigest()

def local_ip():
    try:
        s=socket.socket(socket.AF_INET,socket.SOCK_DGRAM)
        s.connect(("8.8.8.8",80))
        ip=s.getsockname()[0]
        s.close()
        return ip
    except Exception:
        try:return socket.gethostbyname(socket.gethostname())
        except:return "127.0.0.1"
def db():
    c=sqlite3.connect(DB_PATH,timeout=20); c.row_factory=sqlite3.Row; c.execute('PRAGMA foreign_keys=ON'); return c

def init_db():
    c=db(); cur=c.cursor(); cur.executescript('''
    CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT UNIQUE NOT NULL,role TEXT NOT NULL DEFAULT 'CAJERO',pin_hash TEXT NOT NULL,active INTEGER NOT NULL DEFAULT 1,created_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS products(id INTEGER PRIMARY KEY AUTOINCREMENT,barcode TEXT UNIQUE,name TEXT NOT NULL,provider TEXT NOT NULL,presentation TEXT,category TEXT,supplier_price REAL NOT NULL DEFAULT 0,sale_price REAL NOT NULL DEFAULT 0,stock INTEGER NOT NULL DEFAULT 0,min_stock INTEGER NOT NULL DEFAULT 0,active INTEGER NOT NULL DEFAULT 1,created_at TEXT NOT NULL,updated_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS inventory_movements(id INTEGER PRIMARY KEY AUTOINCREMENT,product_id INTEGER NOT NULL,movement_type TEXT NOT NULL,qty INTEGER NOT NULL,stock_before INTEGER NOT NULL,stock_after INTEGER NOT NULL,note TEXT,user_name TEXT,created_at TEXT NOT NULL,FOREIGN KEY(product_id) REFERENCES products(id));
    CREATE TABLE IF NOT EXISTS inventory_receipts(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        provider TEXT NOT NULL,
        user_name TEXT NOT NULL,
        status TEXT NOT NULL DEFAULT 'OPEN',
        started_at TEXT NOT NULL,
        ended_at TEXT,
        email_sent INTEGER NOT NULL DEFAULT 0,
        email_message TEXT
    );
    CREATE TABLE IF NOT EXISTS inventory_receipt_items(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        receipt_id INTEGER NOT NULL,
        product_id INTEGER NOT NULL,
        product_name TEXT NOT NULL,
        movement_type TEXT NOT NULL,
        qty INTEGER NOT NULL,
        stock_before INTEGER NOT NULL,
        stock_after INTEGER NOT NULL,
        note TEXT,
        created_at TEXT NOT NULL,
        FOREIGN KEY(receipt_id) REFERENCES inventory_receipts(id),
        FOREIGN KEY(product_id) REFERENCES products(id)
    );
    CREATE TABLE IF NOT EXISTS ticket_reservations(folio INTEGER PRIMARY KEY,created_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS mp_point_orders(order_id TEXT PRIMARY KEY,terminal_id TEXT NOT NULL,amount_cents INTEGER NOT NULL,status TEXT NOT NULL DEFAULT 'created',sale_id INTEGER UNIQUE,created_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS sales(id INTEGER PRIMARY KEY AUTOINCREMENT,total REAL NOT NULL,payment_method TEXT NOT NULL,received REAL NOT NULL DEFAULT 0,change_due REAL NOT NULL DEFAULT 0,cashbox TEXT NOT NULL,user_name TEXT,voided INTEGER NOT NULL DEFAULT 0,void_reason TEXT,created_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS sale_items(id INTEGER PRIMARY KEY AUTOINCREMENT,sale_id INTEGER NOT NULL,product_id INTEGER NOT NULL,product_name TEXT NOT NULL,qty INTEGER NOT NULL,unit_price REAL NOT NULL,supplier_price REAL NOT NULL,line_total REAL NOT NULL,FOREIGN KEY(sale_id) REFERENCES sales(id),FOREIGN KEY(product_id) REFERENCES products(id));
    CREATE TABLE IF NOT EXISTS cash_sessions(id INTEGER PRIMARY KEY AUTOINCREMENT,cashbox TEXT NOT NULL,user_name TEXT NOT NULL,opening_amount REAL NOT NULL DEFAULT 0,opened_at TEXT NOT NULL,closed_at TEXT,closing_counted REAL,expected_cash REAL,difference REAL,status TEXT NOT NULL DEFAULT 'OPEN');
    CREATE TABLE IF NOT EXISTS cash_movements(id INTEGER PRIMARY KEY AUTOINCREMENT,session_id INTEGER NOT NULL,movement_type TEXT NOT NULL,amount REAL NOT NULL,note TEXT,user_name TEXT,created_at TEXT NOT NULL,FOREIGN KEY(session_id) REFERENCES cash_sessions(id));
    CREATE TABLE IF NOT EXISTS purchase_comparisons(id INTEGER PRIMARY KEY AUTOINCREMENT,product_id INTEGER NOT NULL,qty INTEGER NOT NULL,supplier_price REAL NOT NULL,wholesale_price REAL NOT NULL,supplier_total REAL NOT NULL,wholesale_total REAL NOT NULL,savings REAL NOT NULL,add_to_stock INTEGER NOT NULL DEFAULT 0,created_at TEXT NOT NULL,FOREIGN KEY(product_id) REFERENCES products(id));
    CREATE TABLE IF NOT EXISTS app_settings(key TEXT PRIMARY KEY,value TEXT);
    CREATE TABLE IF NOT EXISTS custom_providers(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT UNIQUE NOT NULL,created_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS departments(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT UNIQUE NOT NULL,created_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS promotions(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,trigger_qty INTEGER NOT NULL DEFAULT 1,max_uses INTEGER NOT NULL DEFAULT 1,enabled INTEGER NOT NULL DEFAULT 1,created_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS promotion_products(promotion_id INTEGER NOT NULL,product_id INTEGER NOT NULL,PRIMARY KEY(promotion_id,product_id));
    CREATE TABLE IF NOT EXISTS user_permissions(user_id INTEGER NOT NULL,panel TEXT NOT NULL,allowed INTEGER NOT NULL DEFAULT 1,PRIMARY KEY(user_id,panel),FOREIGN KEY(user_id) REFERENCES users(id));
    CREATE TABLE IF NOT EXISTS notifications(id INTEGER PRIMARY KEY AUTOINCREMENT,title TEXT NOT NULL,message TEXT NOT NULL,level TEXT NOT NULL DEFAULT 'INFO',read_flag INTEGER NOT NULL DEFAULT 0,created_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS service_withdrawals(id INTEGER PRIMARY KEY AUTOINCREMENT,session_id INTEGER NOT NULL,cashbox TEXT NOT NULL,user_name TEXT NOT NULL,amount_cents INTEGER NOT NULL,fee_cents INTEGER NOT NULL,charged_cents INTEGER NOT NULL,payment_reference TEXT NOT NULL UNIQUE,created_at TEXT NOT NULL,FOREIGN KEY(session_id) REFERENCES cash_sessions(id));
    CREATE TABLE IF NOT EXISTS transfers(id INTEGER PRIMARY KEY AUTOINCREMENT,amount REAL NOT NULL,reference TEXT,note TEXT,status TEXT NOT NULL DEFAULT 'PENDING',created_by TEXT,created_at TEXT NOT NULL,confirmed_at TEXT,confirmed_by TEXT);
    ''')
    sale_cols={x['name'] for x in cur.execute("PRAGMA table_info(sales)").fetchall()}
    if 'session_id' not in sale_cols: cur.execute('ALTER TABLE sales ADD COLUMN session_id INTEGER')
    cur.execute('CREATE INDEX IF NOT EXISTS idx_sales_session ON sales(session_id)')
    cols={x['name'] for x in cur.execute("PRAGMA table_info(cash_sessions)").fetchall()}
    for name,decl in [
        ('declared_transfers','REAL'),('expected_transfers','REAL'),('transfer_difference','REAL'),
        ('declared_card','REAL'),('expected_card','REAL'),('card_difference','REAL'),
        ('declared_withdrawals','REAL'),('expected_withdrawals','REAL'),('withdrawal_difference','REAL'),
        ('cut_note','TEXT')
    ]:
        if name not in cols: cur.execute(f"ALTER TABLE cash_sessions ADD COLUMN {name} {decl}")
    if cur.execute('SELECT COUNT(*) c FROM users').fetchone()['c']==0:
        cur.executemany('INSERT INTO users(name,role,pin_hash,created_at) VALUES(?,?,?,?)',[('ADMIN','ADMIN',pin_hash('1234'),now()),('CAJERO 1','CAJERO',pin_hash('1111'),now()),('CAJERO 2','CAJERO',pin_hash('2222'),now())])
    # v0.9.5: habilitar una sola vez todos los permisos a FERNANDA.
    if not cur.execute("SELECT 1 FROM app_settings WHERE key='migration_095_fernanda_permissions'").fetchone():
        fu=cur.execute("SELECT id FROM users WHERE UPPER(TRIM(name))='FERNANDA' AND active=1 LIMIT 1").fetchone()
        if fu:
            for panel in ('venta','inventario','productos','compras','config','caja','reportes'):
                cur.execute("INSERT INTO user_permissions(user_id,panel,allowed) VALUES(?,?,1) ON CONFLICT(user_id,panel) DO UPDATE SET allowed=1",(fu['id'],panel))
        cur.execute("INSERT OR REPLACE INTO app_settings(key,value) VALUES('migration_095_fernanda_permissions','1')")
    if cur.execute('SELECT COUNT(*) c FROM products').fetchone()['c']==0:
        t=now();cur.executemany('INSERT INTO products(barcode,name,provider,presentation,category,supplier_price,sale_price,stock,min_stock,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?)',[
        ('7501013101234','Coca Cola 600 ml','COCA COLA','600 ml','REFRESCOS',14,20,30,10,t,t),('7500478022047','Pepsi 600 ml','PEPSI','600 ml','REFRESCOS',13,19,25,8,t,t),('7501055300887','Sabritas Original 170 g','SABRITAS','170 g','BOTANAS',30,42,18,6,t,t)])
    # Catalogo inicial SUPER-UNI v0.5.9: inserta productos aprobados sin borrar ni duplicar los existentes.
    catalog=[('Bonafont 600 ml', 'BONAFONT', '600 ml', 'BEBIDAS', 10, 13), ('Bonafont 1 L', 'BONAFONT', '1 L', 'BEBIDAS', 10.8, 15), ('Bonafont 1.5 L', 'BONAFONT', '1.5 L', 'BEBIDAS', 12.5, 18), ('Bonafont Té 500 ml', 'BONAFONT', 'Té 500 ml', 'BEBIDAS', 14.3, 22), ('Bonafont Jugo Jamaica 1 L', 'BONAFONT', '1 L', 'BEBIDAS', 17.5, 22), ('Bonafont Jugo Naranja 1 L', 'BONAFONT', '1 L', 'BEBIDAS', 17.5, 22), ('Bonafont Jugo Limón 1 L', 'BONAFONT', '1 L', 'BEBIDAS', 17.5, 22), ('Bonafont Jugo Piña 1 L', 'BONAFONT', '1 L', 'BEBIDAS', 17.5, 22), ('Bonafont Jugo Mango 1 L', 'BONAFONT', '1 L', 'BEBIDAS', 17.5, 22), ('Bonafont Jugo Tamarindo 1 L', 'BONAFONT', '1 L', 'BEBIDAS', 17.5, 22), ('Bonafont Jugo Guayaba 1 L', 'BONAFONT', '1 L', 'BEBIDAS', 17.5, 22), ('Bonafont Jugo Jamaica 1.4 L', 'BONAFONT', '1.4 L', 'BEBIDAS', 19.2, 25), ('Bonafont Jugo Mango 1.4 L', 'BONAFONT', '1.4 L', 'BEBIDAS', 19.2, 25), ('Bonafont Jugo Naranja 1.4 L', 'BONAFONT', '1.4 L', 'BEBIDAS', 19.2, 25), ('Bonafont Jugo Guayaba 1.4 L', 'BONAFONT', '1.4 L', 'BEBIDAS', 19.2, 25), ('Levité Pepino-Limón 1 L', 'BONAFONT', '1 L', 'BEBIDAS', 18.3, 22), ('Levité Piña-Coco 1 L', 'BONAFONT', '1 L', 'BEBIDAS', 18.3, 22), ('Levité Frutos Rojos 1 L', 'BONAFONT', '1 L', 'BEBIDAS', 18.3, 22), ('Levité Jamaica 1 L', 'BONAFONT', '1 L', 'BEBIDAS', 18.3, 22), ('Levité Pepino-Limón 1.4 L', 'BONAFONT', '1.4 L', 'BEBIDAS', 20.8, 25), ('Levité Piña-Coco 1.4 L', 'BONAFONT', '1.4 L', 'BEBIDAS', 20.8, 25), ('Levité Frutos Rojos 1.4 L', 'BONAFONT', '1.4 L', 'BEBIDAS', 20.8, 25), ('Levité Jamaica 1.4 L', 'BONAFONT', '1.4 L', 'BEBIDAS', 20.8, 25), ('Sabritas RC Sal', 'SABRITAS', '57 g', 'BOTANAS', 17.12, 20), ('Sabritas R.C Jalapeño', 'SABRITAS', '57 g', 'BOTANAS', 17.12, 20), ('Sabritas RC FH', 'SABRITAS', '57 g', 'BOTANAS', 17.12, 20), ('Sabritas Sal', 'SABRITAS', '45 g', 'BOTANAS', 17.12, 20), ('Sabritas C & E', 'SABRITAS', '42 g', 'BOTANAS', 17.12, 20), ('Sabritas Limón', 'SABRITAS', '42 g', 'BOTANAS', 17.12, 20), ('Sabritas FH', 'SABRITAS', '42 g', 'BOTANAS', 17.12, 20), ('Sabritas Adobadas', 'SABRITAS', '42 g', 'BOTANAS', 17.12, 20), ('Sabritas Habanero', 'SABRITAS', '42 g', 'BOTANAS', 17.12, 20), ('Mega Crunch Jalapeño', 'SABRITAS', '42 g', 'BOTANAS', 17.12, 20), ('Mega Crunch Salsa Roja', 'SABRITAS', '42 g', 'BOTANAS', 17.12, 20), ('Mega Crunch FH', 'SABRITAS', '42 g', 'BOTANAS', 17.12, 20), ('Ruffles Sal', 'SABRITAS', '48 g', 'BOTANAS', 17.12, 20), ('Ruffles Queso', 'SABRITAS', '48 g', 'BOTANAS', 17.12, 20), ('Doritos Nacho', 'SABRITAS', '58 g', 'BOTANAS', 17.12, 20), ('Doritos Incógnita', 'SABRITAS', '58 g', 'BOTANAS', 17.12, 20), ('Doritos Pizzerola', 'SABRITAS', '58 g', 'BOTANAS', 17.12, 20), ('Doritos 3D', 'SABRITAS', '50 g', 'BOTANAS', 17.12, 20), ('Doritos Flamin Hot', 'SABRITAS', '58 g', 'BOTANAS', 17.12, 20), ('Doritos Dinamita', 'SABRITAS', '70 g', 'BOTANAS', 17.12, 20), ('Dorito Dinamita FH', 'SABRITAS', '70 g', 'BOTANAS', 17.12, 20), ('Doritos Diablo', 'SABRITAS', '58 g', 'BOTANAS', 17.12, 20), ('Tostito Salsa Verde', 'SABRITAS', '62 g', 'BOTANAS', 17.12, 20), ('Tostito FH', 'SABRITAS', '62 g', 'BOTANAS', 17.12, 20), ('Fritos Chile y Limón', 'SABRITAS', '60 g', 'BOTANAS', 15.41, 18), ('Fritos Sal', 'SABRITAS', '60 g', 'BOTANAS', 15.41, 18), ('Fritos Chorizo y Chipotle', 'SABRITAS', '60 g', 'BOTANAS', 15.41, 18), ('Frito FH', 'SABRITAS', '70 g', 'BOTANAS', 15.41, 18), ('Cheetos Torcidito', 'SABRITAS', '55 g', 'BOTANAS', 14.55, 17), ('Cheetos Flamin Hot', 'SABRITAS', '52 g', 'BOTANAS', 14.55, 17), ('Cheetos Nacho', 'SABRITAS', '58 g', 'BOTANAS', 14.55, 17), ('Cheetos Bolita', 'SABRITAS', '46 g', 'BOTANAS', 14.55, 17), ('Cheetos Colmillo', 'SABRITAS', '27 g', 'BOTANAS', 14.55, 17), ('Cheetos Palomitas', 'SABRITAS', '29 g', 'BOTANAS', 14.55, 17), ('Cheetos Poffs', 'SABRITAS', '44 g', 'BOTANAS', 14.55, 17), ('Cheetos Poff FH', 'SABRITAS', '42 g', 'BOTANAS', 14.55, 17), ('Paketaxo Botanero', 'SABRITAS', '81 g', 'BOTANAS', 18.84, 22), ('Paketaxo Mezcladito', 'SABRITAS', '81 g', 'BOTANAS', 18.84, 22), ('Paketaxo Xtra FH', 'SABRITAS', '81 g', 'BOTANAS', 18.84, 22), ('Paketaxo Quexo', 'SABRITAS', '81 g', 'BOTANAS', 18.84, 22), ('Churrumais Limón', 'SABRITAS', '70 g', 'BOTANAS', 14.55, 17), ('Churrumais FH', 'SABRITAS', '70 g', 'BOTANAS', 14.55, 17), ('Chicharrón de Cerdo', 'SABRITAS', '30 g', 'BOTANAS', 17.12, 20), ('Rancheritos', 'SABRITAS', '58 g', 'BOTANAS', 15.41, 18), ('Crujitos', 'SABRITAS', '42 g', 'BOTANAS', 15.41, 18), ('Sabritones', 'SABRITAS', '60 g', 'BOTANAS', 12.8, 16), ('Crujito FH', 'SABRITAS', '40 g', 'BOTANAS', 8.56, 10), ('Cheetos mix', 'SABRITAS', '41 g', 'BOTANAS', 8.56, 10), ('Paketaxo Queso', 'SABRITAS', '35 g', 'BOTANAS', 8.56, 10), ('Paketaxo Dark', 'SABRITAS', '44 g', 'BOTANAS', 8.56, 10), ('Pizzerolas', 'SABRITAS', '41 g', 'BOTANAS', 12.84, 15), ('Quesabritas', 'SABRITAS', '40 g', 'BOTANAS', 12.84, 15), ('Bolzaza', 'SABRITAS', '', 'BOTANAS', 21.35, 25), ('Mantecadas Nuez 6p', 'BIMBO', '184 g', 'PAN/GALLETAS', 26.56, 32), ('Mantecadas Vainilla 6p', 'BIMBO', '188 g', 'PAN/GALLETAS', 26.56, 32), ('Panquecitos Gota de Chocolate 2p', 'BIMBO', '140 g', 'PAN/GALLETAS', 18.26, 22), ('Rebanadas', 'BIMBO', '55 g', 'PAN/GALLETAS', 8.3, 10), ('Roles Canela 3p', 'BIMBO', '180 g', 'PAN/GALLETAS', 20.75, 25), ('Roles Glass 3p', 'BIMBO', '205 g', 'PAN/GALLETAS', 20.75, 25), ('Chocotorro', 'BIMBO', '50 g', 'PAN/GALLETAS', 12.45, 15), ('Dálmata', 'BIMBO', '55 g', 'PAN/GALLETAS', 12.45, 15), ('Twinkies Vainilla 3p', 'BIMBO', '114 g', 'PAN/GALLETAS', 15.77, 19), ('Twinkies Chocolate 3p', 'BIMBO', '114 g', 'PAN/GALLETAS', 15.77, 19), ('Bran Frut Fresa', 'BIMBO', '58 g', 'PAN/GALLETAS', 9.96, 12), ('Bran Frut Piña', 'BIMBO', '58 g', 'PAN/GALLETAS', 9.96, 12), ('Barritas Fresa', 'BIMBO', '75 g', 'PAN/GALLETAS', 15.12, 18), ('Barritas Moras', 'BIMBO', '75 g', 'PAN/GALLETAS', 15.12, 18), ('Barritas Piña', 'BIMBO', '75 g', 'PAN/GALLETAS', 15.12, 18), ('Bombonete', 'BIMBO', '55 g', 'PAN/GALLETAS', 12.6, 15), ('Canelitas', 'BIMBO', '120 g +2p', 'PAN/GALLETAS', 20.16, 24), ('Fruti Sponch 8p', 'BIMBO', '124 g', 'PAN/GALLETAS', 20.16, 24), ('Platívolos', 'BIMBO', '90 g', 'PAN/GALLETAS', 16.8, 20), ('Polvorones 6p', 'BIMBO', '148 g +2p', 'PAN/GALLETAS', 20.16, 24), ('Rocko', 'BIMBO', '44 g', 'PAN/GALLETAS', 8.4, 10), ('Sponch', 'BIMBO', '120 g', 'PAN/GALLETAS', 18.48, 22), ('Príncipe Chocolate 12p +2p', 'BIMBO', '126 g', 'PAN/GALLETAS', 20.16, 24), ('Príncipe Avellana 12p +2p', 'BIMBO', '126 g', 'PAN/GALLETAS', 20.16, 24), ('Príncipe Chocolate Blanco 12p +2p', 'BIMBO', '126 g', 'PAN/GALLETAS', 20.16, 24), ('Príncipe Limón 12p +2p', 'BIMBO', '126 g', 'PAN/GALLETAS', 20.16, 24), ('MaxiTubos Príncipe', 'BIMBO', '', 'PAN/GALLETAS', 26.88, 32), ('MaxiTubos Triki Trakes', 'BIMBO', '', 'PAN/GALLETAS', 26.88, 32), ('MaxiTubos Canelitas', 'BIMBO', '', 'PAN/GALLETAS', 26.88, 32), ('MaxiTubos Sponch', 'BIMBO', '', 'PAN/GALLETAS', 26.88, 32), ('MaxiTubos Polvorones', 'BIMBO', '', 'PAN/GALLETAS', 26.88, 32), ('MaxiTubos Mini Barritas Fresa', 'BIMBO', '', 'PAN/GALLETAS', 26.88, 32), ('MaxiTubos Mini Barritas Piña', 'BIMBO', '', 'PAN/GALLETAS', 26.88, 32), ('Choco Roles 25pct más 2p', 'BIMBO', '100 g', 'PAN/GALLETAS', 18.26, 22), ('Dúo Mini Pay Piña', 'BIMBO', '110 g', 'PAN/GALLETAS', 20.75, 25), ('Dúo Mini Pay Nuez', 'BIMBO', '96 g', 'PAN/GALLETAS', 20.75, 25), ('Dúo Napolitano', 'BIMBO', '140 g', 'PAN/GALLETAS', 20.75, 25), ('Mini Choco Roles', 'BIMBO', '28 g', 'PAN/GALLETAS', 6.64, 8), ('Mini Gansito', 'BIMBO', '24 g', 'PAN/GALLETAS', 6.64, 8), ("Pastelito Hershey's 1p", 'BIMBO', '40 g', 'PAN/GALLETAS', 11.62, 14), ('Rollo Fresa', 'BIMBO', '75 g', 'PAN/GALLETAS', 14.94, 18), ('Leche Gansito', 'BIMBO', '236 ml', 'PAN/GALLETAS', 12.45, 15), ('Leche Nito', 'BIMBO', '236 ml', 'PAN/GALLETAS', 12.45, 15), ('Submarinos Chocolate', 'BIMBO', '105 g', 'PAN/GALLETAS', 16.6, 20), ('Submarinos Fresa', 'BIMBO', '105 g', 'PAN/GALLETAS', 16.6, 20), ('Submarinos Vainilla', 'BIMBO', '105 g', 'PAN/GALLETAS', 16.6, 20), ('Bigotes Cajeta', 'BIMBO', '80 g', 'PAN/GALLETAS', 13.28, 16), ('Bigotes Chocolate', 'BIMBO', '80 g', 'PAN/GALLETAS', 13.28, 16), ('Doraditas Nuez', 'BIMBO', '127 g', 'PAN/GALLETAS', 14.94, 18), ('Madalenas Cuadradas', 'BIMBO', '44 g', 'PAN/GALLETAS', 8.3, 10), ('Mantecadas Vainilla 3p', 'BIMBO', '157 g', 'PAN/GALLETAS', 21.58, 26), ('Mantecadas Chocolate 3p', 'BIMBO', '143 g', 'PAN/GALLETAS', 21.58, 26), ('Mantecadas Naranja 3p', 'BIMBO', '165 g', 'PAN/GALLETAS', 21.58, 26), ('Mini Divididas en Tiras Doraditas', 'BIMBO', '58 g', 'PAN/GALLETAS', 8.3, 10), ('Galleta con Avena Arándano', 'BIMBO', '66 g', 'PAN/GALLETAS', 10.08, 12), ('Pastisetas Suandy', 'BIMBO', '90 g', 'PAN/GALLETAS', 23.52, 28), ('Tartinas Fresa 8p', 'BIMBO', '133.3 g', 'PAN/GALLETAS', 16.8, 20), ('Tartinas Piña 8p', 'BIMBO', '133.3 g', 'PAN/GALLETAS', 16.8, 20), ('Tartinas Zarzamora 8p', 'BIMBO', '133.3 g', 'PAN/GALLETAS', 16.8, 20), ('Deliciosas Chocochispas', 'BIMBO', '60 g', 'PAN/GALLETAS', 8.4, 10), ('Deliciosas Vainilla', 'BIMBO', '60 g', 'PAN/GALLETAS', 8.4, 10), ('Deliciosas Chocochispas', 'BIMBO', '130 g', 'PAN/GALLETAS', 16.8, 20), ('Deliciosas Vainilla', 'BIMBO', '130 g', 'PAN/GALLETAS', 16.8, 20), ('CAJ Lucky Strike XL Click & Mix', 'CIGARROS', '20s', 'CIGARROS', 100.37, 106), ('Lucky Strike XL Click & Mix Suelto', 'CIGARROS', '1 cigarro', 'CIGARROS', 5.0185, 8), ('CAJ Lucky Strike XL Indigo Wild', 'CIGARROS', '20s', 'CIGARROS', 100.37, 106), ('Lucky Strike XL Indigo Wild Suelto', 'CIGARROS', '1 cigarro', 'CIGARROS', 5.0185, 8), ('CAJ Lucky Strike XL Enigma', 'CIGARROS', '20s', 'CIGARROS', 92.8, 98), ('Lucky Strike XL Enigma Suelto', 'CIGARROS', '1 cigarro', 'CIGARROS', 4.64, 8), ('CAJ Lucky Strike XL Comet', 'CIGARROS', '20s', 'CIGARROS', 92.8, 98), ('Lucky Strike XL Comet Suelto', 'CIGARROS', '1 cigarro', 'CIGARROS', 4.64, 8), ('CAJ Pall Mall XL Alaska', 'CIGARROS', '20s', 'CIGARROS', 92.8, 98), ('Pall Mall XL Alaska Suelto', 'CIGARROS', '1 cigarro', 'CIGARROS', 4.64, 8), ('CAJ Pall Mall XL Tokyo', 'CIGARROS', '20s', 'CIGARROS', 92.8, 98), ('Pall Mall XL Tokyo Suelto', 'CIGARROS', '1 cigarro', 'CIGARROS', 4.64, 8), ('CAJ Pall Mall XL Mykonos', 'CIGARROS', '20s', 'CIGARROS', 92.8, 98), ('Pall Mall XL Mykonos Suelto', 'CIGARROS', '1 cigarro', 'CIGARROS', 4.64, 8), ('CAJ Pall Mall XL Rio', 'CIGARROS', '20s', 'CIGARROS', 92.8, 98), ('Pall Mall XL Rio Suelto', 'CIGARROS', '1 cigarro', 'CIGARROS', 4.64, 8), ('CAJ Pall Mall XL Manila', 'CIGARROS', '20s', 'CIGARROS', 92.8, 98), ('Pall Mall XL Manila Suelto', 'CIGARROS', '1 cigarro', 'CIGARROS', 4.64, 8), ('CAJ Pall Mall XL Hawaii', 'CIGARROS', '20s', 'CIGARROS', 92.8, 98), ('Pall Mall XL Hawaii Suelto', 'CIGARROS', '1 cigarro', 'CIGARROS', 4.64, 8), ('CAJ Pall Mall XL London', 'CIGARROS', '20s', 'CIGARROS', 92.8, 98), ('Pall Mall XL London Suelto', 'CIGARROS', '1 cigarro', 'CIGARROS', 4.64, 8), ('CAJ Pall Mall XL Bora Bora', 'CIGARROS', '20s', 'CIGARROS', 92.8, 98), ('Pall Mall XL Bora Bora Suelto', 'CIGARROS', '1 cigarro', 'CIGARROS', 4.64, 8), ('CAJ Pall Mall XL New York', 'CIGARROS', '20s', 'CIGARROS', 92.8, 98), ('Pall Mall XL New York Suelto', 'CIGARROS', '1 cigarro', 'CIGARROS', 4.64, 8), ('CAJ Pall Mall XL Miami', 'CIGARROS', '20s', 'CIGARROS', 92.8, 98), ('Pall Mall XL Miami Suelto', 'CIGARROS', '1 cigarro', 'CIGARROS', 4.64, 8), ('CAJ Montana Clásicos', 'CIGARROS', '25s', 'CIGARROS', 45.94, 50), ('Montana Clásicos Suelto', 'CIGARROS', '1 cigarro', 'CIGARROS', 1.8376, 6), ('CAJ Boots Clásicos', 'CIGARROS', '25s', 'CIGARROS', 45.94, 50), ('Boots Clásicos Suelto', 'CIGARROS', '1 cigarro', 'CIGARROS', 1.8376, 6)]
    t=now()
    for name,provider,presentation,category,supplier_price,sale_price in catalog:
        if not cur.execute('SELECT 1 FROM products WHERE name=? AND provider=?',(name,provider)).fetchone():
            cur.execute('INSERT INTO products(barcode,name,provider,presentation,category,supplier_price,sale_price,stock,min_stock,created_at,updated_at) VALUES(NULL,?,?,?,?,?,?,0,0,?,?)',(name,provider,presentation,category,supplier_price,sale_price,t,t))
    # Catalogo inicial SUPER-UNI v0.5.9: inserta productos aprobados sin borrar ni duplicar los existentes.
    catalog=[('Bonafont 600 ml', 'BONAFONT', '600 ml', 'BEBIDAS', 10, 13), ('Bonafont 1 L', 'BONAFONT', '1 L', 'BEBIDAS', 10.8, 15), ('Bonafont 1.5 L', 'BONAFONT', '1.5 L', 'BEBIDAS', 12.5, 18), ('Bonafont Té 500 ml', 'BONAFONT', 'Té 500 ml', 'BEBIDAS', 14.3, 22), ('Bonafont Jugo Jamaica 1 L', 'BONAFONT', '1 L', 'BEBIDAS', 17.5, 22), ('Bonafont Jugo Naranja 1 L', 'BONAFONT', '1 L', 'BEBIDAS', 17.5, 22), ('Bonafont Jugo Limón 1 L', 'BONAFONT', '1 L', 'BEBIDAS', 17.5, 22), ('Bonafont Jugo Piña 1 L', 'BONAFONT', '1 L', 'BEBIDAS', 17.5, 22), ('Bonafont Jugo Mango 1 L', 'BONAFONT', '1 L', 'BEBIDAS', 17.5, 22), ('Bonafont Jugo Tamarindo 1 L', 'BONAFONT', '1 L', 'BEBIDAS', 17.5, 22), ('Bonafont Jugo Guayaba 1 L', 'BONAFONT', '1 L', 'BEBIDAS', 17.5, 22), ('Bonafont Jugo Jamaica 1.4 L', 'BONAFONT', '1.4 L', 'BEBIDAS', 19.2, 25), ('Bonafont Jugo Mango 1.4 L', 'BONAFONT', '1.4 L', 'BEBIDAS', 19.2, 25), ('Bonafont Jugo Naranja 1.4 L', 'BONAFONT', '1.4 L', 'BEBIDAS', 19.2, 25), ('Bonafont Jugo Guayaba 1.4 L', 'BONAFONT', '1.4 L', 'BEBIDAS', 19.2, 25), ('Levité Pepino-Limón 1 L', 'BONAFONT', '1 L', 'BEBIDAS', 18.3, 22), ('Levité Piña-Coco 1 L', 'BONAFONT', '1 L', 'BEBIDAS', 18.3, 22), ('Levité Frutos Rojos 1 L', 'BONAFONT', '1 L', 'BEBIDAS', 18.3, 22), ('Levité Jamaica 1 L', 'BONAFONT', '1 L', 'BEBIDAS', 18.3, 22), ('Levité Pepino-Limón 1.4 L', 'BONAFONT', '1.4 L', 'BEBIDAS', 20.8, 25), ('Levité Piña-Coco 1.4 L', 'BONAFONT', '1.4 L', 'BEBIDAS', 20.8, 25), ('Levité Frutos Rojos 1.4 L', 'BONAFONT', '1.4 L', 'BEBIDAS', 20.8, 25), ('Levité Jamaica 1.4 L', 'BONAFONT', '1.4 L', 'BEBIDAS', 20.8, 25), ('Sabritas RC Sal', 'SABRITAS', '57 g', 'BOTANAS', 17.12, 20), ('Sabritas R.C Jalapeño', 'SABRITAS', '57 g', 'BOTANAS', 17.12, 20), ('Sabritas RC FH', 'SABRITAS', '57 g', 'BOTANAS', 17.12, 20), ('Sabritas Sal', 'SABRITAS', '45 g', 'BOTANAS', 17.12, 20), ('Sabritas C & E', 'SABRITAS', '42 g', 'BOTANAS', 17.12, 20), ('Sabritas Limón', 'SABRITAS', '42 g', 'BOTANAS', 17.12, 20), ('Sabritas FH', 'SABRITAS', '42 g', 'BOTANAS', 17.12, 20), ('Sabritas Adobadas', 'SABRITAS', '42 g', 'BOTANAS', 17.12, 20), ('Sabritas Habanero', 'SABRITAS', '42 g', 'BOTANAS', 17.12, 20), ('Mega Crunch Jalapeño', 'SABRITAS', '42 g', 'BOTANAS', 17.12, 20), ('Mega Crunch Salsa Roja', 'SABRITAS', '42 g', 'BOTANAS', 17.12, 20), ('Mega Crunch FH', 'SABRITAS', '42 g', 'BOTANAS', 17.12, 20), ('Ruffles Sal', 'SABRITAS', '48 g', 'BOTANAS', 17.12, 20), ('Ruffles Queso', 'SABRITAS', '48 g', 'BOTANAS', 17.12, 20), ('Doritos Nacho', 'SABRITAS', '58 g', 'BOTANAS', 17.12, 20), ('Doritos Incógnita', 'SABRITAS', '58 g', 'BOTANAS', 17.12, 20), ('Doritos Pizzerola', 'SABRITAS', '58 g', 'BOTANAS', 17.12, 20), ('Doritos 3D', 'SABRITAS', '50 g', 'BOTANAS', 17.12, 20), ('Doritos Flamin Hot', 'SABRITAS', '58 g', 'BOTANAS', 17.12, 20), ('Doritos Dinamita', 'SABRITAS', '70 g', 'BOTANAS', 17.12, 20), ('Dorito Dinamita FH', 'SABRITAS', '70 g', 'BOTANAS', 17.12, 20), ('Doritos Diablo', 'SABRITAS', '58 g', 'BOTANAS', 17.12, 20), ('Tostito Salsa Verde', 'SABRITAS', '62 g', 'BOTANAS', 17.12, 20), ('Tostito FH', 'SABRITAS', '62 g', 'BOTANAS', 17.12, 20), ('Fritos Chile y Limón', 'SABRITAS', '60 g', 'BOTANAS', 15.41, 18), ('Fritos Sal', 'SABRITAS', '60 g', 'BOTANAS', 15.41, 18), ('Fritos Chorizo y Chipotle', 'SABRITAS', '60 g', 'BOTANAS', 15.41, 18), ('Frito FH', 'SABRITAS', '70 g', 'BOTANAS', 15.41, 18), ('Cheetos Torcidito', 'SABRITAS', '55 g', 'BOTANAS', 14.55, 17), ('Cheetos Flamin Hot', 'SABRITAS', '52 g', 'BOTANAS', 14.55, 17), ('Cheetos Nacho', 'SABRITAS', '58 g', 'BOTANAS', 14.55, 17), ('Cheetos Bolita', 'SABRITAS', '46 g', 'BOTANAS', 14.55, 17), ('Cheetos Colmillo', 'SABRITAS', '27 g', 'BOTANAS', 14.55, 17), ('Cheetos Palomitas', 'SABRITAS', '29 g', 'BOTANAS', 14.55, 17), ('Cheetos Poffs', 'SABRITAS', '44 g', 'BOTANAS', 14.55, 17), ('Cheetos Poff FH', 'SABRITAS', '42 g', 'BOTANAS', 14.55, 17), ('Paketaxo Botanero', 'SABRITAS', '81 g', 'BOTANAS', 18.84, 22), ('Paketaxo Mezcladito', 'SABRITAS', '81 g', 'BOTANAS', 18.84, 22), ('Paketaxo Xtra FH', 'SABRITAS', '81 g', 'BOTANAS', 18.84, 22), ('Paketaxo Quexo', 'SABRITAS', '81 g', 'BOTANAS', 18.84, 22), ('Churrumais Limón', 'SABRITAS', '70 g', 'BOTANAS', 14.55, 17), ('Churrumais FH', 'SABRITAS', '70 g', 'BOTANAS', 14.55, 17), ('Chicharrón de Cerdo', 'SABRITAS', '30 g', 'BOTANAS', 17.12, 20), ('Rancheritos', 'SABRITAS', '58 g', 'BOTANAS', 15.41, 18), ('Crujitos', 'SABRITAS', '42 g', 'BOTANAS', 15.41, 18), ('Sabritones', 'SABRITAS', '60 g', 'BOTANAS', 12.8, 16), ('Crujito FH', 'SABRITAS', '40 g', 'BOTANAS', 8.56, 10), ('Cheetos mix', 'SABRITAS', '41 g', 'BOTANAS', 8.56, 10), ('Paketaxo Queso', 'SABRITAS', '35 g', 'BOTANAS', 8.56, 10), ('Paketaxo Dark', 'SABRITAS', '44 g', 'BOTANAS', 8.56, 10), ('Pizzerolas', 'SABRITAS', '41 g', 'BOTANAS', 12.84, 15), ('Quesabritas', 'SABRITAS', '40 g', 'BOTANAS', 12.84, 15), ('Bolzaza', 'SABRITAS', '', 'BOTANAS', 21.35, 25), ('Mantecadas Nuez 6p', 'BIMBO', '184 g', 'PAN/GALLETAS', 26.56, 32), ('Mantecadas Vainilla 6p', 'BIMBO', '188 g', 'PAN/GALLETAS', 26.56, 32), ('Panquecitos Gota de Chocolate 2p', 'BIMBO', '140 g', 'PAN/GALLETAS', 18.26, 22), ('Rebanadas', 'BIMBO', '55 g', 'PAN/GALLETAS', 8.3, 10), ('Roles Canela 3p', 'BIMBO', '180 g', 'PAN/GALLETAS', 20.75, 25), ('Roles Glass 3p', 'BIMBO', '205 g', 'PAN/GALLETAS', 20.75, 25), ('Chocotorro', 'BIMBO', '50 g', 'PAN/GALLETAS', 12.45, 15), ('Dálmata', 'BIMBO', '55 g', 'PAN/GALLETAS', 12.45, 15), ('Twinkies Vainilla 3p', 'BIMBO', '114 g', 'PAN/GALLETAS', 15.77, 19), ('Twinkies Chocolate 3p', 'BIMBO', '114 g', 'PAN/GALLETAS', 15.77, 19), ('Bran Frut Fresa', 'BIMBO', '58 g', 'PAN/GALLETAS', 9.96, 12), ('Bran Frut Piña', 'BIMBO', '58 g', 'PAN/GALLETAS', 9.96, 12), ('Barritas Fresa', 'BIMBO', '75 g', 'PAN/GALLETAS', 15.12, 18), ('Barritas Moras', 'BIMBO', '75 g', 'PAN/GALLETAS', 15.12, 18), ('Barritas Piña', 'BIMBO', '75 g', 'PAN/GALLETAS', 15.12, 18), ('Bombonete', 'BIMBO', '55 g', 'PAN/GALLETAS', 12.6, 15), ('Canelitas', 'BIMBO', '120 g +2p', 'PAN/GALLETAS', 20.16, 24), ('Fruti Sponch 8p', 'BIMBO', '124 g', 'PAN/GALLETAS', 20.16, 24), ('Platívolos', 'BIMBO', '90 g', 'PAN/GALLETAS', 16.8, 20), ('Polvorones 6p', 'BIMBO', '148 g +2p', 'PAN/GALLETAS', 20.16, 24), ('Rocko', 'BIMBO', '44 g', 'PAN/GALLETAS', 8.4, 10), ('Sponch', 'BIMBO', '120 g', 'PAN/GALLETAS', 18.48, 22), ('Príncipe Chocolate 12p +2p', 'BIMBO', '126 g', 'PAN/GALLETAS', 20.16, 24), ('Príncipe Avellana 12p +2p', 'BIMBO', '126 g', 'PAN/GALLETAS', 20.16, 24), ('Príncipe Chocolate Blanco 12p +2p', 'BIMBO', '126 g', 'PAN/GALLETAS', 20.16, 24), ('Príncipe Limón 12p +2p', 'BIMBO', '126 g', 'PAN/GALLETAS', 20.16, 24), ('MaxiTubos Príncipe', 'BIMBO', '', 'PAN/GALLETAS', 26.88, 32), ('MaxiTubos Triki Trakes', 'BIMBO', '', 'PAN/GALLETAS', 26.88, 32), ('MaxiTubos Canelitas', 'BIMBO', '', 'PAN/GALLETAS', 26.88, 32), ('MaxiTubos Sponch', 'BIMBO', '', 'PAN/GALLETAS', 26.88, 32), ('MaxiTubos Polvorones', 'BIMBO', '', 'PAN/GALLETAS', 26.88, 32), ('MaxiTubos Mini Barritas Fresa', 'BIMBO', '', 'PAN/GALLETAS', 26.88, 32), ('MaxiTubos Mini Barritas Piña', 'BIMBO', '', 'PAN/GALLETAS', 26.88, 32), ('Choco Roles 25pct más 2p', 'BIMBO', '100 g', 'PAN/GALLETAS', 18.26, 22), ('Dúo Mini Pay Piña', 'BIMBO', '110 g', 'PAN/GALLETAS', 20.75, 25), ('Dúo Mini Pay Nuez', 'BIMBO', '96 g', 'PAN/GALLETAS', 20.75, 25), ('Dúo Napolitano', 'BIMBO', '140 g', 'PAN/GALLETAS', 20.75, 25), ('Mini Choco Roles', 'BIMBO', '28 g', 'PAN/GALLETAS', 6.64, 8), ('Mini Gansito', 'BIMBO', '24 g', 'PAN/GALLETAS', 6.64, 8), ("Pastelito Hershey's 1p", 'BIMBO', '40 g', 'PAN/GALLETAS', 11.62, 14), ('Rollo Fresa', 'BIMBO', '75 g', 'PAN/GALLETAS', 14.94, 18), ('Leche Gansito', 'BIMBO', '236 ml', 'PAN/GALLETAS', 12.45, 15), ('Leche Nito', 'BIMBO', '236 ml', 'PAN/GALLETAS', 12.45, 15), ('Submarinos Chocolate', 'BIMBO', '105 g', 'PAN/GALLETAS', 16.6, 20), ('Submarinos Fresa', 'BIMBO', '105 g', 'PAN/GALLETAS', 16.6, 20), ('Submarinos Vainilla', 'BIMBO', '105 g', 'PAN/GALLETAS', 16.6, 20), ('Bigotes Cajeta', 'BIMBO', '80 g', 'PAN/GALLETAS', 13.28, 16), ('Bigotes Chocolate', 'BIMBO', '80 g', 'PAN/GALLETAS', 13.28, 16), ('Doraditas Nuez', 'BIMBO', '127 g', 'PAN/GALLETAS', 14.94, 18), ('Madalenas Cuadradas', 'BIMBO', '44 g', 'PAN/GALLETAS', 8.3, 10), ('Mantecadas Vainilla 3p', 'BIMBO', '157 g', 'PAN/GALLETAS', 21.58, 26), ('Mantecadas Chocolate 3p', 'BIMBO', '143 g', 'PAN/GALLETAS', 21.58, 26), ('Mantecadas Naranja 3p', 'BIMBO', '165 g', 'PAN/GALLETAS', 21.58, 26), ('Mini Divididas en Tiras Doraditas', 'BIMBO', '58 g', 'PAN/GALLETAS', 8.3, 10), ('Galleta con Avena Arándano', 'BIMBO', '66 g', 'PAN/GALLETAS', 10.08, 12), ('Pastisetas Suandy', 'BIMBO', '90 g', 'PAN/GALLETAS', 23.52, 28), ('Tartinas Fresa 8p', 'BIMBO', '133.3 g', 'PAN/GALLETAS', 16.8, 20), ('Tartinas Piña 8p', 'BIMBO', '133.3 g', 'PAN/GALLETAS', 16.8, 20), ('Tartinas Zarzamora 8p', 'BIMBO', '133.3 g', 'PAN/GALLETAS', 16.8, 20), ('Deliciosas Chocochispas', 'BIMBO', '60 g', 'PAN/GALLETAS', 8.4, 10), ('Deliciosas Vainilla', 'BIMBO', '60 g', 'PAN/GALLETAS', 8.4, 10), ('Deliciosas Chocochispas', 'BIMBO', '130 g', 'PAN/GALLETAS', 16.8, 20), ('Deliciosas Vainilla', 'BIMBO', '130 g', 'PAN/GALLETAS', 16.8, 20), ('CAJ Lucky Strike XL Click & Mix', 'CIGARROS', '20s', 'CIGARROS', 100.37, 106), ('Lucky Strike XL Click & Mix Suelto', 'CIGARROS', '1 cigarro', 'CIGARROS', 5.0185, 8), ('CAJ Lucky Strike XL Indigo Wild', 'CIGARROS', '20s', 'CIGARROS', 100.37, 106), ('Lucky Strike XL Indigo Wild Suelto', 'CIGARROS', '1 cigarro', 'CIGARROS', 5.0185, 8), ('CAJ Lucky Strike XL Enigma', 'CIGARROS', '20s', 'CIGARROS', 92.8, 98), ('Lucky Strike XL Enigma Suelto', 'CIGARROS', '1 cigarro', 'CIGARROS', 4.64, 8), ('CAJ Lucky Strike XL Comet', 'CIGARROS', '20s', 'CIGARROS', 92.8, 98), ('Lucky Strike XL Comet Suelto', 'CIGARROS', '1 cigarro', 'CIGARROS', 4.64, 8), ('CAJ Pall Mall XL Alaska', 'CIGARROS', '20s', 'CIGARROS', 92.8, 98), ('Pall Mall XL Alaska Suelto', 'CIGARROS', '1 cigarro', 'CIGARROS', 4.64, 8), ('CAJ Pall Mall XL Tokyo', 'CIGARROS', '20s', 'CIGARROS', 92.8, 98), ('Pall Mall XL Tokyo Suelto', 'CIGARROS', '1 cigarro', 'CIGARROS', 4.64, 8), ('CAJ Pall Mall XL Mykonos', 'CIGARROS', '20s', 'CIGARROS', 92.8, 98), ('Pall Mall XL Mykonos Suelto', 'CIGARROS', '1 cigarro', 'CIGARROS', 4.64, 8), ('CAJ Pall Mall XL Rio', 'CIGARROS', '20s', 'CIGARROS', 92.8, 98), ('Pall Mall XL Rio Suelto', 'CIGARROS', '1 cigarro', 'CIGARROS', 4.64, 8), ('CAJ Pall Mall XL Manila', 'CIGARROS', '20s', 'CIGARROS', 92.8, 98), ('Pall Mall XL Manila Suelto', 'CIGARROS', '1 cigarro', 'CIGARROS', 4.64, 8), ('CAJ Pall Mall XL Hawaii', 'CIGARROS', '20s', 'CIGARROS', 92.8, 98), ('Pall Mall XL Hawaii Suelto', 'CIGARROS', '1 cigarro', 'CIGARROS', 4.64, 8), ('CAJ Pall Mall XL London', 'CIGARROS', '20s', 'CIGARROS', 92.8, 98), ('Pall Mall XL London Suelto', 'CIGARROS', '1 cigarro', 'CIGARROS', 4.64, 8), ('CAJ Pall Mall XL Bora Bora', 'CIGARROS', '20s', 'CIGARROS', 92.8, 98), ('Pall Mall XL Bora Bora Suelto', 'CIGARROS', '1 cigarro', 'CIGARROS', 4.64, 8), ('CAJ Pall Mall XL New York', 'CIGARROS', '20s', 'CIGARROS', 92.8, 98), ('Pall Mall XL New York Suelto', 'CIGARROS', '1 cigarro', 'CIGARROS', 4.64, 8), ('CAJ Pall Mall XL Miami', 'CIGARROS', '20s', 'CIGARROS', 92.8, 98), ('Pall Mall XL Miami Suelto', 'CIGARROS', '1 cigarro', 'CIGARROS', 4.64, 8), ('CAJ Montana Clásicos', 'CIGARROS', '25s', 'CIGARROS', 45.94, 50), ('Montana Clásicos Suelto', 'CIGARROS', '1 cigarro', 'CIGARROS', 1.8376, 6), ('CAJ Boots Clásicos', 'CIGARROS', '25s', 'CIGARROS', 45.94, 50), ('Boots Clásicos Suelto', 'CIGARROS', '1 cigarro', 'CIGARROS', 1.8376, 6)]
    t=now()
    for name,provider,presentation,category,supplier_price,sale_price in catalog:
        if not cur.execute('SELECT 1 FROM products WHERE name=? AND provider=?',(name,provider)).fetchone():
            cur.execute('INSERT INTO products(barcode,name,provider,presentation,category,supplier_price,sale_price,stock,min_stock,created_at,updated_at) VALUES(NULL,?,?,?,?,?,?,0,0,?,?)',(name,provider,presentation,category,supplier_price,sale_price,t,t))

    # Catalogo incremental SUPER-UNI v0.6.0: Barcel + Danone.
    catalog_v060=[('7503032606859', "Chip's Papatinas Chilix", 'BARCEL', '31 g', 'BOTANAS', 13.44, 16), ('7500810012284', "Chip's Papatinas Fuego", 'BARCEL', '31 g', 'BOTANAS', 13.44, 16), ('7500810024553', "Chip's Jalapeño", 'BARCEL', '52 g', 'BOTANAS', 16.8, 20), ('7500810024546', "Chip's Fuego", 'BARCEL', '52 g', 'BOTANAS', 16.8, 20), ('7500810024560', "Chip's Sal", 'BARCEL', '52 g', 'BOTANAS', 16.8, 20), ('757528027148', "Chip's Fuego", 'BARCEL', '42 g', 'BOTANAS', 12.6, 15), ('757528027117', "Chip's Jalapeño", 'BARCEL', '42 g', 'BOTANAS', 12.6, 15), ('7501000266203', "Chip's Sal", 'BARCEL', '170 g', 'BOTANAS', 46.2, 55), ('7501000266234', "Chip's Jalapeño", 'BARCEL', '170 g', 'BOTANAS', 46.2, 55), ('757528001889', "Chip's Fuego", 'BARCEL', '170 g', 'BOTANAS', 46.2, 55), ('7500810027783', 'Papas Barcel Sal', 'BARCEL', '28 g', 'BOTANAS', 8.4, 10), ('7500810027745', 'Papas Barcel Adobado', 'BARCEL', '28 g', 'BOTANAS', 8.4, 10), ('7500810027790', 'Papas Barcel Sal', 'BARCEL', '45 g', 'BOTANAS', 13.44, 16), ('7500810027752', 'Papas Barcel Adobado', 'BARCEL', '45 g', 'BOTANAS', 13.44, 16), ('7500810027813', 'Papas Barcel Toreadas', 'BARCEL', '45 g', 'BOTANAS', 13.44, 16), ('7500810014363', 'Papas Barcel Toreadas', 'BARCEL', '170 g', 'BOTANAS', 46.2, 55), ('7500810020975', 'Wapas Nuevo Queso', 'BARCEL', '52 g', 'BOTANAS', 13.44, 16), ('7500810027646', 'Chipotles', 'BARCEL', '65 g', 'BOTANAS', 15.12, 18), ('7501000364039', 'Mini Runners', 'BARCEL', '35 g', 'BOTANAS', 8.4, 10), ('7500810027837', 'Runners', 'BARCEL', '72 g', 'BOTANAS', 15.12, 18), ('7500810027820', 'Runners Fuego', 'BARCEL', '72 g', 'BOTANAS', 15.12, 18), ('7500810028407', 'Runners Blue Heat', 'BARCEL', '72 g', 'BOTANAS', 15.12, 18), ('7500810028599', 'Runners Limón y Sal', 'BARCEL', '72 g', 'BOTANAS', 15.12, 18), ('7501030421269', 'Runners', 'BARCEL', '200 g', 'BOTANAS', 33.6, 40), ('7500810037294', 'Tostachos Queso Jalapeño', 'BARCEL', '75 g', 'BOTANAS', 15.12, 18), ('7501030448242', 'Mini Takis Fuego', 'BARCEL', '35 g', 'BOTANAS', 8.4, 10), ('7500810000441', 'Takis Fajitas', 'BARCEL', '70 g', 'BOTANAS', 16.8, 20), ('7500810000489', 'Takis Huakamole', 'BARCEL', '70 g', 'BOTANAS', 16.8, 20), ('7500810003671', 'Takis Fuego', 'BARCEL', '70 g', 'BOTANAS', 16.8, 20), ('7500810000502', 'Takis Salsa Brava', 'BARCEL', '70 g', 'BOTANAS', 16.8, 20), ('7500810028353', 'Takis Blue Heat', 'BARCEL', '70 g', 'BOTANAS', 16.8, 20), ('7500810036822', 'Takis Chile Limón', 'BARCEL', '70 g', 'BOTANAS', 16.8, 20), ('757528038205', 'Takis Fuego', 'BARCEL', '200 g', 'BOTANAS', 37.8, 45), ('7503030572460', 'Takis Original', 'BARCEL', '200 g', 'BOTANAS', 37.8, 45), ('7500810008874', 'Hot Nuts Original', 'BARCEL', '75 g', 'BOTANAS', 16.8, 20), ('7500810008881', 'Hot Nuts Fuego', 'BARCEL', '75 g', 'BOTANAS', 16.8, 20), ('757528044121', 'Hot Nuts Original', 'BARCEL', '115 g', 'BOTANAS', 21.0, 25), ('757528044138', 'Hot Nuts Fuego', 'BARCEL', '115 g', 'BOTANAS', 21.0, 25), ('7500810029046', 'Golden Nuts Salados', 'BARCEL', '78 g', 'BOTANAS', 16.8, 20), ('7500810029053', 'Golden Nuts Enchilado', 'BARCEL', '78 g', 'BOTANAS', 16.8, 20), ('7500810029879', 'Golden Nuts Fuego', 'BARCEL', '78 g', 'BOTANAS', 16.8, 20), ('7500810027707', 'Golden Nuts Salados', 'BARCEL', '110 g', 'BOTANAS', 21.0, 25), ('7500810027691', 'Golden Nuts Enchilado', 'BARCEL', '110 g', 'BOTANAS', 21.0, 25), ('7500810029886', 'Golden Nuts Fuego', 'BARCEL', '110 g', 'BOTANAS', 21.0, 25), ('7500810027714', 'Kiyakis', 'BARCEL', '60 g', 'BOTANAS', 12.6, 15), ('7500810005064', 'Kiyakis', 'BARCEL', '120 g', 'BOTANAS', 16.8, 20), ('7500810013205', 'Big Mix Inglesa Limón', 'BARCEL', '80 g', 'BOTANAS', 18.48, 22), ('7500810013199', 'Big Mix Fuego', 'BARCEL', '80 g', 'BOTANAS', 18.48, 22), ('7500810013182', 'Big Mix Queso', 'BARCEL', '80 g', 'BOTANAS', 18.48, 22), ('7500810013250', 'Big Mix Fuego', 'BARCEL', '38 g', 'BOTANAS', 8.4, 10), ('757528039271', 'Big Mix Fuego', 'BARCEL', '185 g', 'BOTANAS', 33.6, 40), ('757528039288', 'Big Mix Queso', 'BARCEL', '185 g', 'BOTANAS', 33.6, 40), ('7500810028377', 'Takis Duoz Chips Sal', 'BARCEL', '70 g', 'BOTANAS', 16.8, 20), ('7500810020234', 'Takis Duoz Pop Chilix Sandía', 'BARCEL', '85 g', 'BOTANAS', 16.8, 20), ('7500810005040', 'Karameladas Pop', 'BARCEL', '45 g', 'BOTANAS', 8.4, 10), ('7500810013564', 'Pop Sens Queso', 'BARCEL', '45 g', 'BOTANAS', 13.44, 16), ('7500810005057', 'Karameladas Pop', 'BARCEL', '110 g', 'BOTANAS', 13.44, 16), ('7503030199728', 'Chicharrón de Cerdo', 'BARCEL', '30 g', 'BOTANAS', 15.12, 18), ('7503032248165', 'Chicharrón de Cerdo', 'BARCEL', '70 g', 'BOTANAS', 33.6, 40), ('757528036638', 'Valentones Fuego', 'BARCEL', '60 g', 'BOTANAS', 13.44, 16), ('7501030482055', 'Valentones', 'BARCEL', '175 g', 'BOTANAS', 29.4, 35), ('7500810016930', 'Valentones Fuego', 'BARCEL', '175 g', 'BOTANAS', 29.4, 35), (None, 'Danup Fresa 220 g', 'DANONE', '220 g', 'LÁCTEOS', 14.4, 20), (None, 'Danup Piña Coco 220 g', 'DANONE', '220 g', 'LÁCTEOS', 14.4, 20), (None, 'Danup Galleta 220 g', 'DANONE', '220 g', 'LÁCTEOS', 14.4, 20), (None, 'Danup Fresa 350 g', 'DANONE', '350 g', 'LÁCTEOS', 16.2, 23), (None, 'Danup Piña Coco 350 g', 'DANONE', '350 g', 'LÁCTEOS', 16.2, 23), (None, 'Danup Galleta 350 g', 'DANONE', '350 g', 'LÁCTEOS', 16.2, 23), (None, 'Danone Licuado Fresa-Plátano 435 g', 'DANONE', '435 g', 'LÁCTEOS', 21.1, 26), (None, 'Danone Licuado Frutos Rojos 435 g', 'DANONE', '435 g', 'LÁCTEOS', 21.1, 26), (None, 'Danone Licuado Nuez 435 g', 'DANONE', '435 g', 'LÁCTEOS', 21.1, 26), (None, 'Danone Licuado Quaker Plátano 435 g', 'DANONE', '435 g', 'LÁCTEOS', 21.1, 26), (None, 'Danone Licuado Quaker Fresa 435 g', 'DANONE', '435 g', 'LÁCTEOS', 21.1, 26), (None, 'Activia Fresa 225 g', 'DANONE', '225 g', 'LÁCTEOS', 15.0, 20), (None, 'Activia Chía 225 g', 'DANONE', '225 g', 'LÁCTEOS', 15.0, 20), (None, 'Activia Ciruela Pasa 225 g', 'DANONE', '225 g', 'LÁCTEOS', 15.0, 20), (None, 'Benegastro 240 g', 'DANONE', '240 g', 'LÁCTEOS', 15.8, 20), (None, 'Oikos Selecto 230 g', 'DANONE', '230 g', 'LÁCTEOS', 17.5, 22), (None, 'Oikos Pro 220 g', 'DANONE', '220 g', 'LÁCTEOS', 23.2, 29), (None, 'Oikos Pro Chocolate 220 g', 'DANONE', '220 g', 'LÁCTEOS', 23.2, 29)]
    t=now()
    for barcode,name,provider,presentation,category,supplier_price,sale_price in catalog_v060:
        existing=cur.execute('SELECT id,barcode FROM products WHERE name=? AND provider=? AND COALESCE(presentation,\'\')=?',(name,provider,presentation or '')).fetchone()
        if existing:
            # v0.10.8: NUNCA sobreescribir datos editados por el usuario en arranques.
            # Este catalogo es solo una semilla para productos que no existian.
            # Tampoco reactivar productos dados de baja ni modificar su costo/venta.
            pass
        else:
            try:
                cur.execute('INSERT INTO products(barcode,name,provider,presentation,category,supplier_price,sale_price,stock,min_stock,created_at,updated_at) VALUES(?,?,?,?,?,?,?,0,0,?,?)',(barcode,name,provider,presentation,category,supplier_price,sale_price,t,t))
            except sqlite3.IntegrityError:
                cur.execute('INSERT INTO products(barcode,name,provider,presentation,category,supplier_price,sale_price,stock,min_stock,created_at,updated_at) VALUES(NULL,?,?,?,?,?,?,0,0,?,?)',(name,provider,presentation,category,supplier_price,sale_price,t,t))

    if not cur.execute("SELECT 1 FROM app_settings WHERE key='transfer_webhook_token'").fetchone():
        cur.execute("INSERT INTO app_settings(key,value) VALUES('transfer_webhook_token',?)",(secrets.token_urlsafe(24),))
    cur.execute("INSERT OR IGNORE INTO departments(name,created_at) SELECT DISTINCT UPPER(category),? FROM products WHERE TRIM(COALESCE(category,''))<>''",(now(),))
    c.commit();c.close()


def app_version():
    try:
        with open(VERSION_PATH,'r',encoding='utf-8') as f:return json.load(f).get('version','0.0.0')
    except:return '0.0.0'

def backup_name(reason='daily'):
    stamp=datetime.now().strftime('%Y-%m-%d_%H-%M-%S')
    return f"SUPER_UNI_{reason}_{stamp}.db"

def external_backup_dir(c=None):
    val=''
    try:
        if c: val=get_setting(c,'backup_external_dir','').strip()
        else:
            cx=db(); val=get_setting(cx,'backup_external_dir','').strip(); cx.close()
    except: pass
    if val:return os.path.expandvars(os.path.expanduser(val))
    od=os.environ.get('OneDrive') or os.environ.get('ONEDRIVE')
    return os.path.join(od,'SUPER-UNI Respaldos') if od else ''

def prune_backups(folder,keep=30):
    try:
        files=sorted([os.path.join(folder,x) for x in os.listdir(folder) if x.lower().endswith('.db')],key=os.path.getmtime,reverse=True)
        for f in files[keep:]:
            try:os.remove(f)
            except:pass
    except:pass

def backup_database(reason='manual'):
    with BACKUP_LOCK:
        os.makedirs(BACKUP_DIR,exist_ok=True)
        dest=os.path.join(BACKUP_DIR,backup_name(reason))
        src=sqlite3.connect(DB_PATH,timeout=20)
        dst=sqlite3.connect(dest)
        try:src.backup(dst)
        finally:dst.close();src.close()
        prune_backups(BACKUP_DIR,30)
        ext=external_backup_dir()
        ext_copy=''
        if ext:
            try:
                os.makedirs(ext,exist_ok=True)
                ext_copy=os.path.join(ext,os.path.basename(dest))
                shutil.copy2(dest,ext_copy)
                prune_backups(ext,30)
            except Exception:
                ext_copy=''
        return {'file':os.path.basename(dest),'path':dest,'size':os.path.getsize(dest),'external_copy':ext_copy,'created_at':now(),'reason':reason}

def list_backups():
    out=[]
    os.makedirs(BACKUP_DIR,exist_ok=True)
    for name in sorted(os.listdir(BACKUP_DIR),reverse=True):
        if not name.lower().endswith('.db'):continue
        p=os.path.join(BACKUP_DIR,name)
        st=os.stat(p)
        out.append({'file':name,'size':st.st_size,'modified':datetime.fromtimestamp(st.st_mtime).isoformat(timespec='seconds')})
    return out[:30]

def restore_backup(filename):
    safe=os.path.basename(filename)
    srcpath=os.path.join(BACKUP_DIR,safe)
    if not os.path.isfile(srcpath):raise ValueError('Respaldo no encontrado')
    backup_database('antes_restaurar')
    with BACKUP_LOCK:
        src=sqlite3.connect(srcpath,timeout=20)
        dst=sqlite3.connect(DB_PATH,timeout=20)
        try:src.backup(dst)
        finally:dst.close();src.close()
    return True

def has_daily_backup_today():
    prefix='SUPER_UNI_daily_'+date.today().isoformat()
    return any(x.startswith(prefix) for x in os.listdir(BACKUP_DIR)) if os.path.isdir(BACKUP_DIR) else False

def backup_scheduler():
    while True:
        try:
            if datetime.now().hour>=22 and not has_daily_backup_today():
                backup_database('daily')
        except Exception as e:
            print('[SUPER-UNI] Respaldo automático:',e)
        time.sleep(1800)

def install_launcher_update():
    template=os.path.join(APP_DIR,'launcher_template.pyw')
    target=os.path.join(os.path.dirname(APP_DIR),'SUPER_UNI.pyw')
    if os.path.isfile(template):
        try:
            if not os.path.isfile(target) or open(template,'rb').read()!=open(target,'rb').read():
                shutil.copy2(template,target)
                print('[SUPER-UNI] Actualizador de escritorio actualizado.')
        except Exception as e:print('[SUPER-UNI] No se pudo actualizar launcher:',e)

def rows(c,sql,p=()): return [dict(x) for x in c.execute(sql,p).fetchall()]
def one(c,sql,p=()):
    r=c.execute(sql,p).fetchone(); return dict(r) if r else None

def shift_sales_filter(s):
    # Explicit session ownership for new sales; historical rows retain timestamp fallback.
    return ("(session_id=? OR (session_id IS NULL AND cashbox=? AND user_name=? AND created_at>=? AND created_at<=?))",
            (s['id'],s['cashbox'],s['user_name'],s['opened_at'],s.get('closed_at') or now()))

def session_totals(c,s):
    where,params=shift_sales_filter(s)
    def sum_payment(method):
        return float(c.execute(f"SELECT COALESCE(SUM(total),0) t FROM sales WHERE {where} AND voided=0 AND payment_method=?",params+(method,)).fetchone()['t'])
    cash=sum_payment('EFECTIVO');card=sum_payment('TARJETA');transfer=sum_payment('TRANSFERENCIA')
    withdrawals=float(c.execute("SELECT COALESCE(SUM(amount),0) t FROM cash_movements WHERE session_id=? AND movement_type='WITHDRAWAL'",(s['id'],)).fetchone()['t'])
    deposits=float(c.execute("SELECT COALESCE(SUM(amount),0) t FROM cash_movements WHERE session_id=? AND movement_type='DEPOSIT'",(s['id'],)).fetchone()['t'])
    service_cash=float(c.execute('SELECT COALESCE(SUM(amount_cents),0) n FROM service_withdrawals WHERE session_id=?',(s['id'],)).fetchone()['n'])/100
    service_fee=float(c.execute('SELECT COALESCE(SUM(fee_cents),0) n FROM service_withdrawals WHERE session_id=?',(s['id'],)).fetchone()['n'])/100
    expected_cash=float(s['opening_amount'])+cash+deposits-withdrawals-service_cash
    voids=c.execute(f'SELECT COUNT(*) n FROM sales WHERE {where} AND voided=1',params).fetchone()['n']
    tickets=c.execute(f'SELECT COUNT(*) n FROM sales WHERE {where} AND voided=0',params).fetchone()['n']
    return {'cash_sales':cash,'card_sales':card,'transfer_sales':transfer,'total_sales':round(cash+card+transfer,2),'tickets':tickets,'voided_tickets':voids,'withdrawals':withdrawals,'service_cash_out':service_cash,'service_fees':service_fee,'deposits':deposits,'expected_cash':expected_cash}

def session_expected(c,s):
    return session_totals(c,s)['expected_cash']

def get_setting(c,key,default=''):
    r=c.execute('SELECT value FROM app_settings WHERE key=?',(key,)).fetchone()
    return r['value'] if r else default

def set_setting(c,key,value):
    c.execute("INSERT INTO app_settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",(key,str(value or '')))

def add_notification(c,title,message,level='INFO'):
    c.execute('INSERT INTO notifications(title,message,level,created_at) VALUES(?,?,?,?)',(title,message,level,now()))

def send_gmail(c,subject,body):
    user=get_setting(c,'gmail_user')
    pwd=get_setting(c,'gmail_app_password')
    recipient=get_setting(c,'report_email')
    if not user or not pwd or not recipient:
        return False,'Gmail no configurado'
    msg=EmailMessage()
    msg['Subject']=subject
    msg['From']=user
    msg['To']=recipient
    msg.set_content(body)
    try:
        ctx=ssl.create_default_context()
        with smtplib.SMTP_SSL('smtp.gmail.com',465,context=ctx,timeout=15) as s:
            s.login(user,pwd)
            s.send_message(msg)
        return True,'Enviado'
    except Exception as e:
        return False,str(e)

def cut_report_text(c,sid):
    s=one(c,'SELECT * FROM cash_sessions WHERE id=?',(sid,))
    if not s:return ''
    t=session_totals(c,s)
    sales={'total':t['total_sales'],'tickets':t['tickets']}
    return (
        f"SUPER-UNI - CORTE DE CAJA\n"
        f"Caja: {s['cashbox']}\nCajero: {s['user_name']}\n"
        f"Apertura: {s['opened_at']}\nCierre: {s.get('closed_at') or 'ABIERTO'}\n\n"
        f"Fondo inicial: ${float(s['opening_amount']):,.2f}\n"
        f"Venta total: ${float(sales['total']):,.2f}\nTickets: {sales['tickets']}\n\n"
        f"EFECTIVO\nEsperado: ${float(s.get('expected_cash') or t['expected_cash']):,.2f}\nDeclarado: ${float(s.get('closing_counted') or 0):,.2f}\nDiferencia: ${float(s.get('difference') or 0):,.2f}\n\n"
        f"TARJETA\nSistema: ${float(s.get('expected_card') or t['card_sales']):,.2f}\nDeclarado: ${float(s.get('declared_card') or 0):,.2f}\nDiferencia: ${float(s.get('card_difference') or 0):,.2f}\n\n"
        f"TRANSFERENCIAS\nSistema: ${float(s.get('expected_transfers') or t['transfer_sales']):,.2f}\nDeclarado: ${float(s.get('declared_transfers') or 0):,.2f}\nDiferencia: ${float(s.get('transfer_difference') or 0):,.2f}\n\n"
        f"SALIDAS DE CAJA\nRegistradas: ${float(s.get('expected_withdrawals') or t['withdrawals']):,.2f}\nDeclaradas: ${float(s.get('declared_withdrawals') or 0):,.2f}\nDiferencia: ${float(s.get('withdrawal_difference') or 0):,.2f}\n"
        f"Observaciones: {s.get('cut_note') or ''}\n"
    )


def inventory_receipt_report_text(c,receipt_id):
    r=one(c,'SELECT * FROM inventory_receipts WHERE id=?',(receipt_id,))
    if not r:return ''
    items=rows(c,'SELECT * FROM inventory_receipt_items WHERE receipt_id=? ORDER BY id',(receipt_id,))
    lines=[
        "SUPER-UNI - COMPROBANTE DE INVENTARIADO",
        f"Proveedor: {r['provider']}",
        f"Trabajador: {r['user_name']}",
        f"Inicio: {r['started_at']}",
        f"Fin: {r.get('ended_at') or 'EN PROCESO'}",
        "",
        "MOVIMIENTOS:"
    ]
    for x in items:
        op={'add':'ENTRADA','remove':'SALIDA/MERMA','set':'CONTEO FIJO'}.get(x['movement_type'],x['movement_type'])
        lines.append(f"{x['product_name']} | {op} {x['qty']} | {x['stock_before']} -> {x['stock_after']} | {x.get('note') or ''}")
    lines += ["",f"Total de movimientos: {len(items)}"]
    return "\n".join(lines)

def inventory_report_text(c,limit=100):
    mv=rows(c,'SELECT im.*,p.name product_name FROM inventory_movements im JOIN products p ON p.id=im.product_id ORDER BY im.id DESC LIMIT ?',(limit,))
    lines=["SUPER-UNI - MOVIMIENTOS DE INVENTARIO",""]
    for x in mv:
        lines.append(f"{x['created_at']} | {x['user_name'] or ''} | {x['product_name']} | {x['stock_before']} -> {x['stock_after']} | {x['movement_type']} | {x['note'] or ''}")
    return "\n".join(lines)


MP_API='https://api.mercadopago.com'
def mp_request(token,method,path,payload=None,extra_headers=None):
    data=None if payload is None else json.dumps(payload).encode('utf-8')
    headers={'Authorization':'Bearer '+token,'Content-Type':'application/json'}
    if extra_headers: headers.update(extra_headers)
    req=urllib.request.Request(MP_API+path,data=data,headers=headers,method=method)
    try:
        with urllib.request.urlopen(req,timeout=20) as r:
            raw=r.read().decode('utf-8');return json.loads(raw) if raw else {}
    except urllib.error.HTTPError as e:
        raw=e.read().decode('utf-8','replace')
        try: msg=json.loads(raw).get('message') or raw
        except: msg=raw
        raise Exception('Mercado Pago: '+str(msg))
def mp_token(c):
    t=get_setting(c,'mp_access_token','')
    if not t: raise Exception('Primero guarda tu Access Token en Configuración → Mercado Pago')
    return t

def write_png_ico(png_bytes, dest):
    # ICO supports a PNG-compressed image payload. 0 means 256+ pixels.
    import struct
    header=struct.pack('<HHH',0,1,1)
    entry=struct.pack('<BBBBHHII',0,0,0,0,1,32,len(png_bytes),22)
    Path(dest).write_bytes(header+entry+png_bytes)

def apply_windows_branding(c, app_name, png_bytes=None):
    if os.name!='nt': return False
    try:
        static=Path(STATIC_DIR); ico=static/'custom_app_icon.ico'
        if png_bytes and png_bytes.startswith(b'\x89PNG\r\n\x1a\n'):
            write_png_ico(png_bytes,ico)
        desktop=Path(os.environ.get('USERPROFILE',str(Path.home())))/'Desktop'
        if not desktop.exists():
            od=os.environ.get('OneDrive')
            if od and (Path(od)/'Desktop').exists(): desktop=Path(od)/'Desktop'
        desktop.mkdir(parents=True,exist_ok=True)
        previous=(get_setting(c,'desktop_shortcut_name') or 'SUPER-UNI POS').strip()
        for nm in {previous,'SUPER-UNI POS','SUPER-UNI'}:
            old=desktop/(nm+'.url')
            if old.exists() and nm!=app_name:
                try: old.unlink()
                except: pass
        icon_path=str(ico if ico.exists() else static/'custom_app_icon.png')
        url='http://127.0.0.1:5000/'
        content='[InternetShortcut]\r\nURL='+url+'\r\nIconFile='+icon_path+'\r\nIconIndex=0\r\n'
        (desktop/(app_name+'.url')).write_text(content,encoding='utf-8')
        set_setting(c,'desktop_shortcut_name',app_name)
        return True
    except Exception:
        return False

class Handler(BaseHTTPRequestHandler):
    def log_message(self,fmt,*args): print('[SUPER-UNI]',fmt%args)
    def send_json(self,obj,status=200):
        data=json.dumps(obj,ensure_ascii=False).encode();self.send_response(status);self.send_header('Content-Type','application/json; charset=utf-8');self.send_header('Content-Length',str(len(data)));self.end_headers();self.wfile.write(data)
    def body(self):
        n=int(self.headers.get('Content-Length',0));
        try:return json.loads(self.rfile.read(n) or b'{}')
        except:return {}
    def path_parts(self): return [x for x in urlparse(self.path).path.split('/') if x]
    def serve_file(self,path):
        if not os.path.isfile(path):self.send_error(404);return
        data=open(path,'rb').read();self.send_response(200);self.send_header('Content-Type',mimetypes.guess_type(path)[0] or 'application/octet-stream');self.send_header('Cache-Control','no-store, no-cache, must-revalidate, max-age=0');self.send_header('Pragma','no-cache');self.send_header('Expires','0');self.send_header('Content-Length',len(data));self.end_headers();self.wfile.write(data)
    def do_GET(self):
        u=urlparse(self.path);p=u.path;qs=parse_qs(u.query)
        if p=='/': return self.serve_file(os.path.join(STATIC_DIR,'index.html'))
        if p=='/manifest.webmanifest':
            c=db();name=get_setting(c,'app_name') or 'SUPER-UNI POS';c.close()
            return self.send_json({'name':name,'short_name':name[:30],'start_url':'/','display':'standalone','background_color':'#f3f6fa','theme_color':'#0b1f3a','icons':[{'src':'/static/custom_app_icon.png','sizes':'512x512','type':'image/png','purpose':'any maskable'}]})

        if p.startswith('/static/'):
            rel=os.path.normpath(p[8:]).lstrip('/\\');return self.serve_file(os.path.join(STATIC_DIR,rel))
        try:
            c=db()
            if p=='/api/departments': out=rows(c,'SELECT * FROM departments ORDER BY name')
            elif p=='/api/promotions':
                out=rows(c,"""SELECT p.*,GROUP_CONCAT(pp.product_id) product_ids_csv,GROUP_CONCAT(pr.name, ', ') product_names FROM promotions p LEFT JOIN promotion_products pp ON pp.promotion_id=p.id LEFT JOIN products pr ON pr.id=pp.product_id GROUP BY p.id ORDER BY p.id DESC""")
                for x in out:x['product_ids']=[int(v) for v in (x.pop('product_ids_csv') or '').split(',') if v]
            elif p=='/api/providers':
                custom=[x['name'] for x in rows(c,'SELECT name FROM custom_providers ORDER BY name')]
                used=[x['provider'] for x in rows(c,"SELECT DISTINCT provider FROM products WHERE active=1 AND TRIM(provider)<>'' ORDER BY provider")]
                out=sorted(set(PROVIDERS+custom+used),key=lambda x:x.upper())
            elif p=='/api/mercadopago/spei/status':
                tok=mp_token(c);oid=str(qs.get('id',[''])[0]).strip()
                if not oid:c.close();return self.send_json({'error':'Falta order id'},400)
                r=mp_request(tok,'GET','/v1/orders/'+urllib.parse.quote(oid))
                out={'order_id':r.get('id'),'status':r.get('status'),'status_detail':r.get('status_detail'),'approved':r.get('status')=='processed' and r.get('status_detail')=='accredited'}
            elif p=='/api/mercadopago/point/status':
                oid=str(qs.get('id',[''])[0]).strip()
                rec=one(c,'SELECT * FROM mp_point_orders WHERE order_id=?',(oid,))
                if not rec:c.close();return self.send_json({'error':'Orden Point no encontrada'},404)
                r=mp_request(mp_token(c),'GET','/v1/orders/'+urllib.parse.quote(oid))
                payments=((r.get('transactions') or {}).get('payments') or [])
                approved=r.get('status')=='processed' and any(x.get('status')=='processed' and x.get('status_detail')=='accredited' for x in payments)
                out={'order_id':oid,'status':r.get('status'),'status_detail':r.get('status_detail'),'approved':approved,'sale_id':rec['sale_id']}
            elif p=='/api/mercadopago/config':
                out={'environment':get_setting(c,'mp_environment','test'),'user_id':get_setting(c,'mp_user_id',''),'store_id':get_setting(c,'mp_store_id',''),'pos_id':get_setting(c,'mp_pos_id',''),'configured':bool(get_setting(c,'mp_access_token',''))}
            elif p=='/api/mercadopago/terminals':
                tok=mp_token(c);store=get_setting(c,'mp_store_id','');pos=get_setting(c,'mp_pos_id','');params='?limit=50&offset=0'
                if store:params+='&store_id='+urllib.parse.quote(str(store))
                if pos:params+='&pos_id='+urllib.parse.quote(str(pos))
                r=mp_request(tok,'GET','/terminals/v1/list'+params);out={'terminals':((r.get('data') or {}).get('terminals') or [])}
            elif p=='/api/report-settings':
                out={'report_email':get_setting(c,'report_email',''),'whatsapp_phone':get_setting(c,'whatsapp_phone','')}
            elif p=='/api/users':
                out=rows(c,'SELECT id,name,role,active FROM users ORDER BY name')
                for u0 in out:u0['permissions']={x['panel']:bool(x['allowed']) for x in rows(c,'SELECT panel,allowed FROM user_permissions WHERE user_id=?',(u0['id'],))}
            elif p=='/api/products':
                q=qs.get('q',[''])[0].strip();provider=qs.get('provider',[''])[0].strip();name_only=qs.get('name_only',['0'])[0]=='1';sql='SELECT * FROM products WHERE active=1';pars=[]
                if q:
                    like=f'%{q}%'
                    if name_only:sql+=' AND name LIKE ?';pars.append(like)
                    else:sql+=' AND (name LIKE ? OR COALESCE(barcode,\'\') LIKE ? OR provider LIKE ? OR COALESCE(presentation,\'\') LIKE ?)';pars += [like]*4
                if provider:sql+=' AND provider=?';pars.append(provider)
                out=rows(c,sql+' ORDER BY name',pars)
            elif p=='/api/cash/service-withdrawals':
                out=rows(c,'SELECT * FROM service_withdrawals WHERE substr(created_at,1,10)=? ORDER BY id DESC',(date.today().isoformat(),))
            elif p=='/api/cash/status':out=one(c,"SELECT * FROM cash_sessions WHERE cashbox=? AND status='OPEN' ORDER BY id DESC LIMIT 1",(qs.get('cashbox',['CAJA 1'])[0],)) or {}
            elif p=='/api/cash/preview':
                sess=one(c,"SELECT * FROM cash_sessions WHERE cashbox=? AND status='OPEN' ORDER BY id DESC LIMIT 1",(qs.get('cashbox',['CAJA 1'])[0],)) or {}
                out={'session':sess,'totals':session_totals(c,sess) if sess else {}}

            elif p=='/api/sales':out=rows(c,'SELECT * FROM sales ORDER BY id DESC LIMIT 300')
            elif p.startswith('/api/sales/') and len(self.path_parts())==3:
                sid=int(self.path_parts()[2]);s=one(c,'SELECT * FROM sales WHERE id=?',(sid,));
                if not s:c.close();return self.send_json({'error':'Venta no encontrada'},404)
                out={'sale':s,'items':rows(c,'SELECT * FROM sale_items WHERE sale_id=?',(sid,))}
            elif p=='/api/dashboard':
                td=date.today().isoformat();out={'products':c.execute('SELECT COUNT(*) c FROM products WHERE active=1').fetchone()['c'],'low_stock':c.execute('SELECT COUNT(*) c FROM products WHERE active=1 AND stock<=min_stock').fetchone()['c'],'sales_today':c.execute("SELECT COALESCE(SUM(total),0) t FROM sales WHERE substr(created_at,1,10)=? AND voided=0",(td,)).fetchone()['t'],'tickets_today':c.execute("SELECT COUNT(*) c FROM sales WHERE substr(created_at,1,10)=? AND voided=0",(td,)).fetchone()['c'],'voided_today':c.execute("SELECT COUNT(*) c FROM sales WHERE substr(created_at,1,10)=? AND voided=1",(td,)).fetchone()['c'],'profit_today':c.execute("SELECT COALESCE(SUM((si.unit_price-si.supplier_price)*si.qty),0) t FROM sale_items si JOIN sales s ON s.id=si.sale_id WHERE substr(s.created_at,1,10)=? AND s.voided=0",(td,)).fetchone()['t']}
            elif p=='/api/reports/analytics':
                start=qs.get('start',[date.today().isoformat()])[0];end=qs.get('end',[start])[0]
                daily=rows(c,"""SELECT substr(s.created_at,1,10) day,COALESCE(SUM(si.line_total),0) sales,COALESCE(SUM((si.unit_price-si.supplier_price)*si.qty),0) profit FROM sales s JOIN sale_items si ON si.sale_id=s.id WHERE substr(s.created_at,1,10) BETWEEN ? AND ? AND s.voided=0 GROUP BY substr(s.created_at,1,10) ORDER BY day""",(start,end))
                total_sales=float(c.execute("SELECT COALESCE(SUM(total),0) t FROM sales WHERE substr(created_at,1,10) BETWEEN ? AND ? AND voided=0",(start,end)).fetchone()['t'])
                total_profit=float(c.execute("SELECT COALESCE(SUM((si.unit_price-si.supplier_price)*si.qty),0) t FROM sale_items si JOIN sales s ON s.id=si.sale_id WHERE substr(s.created_at,1,10) BETWEEN ? AND ? AND s.voided=0",(start,end)).fetchone()['t'])
                total_cost=float(c.execute("SELECT COALESCE(SUM(si.supplier_price*si.qty),0) t FROM sale_items si JOIN sales s ON s.id=si.sale_id WHERE substr(s.created_at,1,10) BETWEEN ? AND ? AND s.voided=0",(start,end)).fetchone()['t'])
                tickets=c.execute("SELECT COUNT(*) c FROM sales WHERE substr(created_at,1,10) BETWEEN ? AND ? AND voided=0",(start,end)).fetchone()['c']
                payments=rows(c,"SELECT payment_method name,SUM(total) sales FROM sales WHERE substr(created_at,1,10) BETWEEN ? AND ? AND voided=0 GROUP BY payment_method ORDER BY sales DESC",(start,end))
                providers=rows(c,"""SELECT COALESCE(NULLIF(p.provider,''),'SIN PROVEEDOR') name,SUM(si.line_total) sales FROM sale_items si JOIN sales s ON s.id=si.sale_id LEFT JOIN products p ON p.id=si.product_id WHERE substr(s.created_at,1,10) BETWEEN ? AND ? AND s.voided=0 GROUP BY name ORDER BY sales DESC""",(start,end))
                top=rows(c,"""SELECT si.product_name name,SUM(si.line_total) sales FROM sale_items si JOIN sales s ON s.id=si.sale_id WHERE substr(s.created_at,1,10) BETWEEN ? AND ? AND s.voided=0 GROUP BY si.product_id,si.product_name ORDER BY sales DESC LIMIT 10""",(start,end))
                top_qty=rows(c,"""SELECT si.product_name name,SUM(si.qty) qty,SUM(si.line_total) sales FROM sale_items si JOIN sales s ON s.id=si.sale_id WHERE substr(s.created_at,1,10) BETWEEN ? AND ? AND s.voided=0 GROUP BY si.product_id,si.product_name ORDER BY qty DESC,sales DESC LIMIT 10""",(start,end))
                voided_count=c.execute("SELECT COUNT(*) FROM sales WHERE substr(created_at,1,10) BETWEEN ? AND ? AND voided=1",(start,end)).fetchone()[0]
                out={'start':start,'end':end,'daily':daily,'sales':total_sales,'profit':total_profit,'cost':total_cost,'tickets':tickets,'payments':payments,'providers':providers,'top':top,'top_qty':top_qty,'voided_count':voided_count}
            elif p=='/api/dashboard/owner':
                period=qs.get('period',['today'])[0]
                today=date.today()
                if period=='month': start=today.replace(day=1).isoformat()
                elif period=='week': start=(today-timedelta(days=today.weekday())).isoformat()
                else: start=today.isoformat()
                end=today.isoformat()
                sales_total=c.execute("SELECT COALESCE(SUM(total),0) t FROM sales WHERE substr(created_at,1,10) BETWEEN ? AND ? AND voided=0",(start,end)).fetchone()['t']
                cost_total=c.execute("SELECT COALESCE(SUM(si.supplier_price*si.qty),0) t FROM sale_items si JOIN sales s ON s.id=si.sale_id WHERE substr(s.created_at,1,10) BETWEEN ? AND ? AND s.voided=0",(start,end)).fetchone()['t']
                profit=c.execute("SELECT COALESCE(SUM((si.unit_price-si.supplier_price)*si.qty),0) t FROM sale_items si JOIN sales s ON s.id=si.sale_id WHERE substr(s.created_at,1,10) BETWEEN ? AND ? AND s.voided=0",(start,end)).fetchone()['t']
                tickets=c.execute("SELECT COUNT(*) c FROM sales WHERE substr(created_at,1,10) BETWEEN ? AND ? AND voided=0",(start,end)).fetchone()['c']
                top=rows(c,"""SELECT si.product_name,SUM(si.qty) qty,SUM(si.line_total) sales,SUM((si.unit_price-si.supplier_price)*si.qty) profit FROM sale_items si JOIN sales s ON s.id=si.sale_id WHERE substr(s.created_at,1,10) BETWEEN ? AND ? AND s.voided=0 GROUP BY si.product_id,si.product_name ORDER BY qty DESC,sales DESC LIMIT 10""",(start,end))
                by_user=rows(c,"""SELECT COALESCE(user_name,'SIN USUARIO') user_name,COUNT(*) tickets,COALESCE(SUM(total),0) sales FROM sales WHERE substr(created_at,1,10) BETWEEN ? AND ? AND voided=0 GROUP BY COALESCE(user_name,'SIN USUARIO') ORDER BY sales DESC""",(start,end))
                out={'period':period,'start':start,'end':end,'sales':sales_total,'cost':cost_total,'profit':profit,'margin_percent':(profit/sales_total*100 if sales_total else 0),'tickets':tickets,'top_products':top,'by_user':by_user}
            elif p=='/api/dashboard/weekly':
                today=date.today()
                start=(today-timedelta(days=today.weekday())).isoformat()
                end=today.isoformat()
                sales_total=c.execute("SELECT COALESCE(SUM(total),0) t FROM sales WHERE substr(created_at,1,10) BETWEEN ? AND ? AND voided=0",(start,end)).fetchone()['t']
                cost_total=c.execute("SELECT COALESCE(SUM(si.supplier_price*si.qty),0) t FROM sale_items si JOIN sales s ON s.id=si.sale_id WHERE substr(s.created_at,1,10) BETWEEN ? AND ? AND s.voided=0",(start,end)).fetchone()['t']
                profit=c.execute("SELECT COALESCE(SUM((si.unit_price-si.supplier_price)*si.qty),0) t FROM sale_items si JOIN sales s ON s.id=si.sale_id WHERE substr(s.created_at,1,10) BETWEEN ? AND ? AND s.voided=0",(start,end)).fetchone()['t']
                tickets=c.execute("SELECT COUNT(*) c FROM sales WHERE substr(created_at,1,10) BETWEEN ? AND ? AND voided=0",(start,end)).fetchone()['c']
                top=rows(c,"""SELECT si.product_name, SUM(si.qty) qty, SUM(si.line_total) sales,
                    SUM((si.unit_price-si.supplier_price)*si.qty) profit
                    FROM sale_items si JOIN sales s ON s.id=si.sale_id
                    WHERE substr(s.created_at,1,10) BETWEEN ? AND ? AND s.voided=0
                    GROUP BY si.product_id,si.product_name ORDER BY qty DESC,sales DESC LIMIT 10""",(start,end))
                by_user=rows(c,"""SELECT COALESCE(user_name,'SIN USUARIO') user_name,COUNT(*) tickets,COALESCE(SUM(total),0) sales
                    FROM sales WHERE substr(created_at,1,10) BETWEEN ? AND ? AND voided=0
                    GROUP BY COALESCE(user_name,'SIN USUARIO') ORDER BY sales DESC""",(start,end))
                margin=(profit/sales_total*100) if sales_total else 0
                markup=(profit/cost_total*100) if cost_total else 0
                out={'start':start,'end':end,'sales':sales_total,'cost':cost_total,'profit':profit,'margin_percent':margin,'markup_percent':markup,'tickets':tickets,'top_products':top,'by_user':by_user}
            elif p=='/api/inventory/movements':out=rows(c,'SELECT im.*,p.name product_name FROM inventory_movements im JOIN products p ON p.id=im.product_id ORDER BY im.id DESC LIMIT 300')
            elif p=='/api/inventory/receipt/current':
                usr=qs.get('user',[''])[0];out=one(c,"SELECT * FROM inventory_receipts WHERE user_name=? AND status='OPEN' ORDER BY id DESC LIMIT 1",(usr,)) or {}
            elif p=='/api/inventory/receipt/items':
                rid=int(qs.get('receipt_id',['0'])[0]);out=rows(c,'SELECT * FROM inventory_receipt_items WHERE receipt_id=? ORDER BY id DESC',(rid,))

            elif p=='/api/version':out={'version':app_version()}
            elif p=='/api/connection-info':
                ip=local_ip();out={'ip':ip,'port':5000,'url':f'http://{ip}:5000'}
            elif p=='/api/backups':out={'backups':list_backups(),'external_dir':external_backup_dir(c),'retention':30}

            elif p=='/api/settings':
                out={x['key']:x['value'] for x in rows(c,'SELECT key,value FROM app_settings')}
                if out.get('gmail_app_password'): out['gmail_app_password']='********'
            elif p=='/api/notifications': out=rows(c,'SELECT * FROM notifications ORDER BY id DESC LIMIT 100')
            elif p=='/api/transfers': out=rows(c,'SELECT * FROM transfers ORDER BY id DESC LIMIT 200')
            elif p=='/api/cash/sessions': out=rows(c,'SELECT * FROM cash_sessions ORDER BY id DESC LIMIT 100')
            elif p=='/api/reports/inventory-text': out={'text':inventory_report_text(c,100)}
            elif p=='/api/reports/cut-text':
                sid=int(qs.get('session_id',['0'])[0]);out={'text':cut_report_text(c,sid)}
            else:c.close();return self.send_json({'error':'Ruta no encontrada'},404)
            c.close();return self.send_json(out)
        except Exception as e:return self.send_json({'error':str(e)},500)
    def do_POST(self):
        p=urlparse(self.path).path;d=self.body()
        try:
            c=db();cur=c.cursor()
            if p=='/api/login':
                out=one(c,'SELECT id,name,role FROM users WHERE UPPER(name)=UPPER(?) AND pin_hash=? AND active=1',(str(d.get('name','')).strip(),pin_hash(d.get('pin',''))));c.close();return self.send_json(out if out else {'error':'Usuario o PIN incorrecto'},200 if out else 401)
            if p=='/api/mercadopago/point/create':
                from decimal import Decimal, InvalidOperation
                try: cents=int((Decimal(str(d.get('amount','0')))*100).quantize(Decimal('1')))
                except (InvalidOperation,ValueError):c.close();return self.send_json({'error':'Monto inválido'},400)
                if cents<=0:c.close();return self.send_json({'error':'Monto inválido'},400)
                tok=mp_token(c)
                tid=get_setting(c,'mp_terminal_id','').strip()
                if not tid:c.close();return self.send_json({'error':'Primero selecciona tu Point y activa modo PDV en Configuración'},400)
                r=mp_request(tok,'POST','/v1/orders',{'type':'point','external_reference':'SUPERUNI-'+uuid.uuid4().hex.upper(),'expiration_time':'PT10M','transactions':{'payments':[{'amount':f'{cents/100:.2f}'}]},'config':{'point':{'terminal_id':tid,'print_on_terminal':'no_ticket'}},'description':'Venta SUPER-UNI'},{'X-Idempotency-Key':str(uuid.uuid4())})
                oid=str(r.get('id') or '')
                if not oid:c.close();return self.send_json({'error':'Mercado Pago no devolvió ID de orden'},502)
                cur.execute('INSERT INTO mp_point_orders(order_id,terminal_id,amount_cents,status,created_at) VALUES(?,?,?,?,?)',(oid,tid,cents,r.get('status','created'),now()))
                c.commit();c.close();return self.send_json({'order_id':oid,'status':r.get('status')},201)
            if p=='/api/mercadopago/spei':
                tok=mp_token(c);amount=round(float(d.get('amount',0)),2);email=str(d.get('email','')).strip() or 'cliente.superuni@example.com'
                if amount<=0:c.close();return self.send_json({'error':'Monto inválido'},400)
                ext='SUPERUNI-'+uuid.uuid4().hex[:20].upper()
                payload={'type':'online','external_reference':ext,'processing_mode':'automatic','total_amount':f'{amount:.2f}','expiration_time':'P1D','payer':{'email':email},'transactions':{'payments':[{'amount':f'{amount:.2f}','payment_method':{'id':'clabe','type':'bank_transfer'}}]}}
                r=mp_request(tok,'POST','/v1/orders',payload,{'X-Idempotency-Key':str(uuid.uuid4())})
                pays=((r.get('transactions') or {}).get('payments') or []);pm=(pays[0].get('payment_method') or {}) if pays else {}
                ticket=pm.get('ticket_url','');ref=pm.get('reference','')
                if not r.get('id') or not ticket:c.close();return self.send_json({'error':'Mercado Pago no devolvió instrucciones SPEI','detail':r},400)
                c.close();return self.send_json({'ok':True,'order_id':r.get('id'),'ticket_url':ticket,'reference':ref,'status':r.get('status'),'status_detail':r.get('status_detail')},201)
            if p=='/api/mercadopago/config':
                token=str(d.get('access_token','')).strip() or get_setting(c,'mp_access_token','')
                if not token:c.close();return self.send_json({'error':'Access Token obligatorio'},400)
                me=mp_request(token,'GET','/users/me')
                vals={'mp_access_token':token,'mp_environment':str(d.get('environment','test')),'mp_user_id':str(d.get('user_id','')).strip() or str(me.get('id','')),'mp_store_id':str(d.get('store_id','')).strip(),'mp_pos_id':str(d.get('pos_id','')).strip()}
                for k,v in vals.items():cur.execute("INSERT INTO app_settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",(k,v))
                c.commit();c.close();return self.send_json({'ok':True,'user_id':vals['mp_user_id']})
            if p=='/api/mercadopago/pdv':
                tok=mp_token(c);tid=str(d.get('terminal_id','')).strip()
                if not tid:c.close();return self.send_json({'error':'Selecciona una terminal'},400)
                out=mp_request(tok,'PATCH','/terminals/v1/setup',{'terminals':[{'id':tid,'operating_mode':'PDV'}]})
                for k,v in [('mp_terminal_id',tid),('mp_store_id',str(d.get('store_id',''))),('mp_pos_id',str(d.get('pos_id','')))]:cur.execute("INSERT INTO app_settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",(k,v))
                c.commit();c.close();return self.send_json(out)
            if p=='/api/mercadopago/store-pos':
                tok=mp_token(c);uid=get_setting(c,'mp_user_id','')
                req=['store_name','pos_name','street_name','street_number','city_name','state_name','latitude','longitude']
                if any(not str(d.get(x,'')).strip() for x in req):c.close();return self.send_json({'error':'Completa todos los datos de sucursal, incluida latitud y longitud'},400)
                ext='SUPERUNI'+uuid.uuid4().hex[:10].upper()
                store=mp_request(tok,'POST',f'/users/{uid}/stores',{'name':d['store_name'],'external_id':ext,'location':{'street_number':d['street_number'],'street_name':d['street_name'],'city_name':d['city_name'],'state_name':d['state_name'],'latitude':float(d['latitude']),'longitude':float(d['longitude']),'reference':'SUPER-UNI'}})
                pos=mp_request(tok,'POST','/v2/pos',{'name':d['pos_name'],'store_id':str(store['id']),'external_id':ext+'POS'},{'X-Idempotency-Key':str(uuid.uuid4())})
                for k,v in [('mp_store_id',str(store['id'])),('mp_pos_id',str(pos['id']))]:cur.execute("INSERT INTO app_settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",(k,v))
                c.commit();c.close();return self.send_json({'ok':True,'store_id':str(store['id']),'pos_id':str(pos['id'])})
            if p=='/api/departments':
                name=str(d.get('name','')).strip().upper()
                if not name:c.close();return self.send_json({'error':'Nombre obligatorio'},400)
                try:cur.execute('INSERT INTO departments(name,created_at) VALUES(?,?)',(name,now()));c.commit();c.close();return self.send_json({'ok':True},201)
                except sqlite3.IntegrityError:c.close();return self.send_json({'error':'Ese departamento ya existe'},400)
            if p=='/api/promotions':
                name=str(d.get('name','')).strip();trigger=max(1,int(d.get('trigger_qty',1)));limit=max(1,int(d.get('max_uses',1)));ids=[int(x) for x in d.get('product_ids',[])]
                if not name or not ids:c.close();return self.send_json({'error':'Nombre y productos obligatorios'},400)
                cur.execute('INSERT INTO promotions(name,trigger_qty,max_uses,enabled,created_at) VALUES(?,?,?,?,?)',(name,trigger,limit,1 if d.get('enabled',True) else 0,now()));pid=cur.lastrowid
                cur.executemany('INSERT OR IGNORE INTO promotion_products(promotion_id,product_id) VALUES(?,?)',[(pid,x) for x in ids]);c.commit();c.close();return self.send_json({'ok':True,'id':pid},201)
            if p=='/api/providers':
                name=str(d.get('name','')).strip().upper()
                if not name:c.close();return self.send_json({'error':'Escribe el nombre del proveedor'},400)
                exists=name in PROVIDERS or one(c,'SELECT id FROM custom_providers WHERE UPPER(name)=UPPER(?)',(name,)) or one(c,'SELECT id FROM products WHERE UPPER(provider)=UPPER(?) LIMIT 1',(name,))
                if exists:c.close();return self.send_json({'error':'Ese proveedor ya existe'},400)
                cur.execute('INSERT INTO custom_providers(name,created_at) VALUES(?,?)',(name,now()));c.commit();c.close();return self.send_json({'ok':True,'name':name},201)
            if p=='/api/users/permissions':
                uid=int(d.get('user_id',0));perms=d.get('permissions',{})
                if not one(c,'SELECT id FROM users WHERE id=?',(uid,)):c.close();return self.send_json({'error':'Usuario no encontrado'},404)
                for panel,allowed in perms.items():cur.execute("INSERT INTO user_permissions(user_id,panel,allowed) VALUES(?,?,?) ON CONFLICT(user_id,panel) DO UPDATE SET allowed=excluded.allowed",(uid,str(panel),1 if allowed else 0))
                c.commit();c.close();return self.send_json({'ok':True})
            if p=='/api/users':
                name=d.get('name','').strip().upper();pin=d.get('pin','').strip()
                if not name or not pin:c.close();return self.send_json({'error':'Nombre y PIN son obligatorios'},400)
                try:cur.execute('INSERT INTO users(name,role,pin_hash,created_at) VALUES(?,?,?,?)',(name,d.get('role','CAJERO'),pin_hash(pin),now()));c.commit()
                except sqlite3.IntegrityError:c.close();return self.send_json({'error':'Ese usuario ya existe'},400)
                c.close();return self.send_json({'ok':True},201)
            if p=='/api/tickets/reserve':
                cur.execute('BEGIN IMMEDIATE')
                folio=cur.execute('SELECT MAX(n) FROM (SELECT COALESCE(MAX(id),0) n FROM sales UNION ALL SELECT COALESCE(MAX(folio),0) n FROM ticket_reservations)').fetchone()[0]+1
                cur.execute('INSERT INTO ticket_reservations(folio,created_at) VALUES(?,?)',(folio,now()))
                c.commit();c.close();return self.send_json({'folio':folio})
            if p=='/api/products':
                if not d.get('name','').strip() or not d.get('provider','').strip():c.close();return self.send_json({'error':'Nombre y proveedor son obligatorios'},400)
                t=now()
                barcode=(d.get('barcode') or '').strip() or None
                try:
                    cur.execute('BEGIN IMMEDIATE')
                    existing=one(c,'SELECT id,name,active FROM products WHERE barcode=?',(barcode,)) if barcode else None
                    if existing and not d.get('confirm_replace'):
                        c.rollback();c.close();return self.send_json({'error':'Este código de barras ya existe','code':'BARCODE_EXISTS','existing_name':existing['name']},409)
                    if existing:
                        # Keep the old record for historical sale references; never overwrite sales.
                        cur.execute('UPDATE products SET barcode=NULL,active=0,updated_at=? WHERE id=?',(t,existing['id']))
                    cur.execute('INSERT INTO products(barcode,name,provider,presentation,category,supplier_price,sale_price,stock,min_stock,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?)',(barcode,d['name'].strip(),d['provider'].strip(),d.get('presentation',''),d.get('category',''),float(d.get('supplier_price',0) or 0),float(d.get('sale_price',0) or 0),int(d.get('stock',0) or 0),int(d.get('min_stock',0) or 0),t,t))
                    pid=cur.lastrowid;c.commit()
                except sqlite3.IntegrityError:
                    c.rollback();c.close();return self.send_json({'error':'Ese código de barras ya existe; vuelve a intentar'},409)
                except Exception:
                    c.rollback();c.close();raise
                out=one(c,'SELECT * FROM products WHERE id=?',(pid,));c.close();return self.send_json(out,201)
            if p=='/api/inventory/receipt/start':
                provider=d.get('provider','').strip();usr=d.get('user_name','').strip()
                if not provider or not usr:c.close();return self.send_json({'error':'Proveedor y usuario son obligatorios'},400)
                ex=one(c,"SELECT * FROM inventory_receipts WHERE user_name=? AND status='OPEN' ORDER BY id DESC LIMIT 1",(usr,))
                if ex:c.close();return self.send_json(ex,200)
                cur.execute("INSERT INTO inventory_receipts(provider,user_name,status,started_at) VALUES(?,?,'OPEN',?)",(provider,usr,now()))
                rid=cur.lastrowid;c.commit();out=one(c,'SELECT * FROM inventory_receipts WHERE id=?',(rid,));c.close();return self.send_json(out,201)
            if p=='/api/inventory/receipt/finish':
                rid=int(d.get('receipt_id',0));rec=one(c,"SELECT * FROM inventory_receipts WHERE id=? AND status='OPEN'",(rid,))
                if not rec:c.close();return self.send_json({'error':'Registro de inventario no encontrado o ya finalizado'},404)
                ended=now();cur.execute("UPDATE inventory_receipts SET status='CLOSED',ended_at=? WHERE id=?",(ended,rid));c.commit()
                report=inventory_receipt_report_text(c,rid)
                ok,msg=send_gmail(c,f"SUPER-UNI · Inventariado {rec['provider']} · {rec['user_name']}",report)
                cur.execute("UPDATE inventory_receipts SET email_sent=?,email_message=? WHERE id=?",(1 if ok else 0,msg,rid))
                add_notification(c,'Inventariado finalizado',f"{rec['user_name']} finalizó {rec['provider']}. Email: {'enviado' if ok else 'no enviado'}",'OK' if ok else 'WARN')
                c.commit();c.close();return self.send_json({'ok':True,'email_sent':ok,'email_message':msg,'report':report})
            if p=='/api/inventory/reset':
                kind=str(d.get('type',''));target=str(d.get('target','')).strip();usr=str(d.get('user_name','ADMIN')).strip()
                if kind not in ('barcode','provider') or not target:c.close();return self.send_json({'error':'Indica código o proveedor'},400)
                try:
                    cur.execute('BEGIN IMMEDIATE')
                    if kind=='barcode':selected=rows(c,'SELECT * FROM products WHERE barcode=? AND active=1',(target,))
                    else:selected=rows(c,'SELECT * FROM products WHERE UPPER(provider)=UPPER(?) AND active=1',(target,))
                    if not selected:c.rollback();c.close();return self.send_json({'error':'No se encontraron productos activos'},404)
                    stamp=now()
                    for pr in selected:
                        before=int(pr['stock']);cur.execute('UPDATE products SET stock=0,updated_at=? WHERE id=?',(stamp,pr['id']))
                        cur.execute('INSERT INTO inventory_movements(product_id,movement_type,qty,stock_before,stock_after,note,user_name,created_at) VALUES(?,?,?,?,?,?,?,?)',(pr['id'],'reset',abs(before),before,0,'RESET A CERO · '+kind+' · '+target,usr,stamp))
                    c.commit();c.close();return self.send_json({'ok':True,'updated':len(selected)})
                except Exception:
                    c.rollback();c.close();raise
            if p=='/api/inventory/adjust':
                pid=int(d.get('product_id',0));mode=d.get('mode','add');qty=int(d.get('qty',0));pr=one(c,'SELECT * FROM products WHERE id=?',(pid,))
                if not pr:c.close();return self.send_json({'error':'Producto no encontrado'},404)
                before=int(pr['stock']);after=qty if mode=='set' else before-qty if mode=='remove' else before+qty
                cur.execute('UPDATE products SET stock=?,updated_at=? WHERE id=?',(after,now(),pid))
                stamp=now()
                cur.execute('INSERT INTO inventory_movements(product_id,movement_type,qty,stock_before,stock_after,note,user_name,created_at) VALUES(?,?,?,?,?,?,?,?)',(pid,mode,qty,before,after,d.get('note',''),d.get('user_name','ADMIN'),stamp))
                rid=int(d.get('receipt_id',0) or 0)
                if rid:
                    rec=one(c,"SELECT * FROM inventory_receipts WHERE id=? AND status='OPEN'",(rid,))
                    if rec:
                        cur.execute('INSERT INTO inventory_receipt_items(receipt_id,product_id,product_name,movement_type,qty,stock_before,stock_after,note,created_at) VALUES(?,?,?,?,?,?,?,?,?)',(rid,pid,pr['name'],mode,qty,before,after,d.get('note',''),stamp))
                c.commit();c.close();return self.send_json({'stock_before':before,'stock_after':after})
            if p=='/api/cash/service-withdrawal':
                from decimal import Decimal, InvalidOperation, ROUND_HALF_UP
                try:
                    amount_cents=int((Decimal(str(d.get('amount','0')))*100).quantize(Decimal('1'),rounding=ROUND_HALF_UP))
                except (InvalidOperation,ValueError):
                    c.close();return self.send_json({'error':'Monto inválido'},400)
                ref=str(d.get('payment_reference','')).strip()
                if amount_cents<=0 or amount_cents>100000000:
                    c.close();return self.send_json({'error':'Monto fuera de rango'},400)
                if len(ref)<6 or len(ref)>120:
                    c.close();return self.send_json({'error':'Ingresa una referencia verificable del pago ya acreditado (mínimo 6 caracteres)'},400)
                if d.get('payment_confirmed') is not True:
                    c.close();return self.send_json({'error':'Confirma que el pago ya está acreditado antes de registrar la salida'},400)
                sid=int(d.get('session_id') or 0)
                fee_cents=(amount_cents*10+50)//100
                try:
                    cur.execute('BEGIN IMMEDIATE')
                    sess=one(c,"SELECT * FROM cash_sessions WHERE id=? AND status='OPEN'",(sid,))
                    if not sess:raise ValueError('El turno ya no está abierto')
                    if one(c,'SELECT id FROM service_withdrawals WHERE payment_reference=?',(ref,)):
                        raise ValueError('Esta referencia ya fue registrada; no se puede duplicar la salida')
                    cur.execute('INSERT INTO service_withdrawals(session_id,cashbox,user_name,amount_cents,fee_cents,charged_cents,payment_reference,created_at) VALUES(?,?,?,?,?,?,?,?)',(sid,sess['cashbox'],d.get('user_name') or sess['user_name'],amount_cents,fee_cents,amount_cents+fee_cents,ref,now()))
                    wid=cur.lastrowid
                    c.commit();c.close();return self.send_json({'ok':True,'withdrawal_id':wid,'cash_out':amount_cents/100,'fee':fee_cents/100,'charged':(amount_cents+fee_cents)/100},201)
                except (ValueError,sqlite3.IntegrityError) as e:
                    c.rollback();c.close();return self.send_json({'error':str(e)},409)
            if p=='/api/cash/open':
                box=d.get('cashbox','CAJA 1');ex=one(c,"SELECT * FROM cash_sessions WHERE cashbox=? AND status='OPEN'",(box,))
                if ex:c.close();return self.send_json({'error':'Esa caja ya tiene un turno abierto','session':ex},400)
                cur.execute("INSERT INTO cash_sessions(cashbox,user_name,opening_amount,opened_at,status) VALUES(?,?,?,?, 'OPEN')",(box,d.get('user_name','CAJERO'),float(d.get('opening_amount',0) or 0),now()));c.commit();sid=cur.lastrowid;c.close();return self.send_json({'session_id':sid})
            if p=='/api/cash/movement':
                sid=int(d.get('session_id',0));amount=float(d.get('amount',0) or 0);s=one(c,"SELECT * FROM cash_sessions WHERE id=? AND status='OPEN'",(sid,))
                if not s or amount<=0:c.close();return self.send_json({'error':'Turno o monto inválido'},400)
                cur.execute('INSERT INTO cash_movements(session_id,movement_type,amount,note,user_name,created_at) VALUES(?,?,?,?,?,?)',(sid,d.get('movement_type','WITHDRAWAL'),amount,d.get('note',''),d.get('user_name',''),now()));c.commit();c.close();return self.send_json({'ok':True})
            if p=='/api/cash/close':
                sid=int(d.get('session_id',0));sess=one(c,"SELECT * FROM cash_sessions WHERE id=? AND status='OPEN'",(sid,))
                if not sess:c.close();return self.send_json({'error':'Turno no encontrado'},404)
                vals=session_totals(c,sess)
                counted=float(d.get('closing_counted',0) or 0)
                declared_card=float(d.get('declared_card',0) or 0)
                declared_transfers=float(d.get('declared_transfers',0) or 0)
                declared_withdrawals=float(d.get('declared_withdrawals',0) or 0)
                cash_diff=counted-vals['expected_cash']
                card_diff=declared_card-vals['card_sales']
                transfer_diff=declared_transfers-vals['transfer_sales']
                withdrawal_diff=declared_withdrawals-vals['withdrawals']
                closed=now()
                cur.execute("""UPDATE cash_sessions SET closing_counted=?,expected_cash=?,difference=?,
                    declared_card=?,expected_card=?,card_difference=?,
                    declared_transfers=?,expected_transfers=?,transfer_difference=?,
                    declared_withdrawals=?,expected_withdrawals=?,withdrawal_difference=?,
                    cut_note=?,closed_at=?,status='CLOSED' WHERE id=?""",
                    (counted,vals['expected_cash'],cash_diff,
                     declared_card,vals['card_sales'],card_diff,
                     declared_transfers,vals['transfer_sales'],transfer_diff,
                     declared_withdrawals,vals['withdrawals'],withdrawal_diff,
                     d.get('cut_note',''),closed,sid))
                c.commit()
                report=cut_report_text(c,sid)
                ok,msg=send_gmail(c,f"SUPER-UNI · Corte {sess['cashbox']} · {sess['user_name']}",report)
                any_diff=any(abs(x)>=0.01 for x in (cash_diff,card_diff,transfer_diff,withdrawal_diff))
                add_notification(c,f"Corte {sess['cashbox']} realizado",f"{sess['user_name']} cerró turno. {'Hay diferencias por revisar.' if any_diff else 'Corte cuadrado.'} Email: {'enviado' if ok else 'no enviado'}",'WARN' if any_diff else 'OK')
                c.commit();c.close()
                try: backup_database('daily')
                except Exception as e: print('[SUPER-UNI] Respaldo al corte:',e)
                return self.send_json({
                    'ok':True,'expected_cash':vals['expected_cash'],'closing_counted':counted,'difference':cash_diff,
                    'expected_card':vals['card_sales'],'declared_card':declared_card,'card_difference':card_diff,
                    'expected_transfers':vals['transfer_sales'],'declared_transfers':declared_transfers,'transfer_difference':transfer_diff,
                    'expected_withdrawals':vals['withdrawals'],'declared_withdrawals':declared_withdrawals,'withdrawal_difference':withdrawal_diff,
                    'report':report,'email_sent':ok,'email_message':msg
                })
            if p=='/api/sales':
                items=d.get('items') or []
                if not items:c.close();return self.send_json({'error':'Venta vacía'},400)
                total=0;resolved=[];manual_sale=bool(d.get('manual_sale'))
                if manual_sale:
                    if len(items)!=1 or int(items[0].get('product_id',-1))!=0 or int(items[0].get('qty',0))!=1:
                        raise ValueError('Cobro manual inválido')
                    total=round(float(items[0].get('unit_price',0)),2)
                    if total<5 or total>1000000 or abs(total-float(items[0].get('unit_price',0)))>0.00001:
                        raise ValueError('Monto manual inválido')
                    if d.get('payment_method')!='TARJETA':raise ValueError('El cobro manual requiere Point')
                else:
                    for it in items:
                        pr=one(c,'SELECT * FROM products WHERE id=? AND active=1',(int(it['product_id']),));qty=int(it['qty'])
                        if not pr or qty<=0:raise ValueError('Producto o cantidad inválida')
                        price=float(it.get('unit_price',pr['sale_price']));total+=price*qty;resolved.append((pr,qty,price))
                pay=d.get('payment_method','EFECTIVO');received=float(d.get('received',0) or 0)
                point_order=None
                if pay=='TARJETA':
                    oid=str(d.get('point_order_id') or '').strip()
                    point_order=one(c,'SELECT * FROM mp_point_orders WHERE order_id=?',(oid,))
                    if not point_order:c.close();return self.send_json({'error':'No hay pago Point asociado. Cobra desde F12 → Tarjeta → F2'},409)
                    if point_order['sale_id']:
                        c.close();return self.send_json({'sale_id':point_order['sale_id'],'already_registered':True})
                    if round(total*100)!=point_order['amount_cents']:
                        c.close();return self.send_json({'error':'El total del ticket cambió respecto al importe enviado a Point'},409)
                    r=mp_request(mp_token(c),'GET','/v1/orders/'+urllib.parse.quote(oid))
                    payments=((r.get('transactions') or {}).get('payments') or [])
                    if not (r.get('status')=='processed' and any(x.get('status')=='processed' and x.get('status_detail')=='accredited' for x in payments)):
                        c.close();return self.send_json({'error':'Mercado Pago todavía no confirma el pago acreditado'},409)
                    if str((r.get('config') or {}).get('point',{}).get('terminal_id',''))!=point_order['terminal_id']:
                        c.close();return self.send_json({'error':'La orden no corresponde a la terminal seleccionada'},409)

                if pay=='EFECTIVO' and received<total:raise ValueError('Efectivo recibido insuficiente')
                change=received-total if pay=='EFECTIVO' else 0;t=now();box=d.get('cashbox','CAJA 1');usr=d.get('user_name','CAJERO');cur.execute('BEGIN IMMEDIATE')
                active=one(c,"SELECT * FROM cash_sessions WHERE cashbox=? AND status='OPEN' ORDER BY id DESC LIMIT 1",(box,))
                if not active or active['user_name']!=usr:
                    c.rollback();c.close();return self.send_json({'error':'Abre tu propio turno en esta caja antes de registrar ventas'},409)
                reserved=int(d.get('ticket_folio') or 0)
                if reserved and not one(c,'SELECT folio FROM ticket_reservations WHERE folio=?',(reserved,)):
                    c.rollback();c.close();return self.send_json({'error':'El folio reservado ya no está disponible'},409)
                sid=reserved or (cur.execute('SELECT MAX(n) FROM (SELECT COALESCE(MAX(id),0) n FROM sales UNION ALL SELECT COALESCE(MAX(folio),0) n FROM ticket_reservations)').fetchone()[0]+1)
                cur.execute('INSERT INTO sales(id,total,payment_method,received,change_due,cashbox,user_name,created_at,session_id) VALUES(?,?,?,?,?,?,?,?,?)',(sid,total,pay,received,change,box,usr,t,active['id']))
                if point_order:cur.execute('UPDATE mp_point_orders SET sale_id=?,status=? WHERE order_id=? AND sale_id IS NULL',(sid,'processed',point_order['order_id']))
                if reserved:cur.execute('DELETE FROM ticket_reservations WHERE folio=?',(reserved,))
                if manual_sale:
                    manual_pr=one(c,"SELECT * FROM products WHERE barcode='SUPERUNI-COBRO-MANUAL'")
                    if not manual_pr:
                        cur.execute('INSERT INTO products(barcode,name,provider,presentation,category,supplier_price,sale_price,stock,min_stock,active,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)',('SUPERUNI-COBRO-MANUAL','VENTA MANUAL SIN CÓDIGO','VENTA MANUAL','','VENTA MANUAL',0,0,0,0,1,t,t))
                        manual_pr=one(c,"SELECT * FROM products WHERE barcode='SUPERUNI-COBRO-MANUAL'")
                    cur.execute('INSERT INTO sale_items(sale_id,product_id,product_name,qty,unit_price,supplier_price,line_total) VALUES(?,?,?,?,?,?,?)',(sid,manual_pr['id'],'VENTA MANUAL SIN CÓDIGO',1,total,0,total))
                for pr,qty,price in resolved:
                    cur.execute('INSERT INTO sale_items(sale_id,product_id,product_name,qty,unit_price,supplier_price,line_total) VALUES(?,?,?,?,?,?,?)',(sid,pr['id'],pr['name'],qty,price,pr['supplier_price'],price*qty));before=int(pr['stock']);after=before-qty;cur.execute('UPDATE products SET stock=?,updated_at=? WHERE id=?',(after,t,pr['id']));cur.execute('INSERT INTO inventory_movements(product_id,movement_type,qty,stock_before,stock_after,note,user_name,created_at) VALUES(?,?,?,?,?,?,?,?)',(pr['id'],'sale',qty,before,after,f'Venta #{sid}',usr,t))
                c.commit();c.close();return self.send_json({'sale_id':sid,'total':total,'change':change})
            if p.endswith('/void') and p.startswith('/api/sales/'):
                sid=int(self.path_parts()[2]);s=one(c,'SELECT * FROM sales WHERE id=?',(sid,))
                if not s or s['voided']:c.close();return self.send_json({'error':'Venta no encontrada o ya cancelada'},400)
                cur.execute('BEGIN IMMEDIATE')
                if one(c,'SELECT voided FROM sales WHERE id=?',(sid,))['voided']:
                    c.rollback();c.close();return self.send_json({'error':'Ticket ya cancelado'},409)
                for it in rows(c,'SELECT * FROM sale_items WHERE sale_id=?',(sid,)):
                    pr=one(c,'SELECT * FROM products WHERE id=?',(it['product_id'],));
                    if pr['barcode']=='SUPERUNI-COBRO-MANUAL':continue
                    before=int(pr['stock']);after=before+int(it['qty']);cur.execute('UPDATE products SET stock=?,updated_at=? WHERE id=?',(after,now(),pr['id']));cur.execute('INSERT INTO inventory_movements(product_id,movement_type,qty,stock_before,stock_after,note,user_name,created_at) VALUES(?,?,?,?,?,?,?,?)',(pr['id'],'void',it['qty'],before,after,f'Cancelación venta #{sid}',d.get('user_name','ADMIN'),now()))
                cur.execute('UPDATE sales SET voided=1,void_reason=? WHERE id=?',(d.get('reason','Cancelación'),sid));c.commit();c.close();return self.send_json({'ok':True})
            if p=='/api/purchase-comparison':
                pid=int(d.get('product_id',0));qty=int(d.get('qty',0));wh=float(d.get('wholesale_price',0) or 0);pr=one(c,'SELECT * FROM products WHERE id=?',(pid,))
                if not pr or qty<=0:c.close();return self.send_json({'error':'Producto o cantidad inválida'},400)
                st=float(pr['supplier_price'])*qty;wt=wh*qty if wh>0 else 0;sav=max(0,st-wt) if wh>0 else 0;add=1 if d.get('add_to_stock') else 0;cur.execute('INSERT INTO purchase_comparisons(product_id,qty,supplier_price,wholesale_price,supplier_total,wholesale_total,savings,add_to_stock,created_at) VALUES(?,?,?,?,?,?,?,?,?)',(pid,qty,pr['supplier_price'],wh,st,wt,sav,add,now()))
                if add:
                    before=int(pr['stock']);after=before+qty;cur.execute('UPDATE products SET stock=?,updated_at=? WHERE id=?',(after,now(),pid));cur.execute('INSERT INTO inventory_movements(product_id,movement_type,qty,stock_before,stock_after,note,user_name,created_at) VALUES(?,?,?,?,?,?,?,?)',(pid,'purchase',qty,before,after,'Compra mayorista',d.get('user_name','ADMIN'),now()))
                c.commit();c.close();return self.send_json({'supplier_total':st,'wholesale_total':wt,'savings':sav})

            if p=='/api/backups/create':
                if d.get('user_role')!='ADMIN':c.close();return self.send_json({'error':'Solo administrador'},403)
                c.close()
                try:return self.send_json(backup_database('manual'),201)
                except Exception as e:return self.send_json({'error':str(e)},500)
            if p=='/api/backups/restore':
                admin_pin=str(d.get('admin_pin',''))
                ok=one(c,"SELECT id FROM users WHERE role='ADMIN' AND active=1 AND pin_hash=?",(pin_hash(admin_pin),))
                c.close()
                if not ok:return self.send_json({'error':'PIN de administrador incorrecto'},403)
                try:
                    restore_backup(d.get('file',''))
                    return self.send_json({'ok':True,'message':'Respaldo restaurado. Reinicia SUPER-UNI para asegurar que todos los equipos recarguen la información.'})
                except Exception as e:return self.send_json({'error':str(e)},500)
            if p=='/api/branding':
                old_name=get_setting(c,'app_name') or 'SUPER-UNI POS'
                name=str(d.get('app_name','')).strip() or 'SUPER-UNI POS'
                icon=str(d.get('icon_data','') or '');raw=None
                if icon:
                    try:
                        raw=base64.b64decode(icon.split(',',1)[1])
                        if len(raw)>2097152:raise ValueError('Imagen demasiado grande')
                        if not raw.startswith(b'\x89PNG\r\n\x1a\n'):raise ValueError('Para el icono del Escritorio usa una imagen PNG')
                        open(os.path.join(STATIC_DIR,'custom_app_icon.png'),'wb').write(raw)
                    except Exception as e:c.close();return self.send_json({'error':'No se pudo guardar el icono: '+str(e)},400)
                set_setting(c,'app_name',name)
                desktop=apply_windows_branding(c,name,raw)
                c.commit();c.close();return self.send_json({'ok':True,'desktop_shortcut':desktop})
            if p=='/api/settings':
                allowed=['gmail_user','gmail_app_password','report_email','whatsapp_phone','backup_external_dir']
                for k in allowed:
                    if k in d and not (k=='gmail_app_password' and d[k]=='********'):
                        set_setting(c,k,d[k])
                c.commit();c.close();return self.send_json({'ok':True})
            if p=='/api/reports/send-inventory':
                text=inventory_report_text(c,100);ok,msg=send_gmail(c,'SUPER-UNI · Movimientos de inventario',text)
                add_notification(c,'Reporte de inventario',f"Intento de envío por Gmail: {'enviado' if ok else 'no enviado'}",'OK' if ok else 'WARN')
                c.commit();c.close();return self.send_json({'ok':ok,'message':msg,'text':text})
            if p=='/api/reports/send-cut':
                sid=int(d.get('session_id',0));text=cut_report_text(c,sid)
                if not text:c.close();return self.send_json({'error':'Corte no encontrado'},404)
                s=one(c,'SELECT * FROM cash_sessions WHERE id=?',(sid,));ok,msg=send_gmail(c,f"SUPER-UNI · Corte {s['cashbox']} · {s['user_name']}",text)
                c.close();return self.send_json({'ok':ok,'message':msg,'text':text})
            if p=='/api/transfers':
                amount=float(d.get('amount',0) or 0)
                if amount<=0:c.close();return self.send_json({'error':'Monto inválido'},400)
                cur.execute("INSERT INTO transfers(amount,reference,note,status,created_by,created_at) VALUES(?,?,?,?,?,?)",(amount,d.get('reference','').strip(),d.get('note','').strip(),'PENDING',d.get('user_name',''),now()))
                tid=cur.lastrowid;add_notification(c,'Transferencia pendiente',f"Se registró una transferencia por ${amount:,.2f} pendiente de confirmación.",'INFO');c.commit();c.close();return self.send_json({'id':tid},201)
            if p.startswith('/api/transfers/') and p.endswith('/confirm'):
                tid=int(self.path_parts()[2]);tr=one(c,'SELECT * FROM transfers WHERE id=?',(tid,))
                if not tr:c.close();return self.send_json({'error':'Transferencia no encontrada'},404)
                cur.execute("UPDATE transfers SET status='RECEIVED',confirmed_at=?,confirmed_by=? WHERE id=?",(now(),d.get('user_name','ADMIN'),tid))
                add_notification(c,'TRANSFERENCIA RECIBIDA',f"${float(tr['amount']):,.2f} · Ref. {tr['reference'] or 'sin referencia'}",'OK');c.commit();c.close();return self.send_json({'ok':True})
            if p=='/api/transfers/webhook':
                token=self.headers.get('X-SUPERUNI-TOKEN','') or d.get('token','')
                if token!=get_setting(c,'transfer_webhook_token'):c.close();return self.send_json({'error':'Token inválido'},403)
                ref=d.get('reference','').strip();amount=float(d.get('amount',0) or 0)
                tr=one(c,"SELECT * FROM transfers WHERE status='PENDING' AND (?='' OR reference=?) AND (?<=0 OR ABS(amount-?)<0.01) ORDER BY id DESC LIMIT 1",(ref,ref,amount,amount))
                if not tr:c.close();return self.send_json({'error':'No hay transferencia pendiente coincidente'},404)
                cur.execute("UPDATE transfers SET status='RECEIVED',confirmed_at=?,confirmed_by='INTEGRACION' WHERE id=?",(now(),tr['id']))
                add_notification(c,'TRANSFERENCIA RECIBIDA',f"${float(tr['amount']):,.2f} · Ref. {tr['reference'] or 'sin referencia'} · Confirmación automática",'OK');c.commit();c.close();return self.send_json({'ok':True,'transfer_id':tr['id']})
            if p=='/api/notifications/read-all':
                cur.execute('UPDATE notifications SET read_flag=1');c.commit();c.close();return self.send_json({'ok':True})
            c.close();return self.send_json({'error':'Ruta no encontrada'},404)
        except ValueError as e:
            try:c.rollback();c.close()
            except:pass
            return self.send_json({'error':str(e)},400)
        except Exception as e:
            try:c.rollback();c.close()
            except:pass
            return self.send_json({'error':str(e)},500)
    def do_DELETE(self):
        p=urlparse(self.path).path;parts=self.path_parts()
        if len(parts)==3 and parts[:2]==['api','departments']:
            c=db();c.execute('DELETE FROM departments WHERE id=?',(int(parts[2]),));c.commit();c.close();return self.send_json({'ok':True})
        if len(parts)==3 and parts[:2]==['api','promotions']:
            c=db();pid=int(parts[2]);c.execute('DELETE FROM promotion_products WHERE promotion_id=?',(pid,));c.execute('DELETE FROM promotions WHERE id=?',(pid,));c.commit();c.close();return self.send_json({'ok':True})
        if len(parts)==3 and parts[:2]==['api','providers']:
            name=urllib.parse.unquote(parts[2]).strip();c=db()
            n=c.execute("SELECT COUNT(*) FROM products WHERE active=1 AND UPPER(TRIM(provider))=UPPER(TRIM(?))",(name,)).fetchone()[0]
            if n:c.close();return self.send_json({'error':f'No se puede eliminar: {n} producto(s) todavía usan este proveedor'},409)
            c.execute("DELETE FROM custom_providers WHERE UPPER(TRIM(name))=UPPER(TRIM(?))",(name,));c.commit();c.close();return self.send_json({'ok':True})
        if len(parts)==3 and parts[:2]==['api','users']:
            c=db();uid=int(parts[2]);u=one(c,'SELECT * FROM users WHERE id=?',(uid,))
            if not u:c.close();return self.send_json({'error':'Usuario no encontrado'},404)
            admins=one(c,"SELECT COUNT(*) c FROM users WHERE role='ADMIN' AND active=1")['c']
            if u['role']=='ADMIN' and admins<=1:c.close();return self.send_json({'error':'No puedes borrar al único administrador'},400)
            c.execute('UPDATE users SET active=0 WHERE id=?',(uid,));c.commit();c.close();return self.send_json({'ok':True})
        if len(parts)!=3 or parts[:2]!=['api','products']:return self.send_json({'error':'Ruta no encontrada'},404)
        c=db();pid=int(parts[2]);pr=one(c,'SELECT id FROM products WHERE id=? AND active=1',(pid,))
        if not pr:c.close();return self.send_json({'error':'Producto no encontrado'},404)
        c.execute('UPDATE products SET active=0,barcode=NULL,updated_at=? WHERE id=?',(now(),pid));c.commit();c.close();return self.send_json({'ok':True})
    def do_PUT(self):
        p=urlparse(self.path).path;parts=self.path_parts();d=self.body()
        if len(parts)==3 and parts[:2]==['api','users']:
            c=db();d=self.body();uid=int(parts[2]);u=one(c,'SELECT * FROM users WHERE id=?',(uid,))
            if not u:c.close();return self.send_json({'error':'Usuario no encontrado'},404)
            name=str(d.get('name',u['name'])).strip().upper();role=str(d.get('role',u['role'])).strip().upper();pin=str(d.get('pin','')).strip()
            if not name:c.close();return self.send_json({'error':'Nombre obligatorio'},400)
            admins=one(c,"SELECT COUNT(*) c FROM users WHERE role='ADMIN' AND active=1")['c']
            if u['role']=='ADMIN' and role!='ADMIN' and admins<=1:c.close();return self.send_json({'error':'Debe quedar al menos un administrador'},400)
            try:
                if pin:c.execute('UPDATE users SET name=?,role=?,pin_hash=? WHERE id=?',(name,role,pin_hash(pin),uid))
                else:c.execute('UPDATE users SET name=?,role=? WHERE id=?',(name,role,uid))
                c.commit();c.close();return self.send_json({'ok':True})
            except sqlite3.IntegrityError:c.close();return self.send_json({'error':'Ese nombre ya existe'},400)
        if len(parts)!=3 or parts[:2]!=['api','products']:return self.send_json({'error':'Ruta no encontrada'},404)
        pid=int(parts[2]);c=db();old=one(c,'SELECT * FROM products WHERE id=?',(pid,))
        if not old:c.close();return self.send_json({'error':'Producto no encontrado'},404)
        v={k:d.get(k,old[k]) for k in ['barcode','name','provider','presentation','category','supplier_price','sale_price','stock','min_stock']}
        try:c.execute('UPDATE products SET barcode=?,name=?,provider=?,presentation=?,category=?,supplier_price=?,sale_price=?,stock=?,min_stock=?,updated_at=? WHERE id=?',(v['barcode'] or None,v['name'],v['provider'],v['presentation'],v['category'],float(v['supplier_price']),float(v['sale_price']),int(v['stock']),int(v['min_stock']),now(),pid));c.commit()
        except sqlite3.IntegrityError:c.close();return self.send_json({'error':'Ese código de barras ya existe'},400)
        out=one(c,'SELECT * FROM products WHERE id=?',(pid,));c.close();return self.send_json(out)

if __name__=='__main__':
    init_db();
    try: open(PID_PATH,'w',encoding='utf-8').write(str(os.getpid()))
    except: pass
    install_launcher_update();threading.Thread(target=backup_scheduler,daemon=True).start();print('\nSUPER-UNI POS iniciado.\nEn esta PC: http://127.0.0.1:5000\nEn otras PCs/teléfono: http://IP-DE-ESTA-PC:5000\n');ThreadingHTTPServer(('0.0.0.0',5000),Handler).serve_forever()
