@echo off
echo SUPER-UNI POS no requiere instalar paquetes externos.
echo Solo necesitas Python 3 instalado en Windows.
pause
