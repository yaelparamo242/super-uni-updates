@echo off
cd /d %~dp0
python super_uni_pos.py
pause
