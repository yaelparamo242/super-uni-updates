import os, sys, json, time, shutil, zipfile, tempfile, subprocess, urllib.request, urllib.parse, webbrowser, socket, sqlite3, signal
from pathlib import Path
import tkinter as tk
from tkinter import messagebox

ROOT=Path(__file__).resolve().parent
APP=ROOT/"APP"; DATA=ROOT/"DATOS"; CFG=ROOT/"update_config.json"; LOCAL=ROOT/"ACTUALIZACIONES"/"manifest.json"
BACKUPS=DATA/"RESPALDOS"; PIDFILE=DATA/"super_uni_server.pid"

def jload(p,d=None):
    try:return json.loads(Path(p).read_text(encoding="utf-8"))
    except:return d or {}
def ver(): return jload(APP/"version.json",{}).get("version","0.0.0")
def vt(v):
    try:return tuple(int(x) for x in str(v).split("."))
    except:return (0,)
def fetch(url):
    with urllib.request.urlopen(url,timeout=5) as r:return json.loads(r.read().decode())
def manifest():
    c=jload(CFG,{})
    u=(c.get("manifest_url") or "").strip()
    if u:
        try:return fetch(u),u
        except:pass
    if LOCAL.exists():return jload(LOCAL,{}),LOCAL.as_uri()
    return None,None
def dl(url,dest):
    if url.startswith("file:"):
        src=Path(urllib.request.url2pathname(urllib.parse.urlparse(url).path));shutil.copy2(src,dest)
    else:urllib.request.urlretrieve(url,dest)
def external_dir():
    dbp=DATA/"super_uni_pos.db"
    try:
        c=sqlite3.connect(dbp);r=c.execute("SELECT value FROM app_settings WHERE key='backup_external_dir'").fetchone();c.close()
        if r and r[0]:return Path(os.path.expandvars(os.path.expanduser(r[0])))
    except:pass
    od=os.environ.get("OneDrive") or os.environ.get("ONEDRIVE")
    return Path(od)/"SUPER-UNI Respaldos" if od else None
def prune(folder,keep=30):
    try:
        fs=sorted([p for p in Path(folder).glob("*.db")],key=lambda p:p.stat().st_mtime,reverse=True)
        for p in fs[keep:]:
            try:p.unlink()
            except:pass
    except:pass
def preupdate_backup():
    dbp=DATA/"super_uni_pos.db"
    if not dbp.exists():return
    BACKUPS.mkdir(parents=True,exist_ok=True)
    name="SUPER_UNI_pre_update_"+time.strftime("%Y-%m-%d_%H-%M-%S")+".db"
    dest=BACKUPS/name
    src=sqlite3.connect(dbp);dst=sqlite3.connect(dest)
    try:src.backup(dst)
    finally:dst.close();src.close()
    prune(BACKUPS,30)
    ext=external_dir()
    if ext:
        try:
            ext.mkdir(parents=True,exist_ok=True);shutil.copy2(dest,ext/name);prune(ext,30)
        except:pass
def stop_server():
    try:
        pid=int(PIDFILE.read_text(encoding="utf-8").strip())
        os.kill(pid, signal.SIGTERM)
        for _ in range(30):
            if not running(5000): break
            time.sleep(.1)
    except: pass
    try: PIDFILE.unlink(missing_ok=True)
    except: pass
def apply(m,src):
    preupdate_backup()
    u=(m.get("package_url") or "").strip()
    if not u:raise RuntimeError("Falta package_url")
    if src and src.startswith("file:") and not urllib.parse.urlparse(u).scheme:
        base=Path(urllib.request.url2pathname(urllib.parse.urlparse(src).path)).parent;u=(base/u).resolve().as_uri()
    tmp=Path(tempfile.mkdtemp());z=tmp/"u.zip";dl(u,z)
    ex=tmp/"x";ex.mkdir()
    with zipfile.ZipFile(z) as f:f.extractall(ex)
    na=ex/"APP"
    if not na.exists():
        cand=[p for p in ex.rglob("APP") if p.is_dir()]
        if cand:na=cand[0]
    if not na.exists():raise RuntimeError("Actualización inválida")
    bak=ROOT/"APP_BACKUP"
    if bak.exists():shutil.rmtree(bak)
    APP.rename(bak)
    try:
        shutil.copytree(na,APP);shutil.rmtree(bak,ignore_errors=True)
        stop_server()
    except:
        if APP.exists():shutil.rmtree(APP)
        bak.rename(APP);raise
def check():
    m,src=manifest()
    if not m or vt(m.get("version","0"))<=vt(ver()):return
    r=tk.Tk();r.withdraw()
    notes=m.get("notes","")
    msg=f"Nueva actualización disponible\n\nInstalada: {ver()}\nNueva: {m.get('version')}"
    if notes:msg+=f"\n\n{notes}"
    msg+="\n\nAntes de actualizar se hará un respaldo automático.\n\n¿Actualizar ahora?"
    if messagebox.askyesno("SUPER-UNI POS",msg):
        try:apply(m,src);messagebox.showinfo("SUPER-UNI POS","Actualización instalada correctamente.")
        except Exception as e:messagebox.showerror("SUPER-UNI POS",str(e))
    r.destroy()
def running(port):
    s=socket.socket();s.settimeout(.25)
    try:s.connect(("127.0.0.1",port));return True
    except:return False
    finally:s.close()
def main():
    c=jload(CFG,{})
    if c.get("check_on_start",True):
        try:check()
        except:pass
    port=int(c.get("port",5000));DATA.mkdir(exist_ok=True)
    env=os.environ.copy();env["SUPER_UNI_DATA_DIR"]=str(DATA)
    if not running(port):
        flags=0x08000000 if os.name=="nt" else 0
        subprocess.Popen([sys.executable,str(APP/"super_uni_pos.py")],cwd=str(APP),env=env,creationflags=flags)
        for _ in range(40):
            if running(port):break
            time.sleep(.15)
    webbrowser.open(f"http://127.0.0.1:{port}")
if __name__=="__main__":main()
